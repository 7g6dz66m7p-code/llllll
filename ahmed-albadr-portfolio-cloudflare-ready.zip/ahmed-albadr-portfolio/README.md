# AHMED AL-BADR — أحمد البدر

**Founder • Entrepreneur • AI Product Builder**

The personal platform of Ahmed Al-Badr: the hub for every current and future venture
(مهارة، منصة باحث، SALEEM AI، نظم العراق), plus services, vision, milestones and insights,
with a secure admin dashboard to manage all of it.

Arabic-first (RTL) and ready for English (LTR).

---

## Stack

| Layer | Choice |
| --- | --- |
| Framework | Next.js 16 (App Router, Server Components, Server Actions, Turbopack) |
| Language | TypeScript (strict, `noUncheckedIndexedAccess`) |
| Styling | Tailwind CSS v4 (CSS-first tokens), `@tailwindcss/typography` |
| Motion | CSS keyframes for the hero (no JS on the LCP path), IntersectionObserver reveals, Framer Motion for nav, menu and counters |
| Icons | Lucide (+ matching brand glyphs in `components/shared/brand-icons.tsx`) |
| Data | PostgreSQL + Prisma 7 (`@prisma/adapter-pg`) |
| Auth | Auth.js v5: credentials, JWT sessions, Next 16 `proxy.ts` |
| Storage | Cloudflare R2 (any S3-compatible endpoint) |
| Validation | Zod 4 (shared by client and server) |

## Getting started

```bash
cp .env.example .env            # fill in the values (see below)
npm install
npm run db:deploy               # apply migrations
npm run db:seed                 # load the initial ventures, services, milestones, insights
npm run dev
```

With **no `DATABASE_URL`**, the site still runs. It serves the curated content in `src/data/`
read-only, which is handy for previews. Admin editing needs a database.

### Admin account

```bash
openssl rand -base64 32                       # → AUTH_SECRET
npm run auth:hash -- "a-strong-password"      # → ADMIN_PASSWORD_HASH_B64
```

Set `ADMIN_EMAIL`, `ADMIN_PASSWORD_HASH_B64` and `AUTH_SECRET`, then sign in at `/admin/login`.
The hash is base64-encoded so the `$` characters in bcrypt hashes never get mangled by `.env`
parsers or hosting dashboards.

### Scripts

| Script | Purpose |
| --- | --- |
| `dev` / `build` / `start` | Next.js |
| `lint` / `typecheck` | ESLint (flat config) / `tsc --noEmit` |
| `db:migrate` | Create a migration in development |
| `db:deploy` | Apply migrations (production) |
| `db:seed` | Idempotent seed: never overwrites admin edits |
| `auth:hash` | Generate the admin password hash |

## Architecture

```
src/
  app/
    (site)/            public pages (shared Navbar/Footer layout)
      page.tsx         home: Hero, Stats, Ventures, Focus, Services, Vision, Milestones, Insights, CTA
      about/ ventures/ ventures/[slug]/ services/ vision/ achievements/ insights/ insights/[slug]/ contact/ privacy/ terms/
    admin/
      login/           sign-in (public)
      (panel)/         protected dashboard: overview, ventures, insights, services, achievements,
                       stats, messages, media, social, settings
    api/
      contact/         contact form endpoint (validation, honeypot, time-trap, rate limits)
      health/          lightweight deployment health check
      admin/upload/    authenticated R2 upload with file-signature checks
      auth/[...nextauth]/
    sitemap.ts robots.ts manifest.ts opengraph-image.tsx icon.svg apple-icon.png
  components/
    layout/            Navbar, MobileMenu, Footer
    home/              Hero, Stats, FocusPillars, VisionProcess, AchievementTimeline
    ventures/          VentureCard, VentureGrid, VentureCover, VentureLogo
    services/          ServiceCard
    insights/          InsightCard, InsightsBrowser
    admin/             form kit, ImageField, MediaLibrary, Sidebar, tables
    shared/            SectionHeading, PageHeader, CTA, ContactForm, SocialLinks, Reveal,
                       ThemeProvider, Markdown, Loading/Empty/Error states
    ui/                Button, Badge, Card, form controls, Skeleton
  lib/
    auth/              Auth.js config (edge-safe split) + requireAdmin/assertAdmin
    db/                Prisma singleton
    i18n/              locale config + ar/en dictionaries
    security/          rate limiting, IP hashing, same-origin checks
    seo/               metadata builder + JSON-LD (Person, WebSite, SoftwareApplication, Article, Breadcrumbs)
    storage/           R2 client, upload, magic-byte sniffing
    validations/       Zod schemas (contact + admin entities)
  services/
    content.ts         public read layer (DB or seed fallback, request-deduplicated)
    admin/             Server Actions (authorised, validated, revalidating) + admin queries
  data/                seed content (single source for seeding and the no-DB fallback)
  types/               domain types
  styles/globals.css   design tokens and utilities
prisma/                schema, migrations, seed
```

### Data flow

- **Public pages** are statically generated with ISR (`revalidate = 300`). Every admin mutation calls
  `revalidateSite()`, so changes show up on the next visit.
- **Admin mutations** go through `runAdminAction`: session check → DB check → Zod validation →
  mutation → revalidation, with errors mapped to Arabic messages and logged centrally.
- **Adding a venture** needs no code: create it in `/admin/ventures`. It gets its own page,
  sitemap entry, metadata and structured data automatically.

### Design system

Tokens live in `src/styles/globals.css` as RGB triplets with dark (default) and light themes:
deep navy/charcoal backgrounds, a cyan signature (`--primary`), restrained glass and gradient
utilities (`glass`, `card-surface`, `text-gradient`, `bg-grid`). Typography is IBM Plex Sans Arabic
plus Space Grotesk for Latin runs (`.latin`). Layout uses logical properties
(`ms-/me-/ps-/pe-/start-/end-`) throughout, so flipping to LTR works without changing components.

### Adding English later

1. Move `app/(site)` under `app/[locale]/(site)`, set `lang`/`dir` from `localeDirection[locale]`.
2. Replace `t` (in `lib/i18n`) with `getDictionary(locale)`; `en.ts` is already type-checked
   against `ar.ts`.
3. Add `*_en` content fields (or a translations table) for admin-managed copy.

## Security

- Admin protection on three layers: `proxy.ts` (optimistic redirect), `requireAdmin()` in the panel
  layout, and `assertAdmin()` in every Server Action and admin API route.
- bcrypt credentials, constant-time email comparison, login rate limit (5 per 15 minutes per IP),
  8-hour JWT sessions.
- Contact form: Zod validation + sanitisation, honeypot, minimum fill time, same-origin check,
  in-memory and database-backed rate limits. IPs are stored only as salted SHA-256 hashes.
- Markdown is rendered with raw HTML disabled and URL protocol allow-listing.
- Uploads: auth, 5 MB limit, real file-signature check (SVG rejected), randomised keys.
- Security headers (HSTS, `nosniff`, frame denial, referrer and permissions policies), and `noindex`
  on admin pages.
- No secrets reach the client. `lib/env.ts` is `server-only` and validated with Zod.

## Deployment

### Vercel (recommended)

1. Import the project and set **Root Directory** to `ahmed-albadr-portfolio`.
2. Add the environment variables from `.env.example` (`NEXT_PUBLIC_SITE_URL` = the production domain).
3. Use a managed PostgreSQL (Neon, Supabase, Vercel Postgres). Run `npm run db:deploy && npm run db:seed`
   once (locally against the production URL, or as a build step).
4. R2: create a bucket, enable public access through a custom domain, create an API token with
   object read/write, and set the `R2_*` variables.

### Cloudflare

Deploy with [OpenNext for Cloudflare](https://opennext.js.org/cloudflare) (`@opennextjs/cloudflare`),
using Hyperdrive for PostgreSQL and binding the R2 bucket. The app only uses Node-compatible APIs
(`node:crypto`, `pg`), which are supported with the `nodejs_compat` flag.

## Content notes

The seed descriptions of **منصة باحث**, **SALEEM AI** and **نظم العراق** are written as realistic
product positioning, and project URLs are empty. Review them in `/admin/ventures` and add the real
links, logos, screenshots and the hero portrait (`/admin/settings`).


## Production readiness additions (v1.1)

- Added `/privacy` and `/terms`, linked from the footer and included in the sitemap.
- The contact page now detects a missing database and shows a clear direct-contact fallback instead of exposing a form that would fail on submit.
- Admin login includes an accessible show/hide password control.
- Added `/api/health` for deployment uptime checks (no configuration or secret details are exposed).
- Added 192px, 512px and Apple touch icons for installable/PWA-friendly presentation.
- Added `DEPLOYMENT_CHECKLIST.md` with the exact production launch sequence.

## Cloudflare Workers

The repository includes Cloudflare helper scripts:

```bash
npm run cloudflare:setup
npm run cloudflare:deploy
```

See `CLOUDFLARE_DEPLOYMENT.md` for production variables, database migration, and R2 setup.
