#!/usr/bin/env node
// Usage: npm run auth:hash -- "your-strong-password"
import bcrypt from "bcryptjs";

const password = process.argv[2];
if (!password || password.length < 12) {
  console.error("Provide a password of at least 12 characters: npm run auth:hash -- \"...\"");
  process.exit(1);
}
const hash = await bcrypt.hash(password, 12);
// Base64 avoids `$` escaping problems inside .env files and dashboard variables.
console.log(`ADMIN_PASSWORD_HASH_B64=${Buffer.from(hash).toString("base64")}`);
