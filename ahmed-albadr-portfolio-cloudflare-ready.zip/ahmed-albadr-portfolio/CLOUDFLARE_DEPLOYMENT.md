# Cloudflare Workers deployment

This project is a full-stack Next.js application (App Router, Server Actions, Auth.js, Prisma/PostgreSQL), so deploy it to **Cloudflare Workers**, not static Pages.

Cloudflare's current Wrangler can automatically detect and configure existing Next.js applications.

## First deployment

```bash
npm run cloudflare:setup
npm run cloudflare:deploy
```

Wrangler will create/update the Cloudflare runtime configuration and deploy the app. `nodejs_compat` is required for Prisma's `pg` adapter and is added by Cloudflare's Next.js setup.

## Production environment variables / secrets

Set these in the Worker before enabling database-backed admin features:

- `NEXT_PUBLIC_SITE_URL`
- `DATABASE_URL`
- `AUTH_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD_HASH_B64`
- `IP_HASH_SECRET`
- `CONTACT_EMAIL`
- `CONTACT_WHATSAPP`
- `SOCIAL_INSTAGRAM`
- `SOCIAL_LINKEDIN`
- `SOCIAL_GITHUB`

Object storage (optional, required only for uploads from the admin panel):

- `R2_ACCOUNT_ID`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_BUCKET`
- `R2_PUBLIC_URL`
- `R2_ENDPOINT` (optional)

Use Wrangler secrets for sensitive values, for example:

```bash
npx wrangler@latest secret put DATABASE_URL
npx wrangler@latest secret put AUTH_SECRET
npx wrangler@latest secret put ADMIN_PASSWORD_HASH_B64
npx wrangler@latest secret put IP_HASH_SECRET
```

The public website remains usable with the curated built-in content even when `DATABASE_URL` is not set. The database is required for persistent admin edits, messages, and managed content.

## Database

Apply migrations and seed once against the production PostgreSQL database before relying on the admin panel:

```bash
DATABASE_URL="..." npm run db:deploy
DATABASE_URL="..." npm run db:seed
```

## Portrait

The supplied portrait is stored locally at:

`/public/images/ahmed-albadr-portrait.webp`

and is the default hero portrait for both seed/fallback content and new database seeding.
