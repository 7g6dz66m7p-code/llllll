/**
 * Minimal structured logger. Emits single-line JSON in production (ingestible by Vercel / Cloudflare
 * log drains) and readable output in development. Never pass secrets or raw personal data here.
 */
type Level = "debug" | "info" | "warn" | "error";

const isProd = process.env.NODE_ENV === "production";

function serializeError(err: unknown) {
  if (err instanceof Error) return { name: err.name, message: err.message, stack: isProd ? undefined : err.stack };
  return { message: String(err) };
}

function write(level: Level, message: string, context?: Record<string, unknown>) {
  if (level === "debug" && isProd) return;
  const payload = {
    level,
    message,
    time: new Date().toISOString(),
    ...(context && {
      ...context,
      ...(context.error !== undefined && { error: serializeError(context.error) }),
    }),
  };
  const line = isProd ? JSON.stringify(payload) : `[${level}] ${message}${context ? " " + JSON.stringify(payload) : ""}`;
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const logger = {
  debug: (m: string, c?: Record<string, unknown>) => write("debug", m, c),
  info: (m: string, c?: Record<string, unknown>) => write("info", m, c),
  warn: (m: string, c?: Record<string, unknown>) => write("warn", m, c),
  error: (m: string, c?: Record<string, unknown>) => write("error", m, c),
};
