import "server-only";
import { timingSafeEqual } from "node:crypto";
import bcrypt from "bcryptjs";
import NextAuth, { CredentialsSignin } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { redirect } from "next/navigation";
import { z } from "zod";
import { env } from "@/lib/env";
import { logger } from "@/lib/logger";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp, hashIp } from "@/lib/security/request";
import { authConfig } from "./auth.config";

const credentialsSchema = z.object({
  email: z.string().trim().toLowerCase().pipe(z.email()),
  password: z.string().min(1).max(200),
});

class RateLimitedSignin extends CredentialsSignin {
  code = "rate_limited";
}

function safeEqual(a: string, b: string) {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

// Pre-computed hash used when the admin is not configured, so response timing stays constant.
const DUMMY_HASH = "$2b$12$cMgZH3wKtvKlNO5/FmkMneA61fSqgNRykkP3Apk6xXsiK/m2YFNO6";

export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  secret: process.env.AUTH_SECRET,
  providers: [
    Credentials({
      credentials: { email: { type: "email" }, password: { type: "password" } },
      async authorize(raw, request) {
        const ipHash = hashIp(clientIp(request.headers));
        if (!rateLimit(`login:${ipHash}`, { limit: 5, windowMs: 15 * 60 * 1000 }).ok) {
          logger.warn("auth.login.rate_limited", { ipHash });
          throw new RateLimitedSignin();
        }

        const parsed = credentialsSchema.safeParse(raw);
        if (!parsed.success) return null;
        const { email, password } = parsed.data;

        const { ADMIN_EMAIL, ADMIN_PASSWORD_HASH_B64 } = env();
        const hash = ADMIN_PASSWORD_HASH_B64 ? Buffer.from(ADMIN_PASSWORD_HASH_B64, "base64").toString("utf8") : DUMMY_HASH;
        const passwordOk = await bcrypt.compare(password, hash);
        const emailOk = Boolean(ADMIN_EMAIL) && safeEqual(email, ADMIN_EMAIL!.toLowerCase());

        if (!passwordOk || !emailOk || !ADMIN_PASSWORD_HASH_B64) {
          logger.warn("auth.login.failed", { ipHash });
          return null;
        }
        logger.info("auth.login.success", { ipHash });
        return { id: "admin", email, name: "Ahmed Al-Badr" };
      },
    }),
  ],
});

/** Use in admin Server Components/layouts. Redirects anonymous visitors to the login page. */
export async function requireAdmin() {
  const session = await auth();
  if (!session?.user) redirect("/admin/login");
  return session;
}

export class UnauthorizedError extends Error {
  constructor() {
    super("UNAUTHORIZED");
  }
}

/** Use in Server Actions and route handlers — never trust the proxy alone. */
export async function assertAdmin() {
  const session = await auth();
  if (!session?.user) throw new UnauthorizedError();
  return session;
}
