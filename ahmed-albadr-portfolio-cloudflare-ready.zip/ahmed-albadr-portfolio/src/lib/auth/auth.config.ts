import type { NextAuthConfig } from "next-auth";

/**
 * Edge-safe Auth.js config shared by `proxy.ts` and the full server config.
 * It contains no providers or Node-only dependencies.
 */
export const authConfig = {
  pages: { signIn: "/admin/login" },
  session: { strategy: "jwt", maxAge: 60 * 60 * 8 },
  trustHost: true,
  providers: [],
  callbacks: {
    authorized({ auth, request }) {
      const { pathname } = request.nextUrl;
      if (pathname === "/admin/login") return true;
      if (pathname.startsWith("/api/admin") && !auth?.user) {
        return Response.json({ ok: false, code: "UNAUTHORIZED", message: "يجب تسجيل الدخول" }, { status: 401 });
      }
      if (pathname.startsWith("/admin")) return Boolean(auth?.user);
      return true;
    },
    jwt({ token, user }) {
      if (user) token.role = "admin";
      return token;
    },
    session({ session, token }) {
      if (session.user) (session.user as { role?: string }).role = typeof token.role === "string" ? token.role : undefined;
      return session;
    },
  },
} satisfies NextAuthConfig;
