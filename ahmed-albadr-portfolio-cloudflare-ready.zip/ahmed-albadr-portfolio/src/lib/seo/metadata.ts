import type { Metadata } from "next";
import { absoluteUrl, siteConfig } from "@/lib/site";

interface PageMetaInput {
  title?: string;
  description: string;
  path: string;
  image?: string | null;
  type?: "website" | "article" | "profile";
  publishedTime?: string;
  modifiedTime?: string;
  keywords?: string[];
  noIndex?: boolean;
}

/** Consistent metadata (canonical, Open Graph, Twitter) for every public page. */
export function buildMetadata({
  title,
  description,
  path,
  image,
  type = "website",
  publishedTime,
  modifiedTime,
  keywords,
  noIndex,
}: PageMetaInput): Metadata {
  const url = absoluteUrl(path);
  const images = image ? [{ url: image.startsWith("http") ? image : absoluteUrl(image), width: 1200, height: 630 }] : undefined;
  return {
    title,
    description,
    keywords: keywords ? [...keywords, ...siteConfig.keywords.slice(0, 4)] : undefined,
    alternates: { canonical: url },
    openGraph: {
      type,
      url,
      title: title ? `${title} | ${siteConfig.title}` : siteConfig.title,
      description,
      siteName: siteConfig.title,
      locale: siteConfig.locale,
      ...(images && { images }),
      ...(type === "article" && { publishedTime, modifiedTime, authors: [absoluteUrl("/about")] }),
    },
    twitter: {
      card: "summary_large_image",
      title: title ? `${title} | ${siteConfig.title}` : siteConfig.title,
      description,
      ...(images && { images: images.map((i) => i.url) }),
    },
    ...(noIndex && { robots: { index: false, follow: false } }),
  };
}
