import { absoluteUrl, siteConfig } from "@/lib/site";
import type { Insight, SocialLink, Venture } from "@/types/content";

type JsonLdObject = Record<string, unknown>;

/** Renders schema.org JSON-LD. `<` is escaped so content can never break out of the script tag. */
export function JsonLd({ data }: { data: JsonLdObject | JsonLdObject[] }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
    />
  );
}

const personId = absoluteUrl("/#person");
const websiteId = absoluteUrl("/#website");

export function personSchema({ description, image, socialLinks }: { description: string; image?: string | null; socialLinks: SocialLink[] }) {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    "@id": personId,
    name: siteConfig.name,
    alternateName: [siteConfig.nameEn, "AHMED AL-BADR", "Ahmed Albadr"],
    url: siteConfig.url,
    description,
    jobTitle: "Founder & AI Product Builder",
    ...(image && { image: image.startsWith("http") ? image : absoluteUrl(image) }),
    knowsAbout: ["Entrepreneurship", "Artificial Intelligence", "SaaS", "Digital Products", "Business Automation"],
    sameAs: socialLinks.filter((l) => l.url.startsWith("http")).map((l) => l.url),
  };
}

export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "@id": websiteId,
    url: siteConfig.url,
    name: siteConfig.title,
    inLanguage: "ar",
    publisher: { "@id": personId },
  };
}

export function ventureSchema(venture: Venture) {
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: venture.nameEn ? `${venture.name} (${venture.nameEn})` : venture.name,
    description: venture.shortDescription,
    applicationCategory: venture.category,
    operatingSystem: "Web",
    url: venture.websiteUrl ?? absoluteUrl(`/ventures/${venture.slug}`),
    ...(venture.logo && { image: absoluteUrl(venture.logo) }),
    creator: { "@id": personId },
    founder: { "@id": personId },
  };
}

export function articleSchema(insight: Insight) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: insight.seoTitle ?? insight.title,
    description: insight.metaDescription ?? insight.excerpt,
    datePublished: insight.publishedAt?.toISOString(),
    dateModified: insight.updatedAt.toISOString(),
    inLanguage: "ar",
    articleSection: insight.category,
    mainEntityOfPage: absoluteUrl(`/insights/${insight.slug}`),
    ...(insight.coverImage && { image: [insight.coverImage.startsWith("http") ? insight.coverImage : absoluteUrl(insight.coverImage)] }),
    author: { "@id": personId, "@type": "Person", name: siteConfig.name, url: absoluteUrl("/about") },
    publisher: { "@id": personId },
  };
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: absoluteUrl(item.path),
    })),
  };
}
