import type { core } from "zod";

export function zodIssuesToFieldErrors(issues: core.$ZodIssue[]) {
  const out: Record<string, string> = {};
  for (const issue of issues) {
    const key = issue.path.join(".");
    if (key && !out[key]) out[key] = issue.message;
  }
  return out;
}
