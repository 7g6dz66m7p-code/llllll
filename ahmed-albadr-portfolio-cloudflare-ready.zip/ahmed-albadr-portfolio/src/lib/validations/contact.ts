import { z } from "zod";
import { INQUIRY_TYPES } from "@/types/content";
import { sanitizeText, stripTags } from "@/lib/utils/sanitize";

const clean = (multiline = false) => z.string().transform((v) => stripTags(sanitizeText(v, { multiline })));

export const contactSchema = z.object({
  name: clean().pipe(z.string().min(2, "الاسم قصير جدًا").max(100, "الاسم طويل جدًا")),
  email: z.string().trim().toLowerCase().pipe(z.email("أدخل بريدًا إلكترونيًا صحيحًا").max(160)),
  phone: clean()
    .pipe(z.string().max(30).regex(/^[+\d\s()-]*$/, "رقم الهاتف غير صالح"))
    .optional()
    .transform((v) => (v ? v : undefined)),
  type: z.enum(INQUIRY_TYPES, { error: "اختر نوع الطلب" }),
  message: clean(true).pipe(z.string().min(20, "اكتب رسالة لا تقل عن 20 حرفًا").max(4000, "الرسالة طويلة جدًا")),
  // Anti-spam: honeypot must stay empty; elapsed is ms since the form was rendered.
  website: z.string().max(500).optional(),
  elapsed: z.coerce.number().int().nonnegative().optional(),
});

export type ContactInput = z.input<typeof contactSchema>;
export type ContactData = z.output<typeof contactSchema>;
