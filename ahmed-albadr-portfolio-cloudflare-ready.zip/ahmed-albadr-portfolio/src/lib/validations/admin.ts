import { z } from "zod";
import { iconNames } from "@/lib/icons";
import { sanitizeText } from "@/lib/utils/sanitize";
import { MESSAGE_STATUSES, SOCIAL_PLATFORMS, VENTURE_STATUSES } from "@/types/content";

// ---------- Primitives ----------

const text = (min: number, max: number, label: string) =>
  z
    .string()
    .transform((v) => sanitizeText(v))
    .pipe(z.string().min(min, `${label}: الحد الأدنى ${min} أحرف`).max(max, `${label}: الحد الأقصى ${max} حرف`));

const longText = (min: number, max: number, label: string) =>
  z
    .string()
    .transform((v) => sanitizeText(v, { multiline: true }))
    .pipe(z.string().min(min, `${label}: الحد الأدنى ${min} أحرف`).max(max, `${label}: الحد الأقصى ${max} حرف`));

const optionalText = (max: number) =>
  z
    .string()
    .optional()
    .transform((v) => (v ? sanitizeText(v).slice(0, max) : null) || null);

const optionalLongText = (max: number) =>
  z
    .string()
    .optional()
    .transform((v) => (v ? sanitizeText(v, { multiline: true }).slice(0, max) : null) || null);

/** Absolute http(s) URL or a site-relative path (e.g. /logos/x.svg). */
const urlOrPath = z
  .string()
  .optional()
  .transform((v) => v?.trim() || null)
  .refine((v) => v === null || /^https?:\/\/[^\s]+$/i.test(v) || /^\/[^\s/][^\s]*$/.test(v), "رابط غير صالح (يجب أن يبدأ بـ https:// أو /)");

const httpUrl = z
  .string()
  .optional()
  .transform((v) => v?.trim() || null)
  .refine((v) => v === null || /^https?:\/\/[^\s]+$/i.test(v), "رابط غير صالح (يجب أن يبدأ بـ https://)");

const slug = z
  .string()
  .trim()
  .toLowerCase()
  .min(2, "المعرّف (slug) قصير جدًا")
  .max(80)
  .regex(/^[\p{L}\p{N}]+(?:-[\p{L}\p{N}]+)*$/u, "المعرّف يقبل الحروف والأرقام والشرطة فقط");

const checkbox = z
  .union([z.literal("on"), z.literal("true"), z.literal("false"), z.literal("")])
  .optional()
  .transform((v) => v === "on" || v === "true");

const int = (min: number, max: number) => z.coerce.number().int().min(min).max(max);

/** One item per line (or comma separated), trimmed and de-duplicated. */
const list = (maxItems: number, maxLen = 120) =>
  z
    .string()
    .optional()
    .transform((v) =>
      [...new Set((v ?? "").split(/\n|,|،/).map((s) => sanitizeText(s)).filter(Boolean))].slice(0, maxItems).map((s) => s.slice(0, maxLen)),
    );

const urlList = (maxItems: number) =>
  list(maxItems, 500).refine((items) => items.every((u) => /^https?:\/\/\S+$/i.test(u) || /^\/\S+$/.test(u)), "كل رابط يجب أن يبدأ بـ https:// أو /");

/** "Title | Description" per line. */
const features = z
  .string()
  .optional()
  .transform((v) =>
    (v ?? "")
      .split("\n")
      .map((line) => line.split("|"))
      .map(([title = "", ...rest]) => ({ title: sanitizeText(title).slice(0, 120), description: sanitizeText(rest.join("|")).slice(0, 400) }))
      .filter((f) => f.title)
      .slice(0, 24),
  );

const hexColor = z
  .string()
  .optional()
  .transform((v) => v?.trim() || null)
  .refine((v) => v === null || /^#[0-9a-f]{6}$/i.test(v), "اللون يجب أن يكون بصيغة #RRGGBB");

const optionalDate = z
  .string()
  .optional()
  .transform((v) => (v ? new Date(v) : null))
  .refine((d) => d === null || !Number.isNaN(d.getTime()), "تاريخ غير صالح");

// ---------- Entities ----------

export const ventureSchema = z.object({
  name: text(2, 80, "اسم المشروع"),
  nameEn: optionalText(80),
  slug,
  tagline: optionalText(140),
  logo: urlOrPath,
  coverImage: urlOrPath,
  shortDescription: text(20, 320, "الوصف المختصر"),
  fullDescription: longText(20, 20000, "الوصف الكامل"),
  problem: optionalLongText(3000),
  solution: optionalLongText(3000),
  features,
  targetAudience: list(20),
  screenshots: urlList(20),
  category: text(2, 60, "التصنيف"),
  status: z.enum(VENTURE_STATUSES),
  technologies: list(24, 40),
  websiteUrl: httpUrl,
  githubUrl: httpUrl,
  accentColor: hexColor,
  featured: checkbox,
  published: checkbox,
  sortOrder: int(0, 9999).default(0),
  launchedAt: optionalDate,
});

export const insightSchema = z.object({
  title: text(5, 160, "العنوان"),
  slug,
  coverImage: urlOrPath,
  excerpt: text(20, 400, "الوصف"),
  content: longText(50, 100000, "المحتوى"),
  category: text(2, 60, "التصنيف"),
  status: z.enum(["DRAFT", "PUBLISHED"]),
  featured: checkbox,
  publishedAt: optionalDate,
  seoTitle: optionalText(70),
  metaDescription: optionalText(170),
});

export const serviceSchema = z.object({
  title: text(2, 80, "العنوان"),
  description: text(10, 500, "الوصف"),
  icon: z.enum(iconNames as [string, ...string[]]),
  highlights: list(8, 80),
  ctaLabel: text(2, 40, "نص الزر"),
  ctaHref: z.string().trim().regex(/^(\/|https?:\/\/)\S*$/, "رابط الزر غير صالح").max(300),
  published: checkbox,
  sortOrder: int(0, 9999).default(0),
});

export const achievementSchema = z.object({
  year: int(1990, 2100),
  title: text(3, 140, "العنوان"),
  description: optionalLongText(800),
  date: optionalDate,
  ventureId: z
    .string()
    .optional()
    .transform((v) => v || null),
  published: checkbox,
  sortOrder: int(0, 9999).default(0),
});

export const statSchema = z.object({
  label: text(2, 60, "العنوان"),
  value: int(0, 1_000_000),
  suffix: optionalText(6),
  icon: z.enum(iconNames as [string, ...string[]]),
  sortOrder: int(0, 9999).default(0),
});

export const socialLinkSchema = z.object({
  platform: z.enum(SOCIAL_PLATFORMS),
  url: z
    .string()
    .trim()
    .max(500)
    .regex(/^(https?:\/\/|mailto:|tel:)\S+$/i, "الرابط يجب أن يبدأ بـ https:// أو mailto: أو tel:"),
  label: optionalText(40),
  active: checkbox,
  sortOrder: int(0, 9999).default(0),
});

export const settingsSchema = z.object({
  heroName: text(2, 60, "الاسم"),
  heroNameEn: text(2, 60, "الاسم بالإنجليزية"),
  heroRole: text(2, 120, "الوصف"),
  heroIdentity: text(2, 120, "الهوية"),
  heroDescription: text(10, 400, "النص التعريفي"),
  heroImage: urlOrPath,
  primaryCtaLabel: text(2, 40, "الزر الأساسي"),
  secondaryCtaLabel: text(2, 40, "الزر الثانوي"),
  aboutHeadline: text(2, 80, "عنوان صفحة عن أحمد"),
  aboutIdentity: text(2, 120, "هوية صفحة عن أحمد"),
  aboutBody: longText(20, 6000, "نص صفحة عن أحمد"),
  visionStatement: text(10, 400, "نص الرؤية"),
  contactEmail: z
    .string()
    .optional()
    .transform((v) => v?.trim().toLowerCase() || null)
    .refine((v) => v === null || z.email().safeParse(v).success, "بريد غير صالح"),
  whatsappNumber: z
    .string()
    .optional()
    .transform((v) => v?.replace(/[^\d+]/g, "") || null)
    .refine((v) => v === null || /^\+?\d{8,15}$/.test(v), "رقم واتساب غير صالح (مثال: 9647700000000)"),
  location: optionalText(80),
  availability: optionalText(120),
  seoDescription: text(50, 300, "وصف SEO"),
  ogImage: urlOrPath,
});

export const messageStatusSchema = z.enum(MESSAGE_STATUSES);
