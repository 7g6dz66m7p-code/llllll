import { createElement } from "react";
import {
  BarChart3,
  Boxes,
  BrainCircuit,
  Code2,
  Compass,
  Cpu,
  Globe,
  Hammer,
  Layers,
  Lightbulb,
  LineChart,
  Megaphone,
  Rocket,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  Workflow,
  Zap,
  type LucideIcon,
} from "lucide-react";

/**
 * Curated icon registry. Admin-editable records store an icon *name*; only names listed here
 * can be rendered, which keeps bundles small and prevents arbitrary component lookups.
 */
export const iconRegistry = {
  BarChart3,
  Boxes,
  BrainCircuit,
  Code2,
  Compass,
  Cpu,
  Globe,
  Hammer,
  Layers,
  Lightbulb,
  LineChart,
  Megaphone,
  Rocket,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  Workflow,
  Zap,
} satisfies Record<string, LucideIcon>;

export type IconName = keyof typeof iconRegistry;
export const iconNames = Object.keys(iconRegistry) as IconName[];

export function getIcon(name: string | null | undefined): LucideIcon {
  return (name && name in iconRegistry ? iconRegistry[name as IconName] : Sparkles) as LucideIcon;
}

/** Renders a registry icon by name (for admin-editable records). */
export function DynamicIcon({ name, className }: { name: string | null | undefined; className?: string }) {
  return createElement(getIcon(name), { className, "aria-hidden": true });
}
