import "server-only";
import { randomUUID } from "node:crypto";
import { DeleteObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { env, isStorageConfigured } from "@/lib/env";

/**
 * S3-compatible object storage (Cloudflare R2 by default; any S3 endpoint works via R2_ENDPOINT).
 * Files are served from R2_PUBLIC_URL (an R2 custom domain or r2.dev URL).
 */
let client: S3Client | null = null;

function s3() {
  if (!isStorageConfigured()) throw new Error("Object storage is not configured");
  if (!client) {
    const e = env();
    client = new S3Client({
      region: "auto",
      endpoint: e.R2_ENDPOINT ?? `https://${e.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
      credentials: { accessKeyId: e.R2_ACCESS_KEY_ID!, secretAccessKey: e.R2_SECRET_ACCESS_KEY! },
    });
  }
  return client;
}

export const ALLOWED_IMAGE_TYPES = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/avif": "avif",
  "image/gif": "gif",
} as const;

export type AllowedImageType = keyof typeof ALLOWED_IMAGE_TYPES;
export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;

/** Verifies the real file signature so a renamed script can't be uploaded as an image. SVG is rejected by design. */
export function sniffImageType(bytes: Uint8Array): AllowedImageType | null {
  const b = (i: number) => bytes[i] ?? -1;
  if (b(0) === 0x89 && b(1) === 0x50 && b(2) === 0x4e && b(3) === 0x47) return "image/png";
  if (b(0) === 0xff && b(1) === 0xd8 && b(2) === 0xff) return "image/jpeg";
  if (b(0) === 0x47 && b(1) === 0x49 && b(2) === 0x46) return "image/gif";
  if (b(0) === 0x52 && b(1) === 0x49 && b(2) === 0x46 && b(3) === 0x46 && b(8) === 0x57 && b(9) === 0x45 && b(10) === 0x42 && b(11) === 0x50) return "image/webp";
  const ftyp = String.fromCharCode(b(4), b(5), b(6), b(7));
  const brand = String.fromCharCode(b(8), b(9), b(10), b(11));
  if (ftyp === "ftyp" && (brand === "avif" || brand === "avis")) return "image/avif";
  return null;
}

export async function uploadObject(bytes: Uint8Array, type: AllowedImageType, folder = "uploads") {
  const now = new Date();
  const key = `${folder}/${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, "0")}/${randomUUID()}.${ALLOWED_IMAGE_TYPES[type]}`;
  await s3().send(
    new PutObjectCommand({
      Bucket: env().R2_BUCKET,
      Key: key,
      Body: bytes,
      ContentType: type,
      CacheControl: "public, max-age=31536000, immutable",
    }),
  );
  return { key, url: `${env().R2_PUBLIC_URL!.replace(/\/$/, "")}/${key}` };
}

export async function deleteObject(key: string) {
  await s3().send(new DeleteObjectCommand({ Bucket: env().R2_BUCKET, Key: key }));
}
