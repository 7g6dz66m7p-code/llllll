/** Public, non-secret site configuration (safe for client bundles). */
export const siteConfig = {
  name: "أحمد البدر",
  nameEn: "Ahmed Al-Badr",
  title: "أحمد البدر | Ahmed Al-Badr",
  identity: "Founder • Entrepreneur • AI Product Builder",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, ""),
  locale: "ar_IQ",
  keywords: [
    "أحمد البدر",
    "Ahmed Al-Badr",
    "Ahmed Albadr",
    "مؤسس",
    "رائد أعمال",
    "Founder",
    "Entrepreneur",
    "AI Product Builder",
    "منتجات رقمية",
    "ذكاء اصطناعي",
    "SaaS",
    "مهارة",
    "منصة باحث",
    "SALEEM AI",
    "نظم العراق",
  ],
} as const;

export const absoluteUrl = (path = "/") => `${siteConfig.url}${path.startsWith("/") ? path : `/${path}`}`;
