import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { logger } from "@/lib/logger";
import { zodIssuesToFieldErrors } from "@/lib/validations/errors";

export class HttpError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public fieldErrors?: Record<string, string>,
  ) {
    super(message);
  }
}

export function zodFieldErrors(error: ZodError) {
  return zodIssuesToFieldErrors(error.issues);
}

/** Central error → JSON mapping for route handlers. Unknown errors are logged and hidden from clients. */
export function handleRouteError(error: unknown, context: string) {
  if (error instanceof HttpError) {
    return NextResponse.json({ ok: false, code: error.code, message: error.message, fieldErrors: error.fieldErrors }, { status: error.status });
  }
  if (error instanceof ZodError) {
    return NextResponse.json({ ok: false, code: "VALIDATION", message: "تحقق من الحقول المدخلة", fieldErrors: zodFieldErrors(error) }, { status: 422 });
  }
  logger.error(`route.error:${context}`, { error });
  return NextResponse.json({ ok: false, code: "INTERNAL", message: "حدث خطأ غير متوقع" }, { status: 500 });
}
