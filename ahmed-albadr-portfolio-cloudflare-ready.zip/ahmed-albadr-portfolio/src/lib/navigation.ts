import { t } from "@/lib/i18n";

export interface NavItem {
  href: string;
  label: string;
}

export const mainNav: NavItem[] = [
  { href: "/", label: t.nav.home },
  { href: "/ventures", label: t.nav.ventures },
  { href: "/about", label: t.nav.about },
  { href: "/services", label: t.nav.services },
  { href: "/vision", label: t.nav.vision },
  { href: "/achievements", label: t.nav.achievements },
  { href: "/insights", label: t.nav.insights },
];

export const footerNav: NavItem[] = [...mainNav.slice(1), { href: "/contact", label: t.nav.contact }];

export function isActivePath(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}
