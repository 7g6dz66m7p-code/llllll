import "server-only";
import { createHash } from "node:crypto";
import { env } from "@/lib/env";

export function clientIp(headers: Headers) {
  return (
    headers.get("cf-connecting-ip") ??
    headers.get("x-real-ip") ??
    headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "unknown"
  );
}

/** One-way, salted IP fingerprint — lets us rate-limit without storing personal data. */
export function hashIp(ip: string) {
  const secret = env().IP_HASH_SECRET ?? env().AUTH_SECRET ?? "dev-only-ip-salt";
  return createHash("sha256").update(`${secret}:${ip}`).digest("hex").slice(0, 32);
}

/** Basic CSRF defence for JSON endpoints: the Origin (when sent) must match the Host. */
export function isSameOrigin(headers: Headers) {
  const origin = headers.get("origin");
  if (!origin) return true;
  const host = headers.get("x-forwarded-host") ?? headers.get("host");
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}
