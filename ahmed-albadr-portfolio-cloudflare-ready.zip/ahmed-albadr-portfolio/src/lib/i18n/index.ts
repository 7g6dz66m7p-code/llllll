import { ar, type DictionaryShape } from "./dictionaries/ar";
import { en } from "./dictionaries/en";
import { defaultLocale, type Locale } from "./config";

export type Dictionary = DictionaryShape;

const dictionaries: Record<Locale, Dictionary> = { ar, en };

export function getDictionary(locale: Locale = defaultLocale): Dictionary {
  return dictionaries[locale];
}

/** Current-locale dictionary. Swap for a request-scoped lookup once `[locale]` routing ships. */
export const t = getDictionary(defaultLocale);

export * from "./config";
