export const ar = {
  brand: {
    name: "أحمد البدر",
    nameEn: "AHMED AL-BADR",
    identity: "Founder • Entrepreneur • AI Product Builder",
  },
  nav: {
    home: "الرئيسية",
    about: "عن أحمد",
    ventures: "المشاريع",
    services: "الخدمات",
    vision: "الرؤية",
    achievements: "الإنجازات",
    insights: "أفكار ورؤى",
    contact: "تواصل",
    cta: "ابدأ مشروعك",
    openMenu: "فتح القائمة",
    closeMenu: "إغلاق القائمة",
    skipToContent: "انتقل إلى المحتوى",
    toggleTheme: "تبديل المظهر",
  },
  ventureStatus: {
    LIVE: "مُطلق",
    BETA: "إصدار تجريبي",
    IN_DEVELOPMENT: "قيد التطوير",
    PLANNED: "مُخطط",
  },
  inquiryType: {
    NEW_PROJECT: "مشروع جديد",
    PARTNERSHIP: "شراكة",
    INVESTMENT: "استثمار",
    CONSULTING: "استشارة",
    MEDIA: "إعلام ومقابلات",
    OTHER: "أخرى",
  },
  messageStatus: {
    NEW: "جديدة",
    READ: "مقروءة",
    REPLIED: "تم الرد",
    ARCHIVED: "مؤرشفة",
  },
  common: {
    exploreVenture: "استكشف المشروع",
    visitWebsite: "زيارة المشروع",
    viewAll: "عرض الكل",
    readMore: "اقرأ المزيد",
    backTo: "العودة إلى",
    featured: "مميز",
    minutesRead: (n: number) => `${n} دقائق قراءة`,
    loading: "جارٍ التحميل…",
    retry: "إعادة المحاولة",
    sourceCode: "الكود المصدري",
  },
  states: {
    emptyTitle: "لا يوجد محتوى بعد",
    emptyDescription: "سيظهر المحتوى هنا فور نشره.",
    errorTitle: "حدث خطأ غير متوقع",
    errorDescription: "تعذّر تحميل هذا القسم. حاول مرة أخرى بعد لحظات.",
    notFoundTitle: "الصفحة غير موجودة",
    notFoundDescription: "ربما تم نقل الصفحة أو أن الرابط غير صحيح.",
  },
  footer: {
    tagline: "أبني منتجات رقمية وأنظمة ذكية تتحول إلى أعمال قابلة للنمو.",
    explore: "استكشف",
    ventures: "المشاريع",
    connect: "تواصل",
    rights: "جميع الحقوق محفوظة.",
  },
  contact: {
    name: "الاسم الكامل",
    email: "البريد الإلكتروني",
    phone: "رقم الهاتف (اختياري)",
    type: "نوع الطلب",
    message: "الرسالة",
    messagePlaceholder: "حدّثني عن فكرتك أو مشروعك وما الذي تريد تحقيقه…",
    submit: "إرسال الرسالة",
    sending: "جارٍ الإرسال…",
    success: "تم استلام رسالتك بنجاح. سأعود إليك في أقرب وقت.",
    genericError: "تعذّر إرسال الرسالة. حاول مرة أخرى.",
    rateLimited: "أرسلت عدة رسائل خلال وقت قصير. حاول مجددًا لاحقًا.",
    privacy: "نستخدم بياناتك للرد على طلبك وحماية النموذج من الإساءة وفق سياسة الخصوصية.",
  },
} as const;

type DeepString<T> = {
  [K in keyof T]: T[K] extends (...args: infer A) => string
    ? (...args: A) => string
    : T[K] extends object
      ? DeepString<T[K]>
      : string;
};

export type DictionaryShape = DeepString<typeof ar>;
