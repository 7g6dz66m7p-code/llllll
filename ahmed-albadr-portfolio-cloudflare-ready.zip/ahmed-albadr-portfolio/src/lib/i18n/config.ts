// Locale configuration. Arabic (RTL) is the primary locale; English (LTR) is prepared
// so a future `app/[locale]` segment can be introduced without touching components:
// every component reads copy from a dictionary and uses logical CSS properties (ms/me/ps/pe/start/end).

export const locales = ["ar", "en"] as const;
export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "ar";

export const localeDirection: Record<Locale, "rtl" | "ltr"> = {
  ar: "rtl",
  en: "ltr",
};

export const localeTag: Record<Locale, string> = {
  ar: "ar-IQ",
  en: "en-US",
};

export function isLocale(value: string): value is Locale {
  return (locales as readonly string[]).includes(value);
}
