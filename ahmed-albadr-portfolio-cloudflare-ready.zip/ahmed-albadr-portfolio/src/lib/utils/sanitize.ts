/** Normalises user text: NFC, strips control/zero-width chars (keeps \n and \t), collapses runaway whitespace. */
export function sanitizeText(value: string, { multiline = false }: { multiline?: boolean } = {}) {
  let v = value.normalize("NFC").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B\u2028\u2029\uFEFF]/g, "");
  v = multiline ? v.replace(/\r\n?/g, "\n").replace(/\n{4,}/g, "\n\n\n") : v.replace(/\s+/g, " ");
  return v.trim();
}

/** Strips any HTML tags — contact content is shown as plain text only, but defence in depth. */
export function stripTags(value: string) {
  return value.replace(/<[^>]*>/g, "");
}
