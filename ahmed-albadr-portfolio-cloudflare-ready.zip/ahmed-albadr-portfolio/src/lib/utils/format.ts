import { localeTag, defaultLocale } from "@/lib/i18n/config";

const dateFormatter = new Intl.DateTimeFormat(`${localeTag[defaultLocale]}-u-nu-latn`, {
  year: "numeric",
  month: "long",
  day: "numeric",
});

export function formatDate(date: Date | string | null | undefined) {
  if (!date) return "";
  const d = typeof date === "string" ? new Date(date) : date;
  return Number.isNaN(d.getTime()) ? "" : dateFormatter.format(d);
}

/** Arabic reads ~180 words/minute on screen. */
export function readingTime(text: string) {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 180));
}

/** URL-safe slug. Arabic letters are kept (browsers display them natively); Latin is lowercased. */
export function slugify(input: string) {
  return input
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[ً-ٰٟ]/g, "") // tashkeel
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();
}
