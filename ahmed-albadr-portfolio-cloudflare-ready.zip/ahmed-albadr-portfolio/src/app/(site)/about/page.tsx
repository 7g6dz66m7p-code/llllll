import { Bot, Boxes, Cpu, Lightbulb, Rocket, Workflow } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeading } from "@/components/shared/section-heading";
import { Reveal } from "@/components/shared/reveal";
import { CTA } from "@/components/shared/cta";
import { FocusPillars } from "@/components/home/focus-pillars";
import { VentureLogo } from "@/components/ventures/venture-logo";
import { buildMetadata } from "@/lib/seo/metadata";
import { getSiteSettings, getVentures } from "@/services/content";
import Link from "next/link";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "عن أحمد",
  description:
    "أحمد البدر — رائد أعمال وباني منتجات رقمية. يبني مشاريع تقنية ومنصات SaaS ومنتجات ذكاء اصطناعي تحوّل الأفكار إلى أعمال قابلة للنمو.",
  path: "/about",
  type: "profile",
});

const focusAreas = [
  { icon: Rocket, title: "بناء المشاريع الرقمية", text: "من الفكرة إلى شركة: نموذج العمل، الفريق، والإطلاق." },
  { icon: Boxes, title: "تطوير المنتجات", text: "تجربة مستخدم واضحة وميزات تُبنى على احتياج فعلي." },
  { icon: Bot, title: "الذكاء الاصطناعي", text: "دمج النماذج الذكية داخل سير العمل لا على هامشه." },
  { icon: Cpu, title: "منصات SaaS", text: "اشتراكات، أرصدة، صلاحيات وبنية متعددة المؤسسات." },
  { icon: Workflow, title: "الأنظمة والأتمتة", text: "أنظمة إدارة وأتمتة تختصر الوقت وتقلل الأخطاء." },
  { icon: Lightbulb, title: "ريادة الأعمال", text: "قرارات مبنية على السوق، وتجريب سريع، ونمو مستدام." },
];

const principles = [
  { title: "المشكلة قبل التقنية", text: "لا أبدأ بالأداة، بل بالشخص الذي يعاني والمشكلة التي يدفع ليتخلص منها." },
  { title: "أطلق مبكرًا وتعلّم", text: "النسخة الأولى ليست النهائية؛ هي بداية الحوار الحقيقي مع السوق." },
  { title: "جودة عالمية بهوية عربية", text: "منتجات تحترم لغة المستخدم وثقافته، وتنافس بجودة أي منتج عالمي." },
  { title: "ابنِ ليكبر", text: "قرارات تقنية وتنظيمية تجعل التوسع خطوة طبيعية لا إعادة بناء." },
];

export default async function AboutPage() {
  const [settings, ventures] = await Promise.all([getSiteSettings(), getVentures()]);
  const paragraphs = settings.aboutBody.split(/\n{2,}/).filter(Boolean);

  return (
    <>
      <PageHeader
        eyebrow={settings.aboutIdentity}
        title={<span className="text-gradient">{settings.aboutHeadline}</span>}
        description={settings.heroRole}
        breadcrumbs={[{ name: "عن أحمد", path: "/about" }]}
      />

      <section className="container-page pb-8">
        <div className="grid gap-12 lg:grid-cols-12">
          <Reveal className="space-y-6 text-lg leading-9 text-muted lg:col-span-7">
            {paragraphs.map((p, i) => (
              <p key={i} className={i === 0 ? "text-xl leading-10 text-foreground" : undefined}>
                {p}
              </p>
            ))}
          </Reveal>
          <Reveal delay={0.1} className="lg:col-span-5">
            <div className="card-surface rounded-[var(--radius-panel)] p-7">
              <p className="latin text-xs font-semibold uppercase tracking-[0.25em] text-primary">Founder of</p>
              <ul className="mt-6 space-y-3">
                {ventures.map((v) => (
                  <li key={v.id}>
                    <Link
                      href={`/ventures/${v.slug}`}
                      className="group flex items-center gap-4 rounded-2xl p-2 transition-colors hover:bg-surface-2"
                    >
                      <VentureLogo name={v.name} logo={v.logo} accentColor={v.accentColor} size={44} />
                      <span className="min-w-0">
                        <span className="block font-semibold text-foreground group-hover:text-primary">{v.name}</span>
                        <span className="block truncate text-sm text-subtle">{v.tagline ?? v.category}</span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="container-page section-y">
        <SectionHeading eyebrow="Core Pillars" title="محاور العمل" description="ثلاثة محاور تتقاطع في كل مشروع أبنيه." />
        <FocusPillars />
      </section>

      <section className="container-page pb-8">
        <SectionHeading eyebrow="What I Do" title="على ماذا أعمل" />
        <ul className="grid gap-px overflow-hidden rounded-[var(--radius-panel)] border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {focusAreas.map(({ icon: Icon, title, text }, i) => (
            <Reveal as="li" key={title} delay={(i % 3) * 0.06} className="group bg-background p-7 transition-colors hover:bg-surface">
              <Icon className="size-5 text-primary transition-transform duration-500 group-hover:scale-110" />
              <h3 className="mt-5 text-lg font-bold">{title}</h3>
              <p className="mt-2 text-muted">{text}</p>
            </Reveal>
          ))}
        </ul>
      </section>

      <section className="container-page section-y">
        <SectionHeading eyebrow="Principles" title="مبادئ أعمل بها" />
        <ol className="grid gap-5 md:grid-cols-2">
          {principles.map((p, i) => (
            <Reveal as="li" key={p.title} delay={(i % 2) * 0.08}>
              <div className="card-surface flex h-full gap-5 rounded-[var(--radius-card)] p-7">
                <span className="latin text-3xl font-bold text-primary/40">0{i + 1}</span>
                <div>
                  <h3 className="text-lg font-bold">{p.title}</h3>
                  <p className="mt-2 text-muted">{p.text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </ol>
      </section>

      <CTA title="لنبنِ شيئًا يستحق" description="أبحث دائمًا عن شركاء ومشاريع طموحة. إن كانت لديك فكرة أو فرصة، يسعدني أن أسمع عنها." />
    </>
  );
}
