import { ArrowLeft } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeading } from "@/components/shared/section-heading";
import { Reveal } from "@/components/shared/reveal";
import { CTA } from "@/components/shared/cta";
import { EmptyState } from "@/components/shared/states";
import { ServiceCard } from "@/components/services/service-card";
import { ButtonLink } from "@/components/ui/button";
import { buildMetadata } from "@/lib/seo/metadata";
import { getServices } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "الخدمات",
  description: "خدمات أحمد البدر: تطوير الأفكار الرقمية، بناء MVP، حلول الذكاء الاصطناعي، أتمتة الأعمال، تطوير المنصات والأنظمة، واستشارات المنتجات الرقمية.",
  path: "/services",
});

const engagement = [
  { title: "جلسة اكتشاف", text: "نفهم الفكرة والهدف والجمهور والقيود — دون التزام." },
  { title: "خطة واضحة", text: "نطاق عمل، أولويات، جدول زمني وتكلفة شفافة." },
  { title: "بناء على مراحل", text: "تسليمات أسبوعية قابلة للتجربة، وقرارات مشتركة." },
  { title: "إطلاق ونمو", text: "إطلاق، قياس، وتحسين مستمر بعد التسليم." },
];

export default async function ServicesPage() {
  const services = await getServices();
  return (
    <>
      <PageHeader
        eyebrow="Services"
        title="الخدمات"
        description="أشارك خبرتي في بناء المنتجات والمشاريع الرقمية مع رواد الأعمال والشركات — من صياغة الفكرة إلى منتج يعمل ويكبر."
        breadcrumbs={[{ name: "الخدمات", path: "/services" }]}
      >
        <ButtonLink href="/contact?type=NEW_PROJECT" size="lg">
          ابدأ مشروعك
          <ArrowLeft className="size-4 transition-transform duration-300 group-hover/btn:-translate-x-1 ltr:rotate-180" />
        </ButtonLink>
      </PageHeader>

      <section className="container-page pb-8">
        {services.length ? (
          <ul className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service, i) => (
              <Reveal as="li" key={service.id} delay={(i % 3) * 0.08}>
                <ServiceCard service={service} index={i} />
              </Reveal>
            ))}
          </ul>
        ) : (
          <EmptyState title="لا توجد خدمات منشورة حاليًا" />
        )}
      </section>

      <section className="container-page section-y">
        <SectionHeading eyebrow="How We Work" title="كيف نعمل معًا" align="center" />
        <ol className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {engagement.map((step, i) => (
            <Reveal as="li" key={step.title} delay={i * 0.08}>
              <div className="card-surface relative h-full rounded-[var(--radius-card)] p-7">
                <span className="latin grid size-10 place-items-center rounded-full border border-primary/30 text-sm font-bold text-primary">{i + 1}</span>
                <h3 className="mt-5 text-lg font-bold">{step.title}</h3>
                <p className="mt-2 text-muted">{step.text}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </section>

      <CTA title="جاهز لتبدأ؟" description="أخبرني عن فكرتك أو تحديك الحالي، وسأعود إليك بخطوات عملية واضحة." primaryHref="/contact?type=NEW_PROJECT" secondaryLabel="شاهد المشاريع" />
    </>
  );
}
