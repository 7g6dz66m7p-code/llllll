import Link from "next/link";
import { Mail, ShieldCheck } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Reveal } from "@/components/shared/reveal";
import { ButtonLink } from "@/components/ui/button";
import { buildMetadata } from "@/lib/seo/metadata";
import { getSiteSettings } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "سياسة الخصوصية",
  description: "سياسة الخصوصية لموقع أحمد البدر وكيفية التعامل مع بيانات رسائل التواصل والبيانات التقنية الضرورية لتشغيل الموقع وحمايته.",
  path: "/privacy",
});

const sections = [
  {
    title: "البيانات التي قد نجمعها",
    body: "عند استخدام نموذج التواصل قد نجمع الاسم، البريد الإلكتروني، رقم الهاتف إن أضفته، نوع الطلب ونص الرسالة. ولأغراض الحماية من الإساءة قد تُعالج بيانات تقنية محدودة مثل نوع المتصفح ومعرّف مشتق من عنوان الشبكة دون تخزين عنوان IP الخام.",
  },
  {
    title: "كيف نستخدم البيانات",
    body: "تُستخدم البيانات للرد على طلبك، متابعة فرصة تعاون أو مشروع، تشغيل الموقع، منع الرسائل المزعجة وتحسين موثوقية الخدمة. لا تُستخدم بيانات نموذج التواصل للإعلانات السلوكية ولا تُباع كقوائم تسويقية.",
  },
  {
    title: "التخزين ومقدمو الخدمة",
    body: "قد تُخزن البيانات لدى مزودي الاستضافة وقاعدة البيانات والتخزين السحابي الذين نستخدمهم لتشغيل الموقع. يُمنح هؤلاء المزودون الوصول التقني اللازم لتقديم خدماتهم فقط ووفق إعدادات الحسابات المستخدمة لتشغيل الموقع.",
  },
  {
    title: "الاحتفاظ بالبيانات",
    body: "قد نحتفظ برسائل التواصل بالمدة اللازمة لمتابعة الطلبات، حفظ سجل الأعمال، الحماية من إساءة الاستخدام أو الوفاء بمتطلبات تشغيلية مشروعة. يمكنك طلب حذف رسالة أو تصحيح بياناتها عبر وسيلة التواصل الرسمية المتاحة أدناه.",
  },
  {
    title: "ملفات الارتباط والتخزين المحلي",
    body: "يستخدم الموقع ما يلزم لتشغيل جلسة الإدارة وتفضيلات الواجهة مثل المظهر. لا يتضمن الإصدار الافتراضي أدوات إعلانية أو تتبعًا تسويقيًا من جهات خارجية ما لم تتم إضافتها لاحقًا مع تحديث هذه السياسة عند الحاجة.",
  },
  {
    title: "الروابط الخارجية",
    body: "قد يحتوي الموقع على روابط لمشاريع أو منصات خارجية. لكل خدمة خارجية سياسة خصوصية وشروط مستقلة، ولا تمتد هذه السياسة تلقائيًا إلى المواقع التي تغادر إليها عبر تلك الروابط.",
  },
];

export default async function PrivacyPage() {
  const settings = await getSiteSettings();
  return (
    <>
      <PageHeader
        eyebrow="Privacy"
        title="سياسة الخصوصية"
        description="توضّح هذه الصفحة ما الذي يحدث لبياناتك عند استخدام الموقع أو إرسال رسالة عبر نموذج التواصل."
        breadcrumbs={[{ name: "سياسة الخصوصية", path: "/privacy" }]}
      >
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-4 py-2 text-sm text-muted">
          <ShieldCheck className="size-4 text-primary" />
          آخر تحديث: 3 أكتوبر 2026
        </span>
      </PageHeader>

      <section className="container-page pb-24">
        <div className="mx-auto max-w-4xl space-y-5">
          {sections.map((section, index) => (
            <Reveal key={section.title} delay={(index % 3) * 0.04}>
              <article className="card-surface rounded-[var(--radius-card)] p-6 sm:p-8">
                <h2 className="text-xl font-bold">{section.title}</h2>
                <p className="mt-3 leading-8 text-muted">{section.body}</p>
              </article>
            </Reveal>
          ))}

          <Reveal>
            <article className="rounded-[var(--radius-card)] border border-primary/25 bg-primary/5 p-6 sm:p-8">
              <h2 className="text-xl font-bold">طلبات الخصوصية والتواصل</h2>
              <p className="mt-3 leading-8 text-muted">
                لطلب تصحيح أو حذف بيانات أرسلتها عبر الموقع، استخدم صفحة التواصل أو البريد الرسمي إن كان ظاهرًا في الموقع.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <ButtonLink href="/contact" size="sm">
                  <Mail className="size-4" />
                  تواصل معي
                </ButtonLink>
                <Link href="/terms" className="inline-flex items-center rounded-full px-4 py-2 text-sm font-medium text-muted transition-colors hover:text-primary">
                  شروط الاستخدام
                </Link>
                {settings.contactEmail && (
                  <a href={`mailto:${settings.contactEmail}`} className="latin inline-flex items-center rounded-full px-4 py-2 text-sm font-medium text-muted transition-colors hover:text-primary" dir="ltr">
                    {settings.contactEmail}
                  </a>
                )}
              </div>
            </article>
          </Reveal>
        </div>
      </section>
    </>
  );
}
