import { PageHeader } from "@/components/shared/page-header";
import { CTA } from "@/components/shared/cta";
import { InsightsBrowser } from "@/components/insights/insights-browser";
import { buildMetadata } from "@/lib/seo/metadata";
import { getInsights } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "أفكار ورؤى",
  description: "مقالات أحمد البدر عن الذكاء الاصطناعي، ريادة الأعمال، SaaS، بناء المنتجات، التجارة الرقمية والسوق العراقي والعربي.",
  path: "/insights",
});

export default async function InsightsPage() {
  const insights = await getInsights();
  return (
    <>
      <PageHeader
        eyebrow="Insights"
        title="أفكار ورؤى"
        description="ملاحظات عملية من رحلة بناء المنتجات والمشاريع — عن الذكاء الاصطناعي، ريادة الأعمال، والسوق العربي."
        breadcrumbs={[{ name: "أفكار ورؤى", path: "/insights" }]}
      />
      <section className="container-page pb-12">
        <InsightsBrowser insights={insights} />
      </section>
      <CTA title="هل لديك سؤال أو فكرة للنقاش؟" primaryLabel="راسلني" secondaryLabel="استكشف المشاريع" />
    </>
  );
}
