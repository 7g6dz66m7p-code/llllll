import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Clock } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Markdown } from "@/components/shared/markdown";
import { SectionHeading } from "@/components/shared/section-heading";
import { CTA } from "@/components/shared/cta";
import { InsightCard } from "@/components/insights/insight-card";
import { Badge } from "@/components/ui/badge";
import { t } from "@/lib/i18n";
import { buildMetadata } from "@/lib/seo/metadata";
import { JsonLd, articleSchema } from "@/lib/seo/json-ld";
import { formatDate, readingTime } from "@/lib/utils";
import { getInsightBySlug, getInsights } from "@/services/content";

export const revalidate = 300;

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const insights = await getInsights();
  return insights.map((i) => ({ slug: i.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const insight = await getInsightBySlug(decodeURIComponent(slug));
  if (!insight) return { title: t.states.notFoundTitle, robots: { index: false } };
  return buildMetadata({
    title: insight.seoTitle ?? insight.title,
    description: insight.metaDescription ?? insight.excerpt,
    path: `/insights/${insight.slug}`,
    image: insight.coverImage,
    type: "article",
    publishedTime: insight.publishedAt?.toISOString(),
    modifiedTime: insight.updatedAt.toISOString(),
    keywords: [insight.category],
  });
}

export default async function InsightPage({ params }: Props) {
  const { slug } = await params;
  const insight = await getInsightBySlug(decodeURIComponent(slug));
  if (!insight) notFound();

  const all = await getInsights();
  const related = all
    .filter((i) => i.id !== insight.id)
    .sort((a, b) => Number(b.category === insight.category) - Number(a.category === insight.category))
    .slice(0, 3);

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { name: "أفكار ورؤى", path: "/insights" },
          { name: insight.title, path: `/insights/${insight.slug}` },
        ]}
        title={insight.title}
        description={insight.excerpt}
      >
        <div className="flex flex-wrap items-center gap-4 text-sm text-subtle">
          <Badge tone="primary">{insight.category}</Badge>
          {insight.publishedAt && <time dateTime={insight.publishedAt.toISOString()}>{formatDate(insight.publishedAt)}</time>}
          <span className="inline-flex items-center gap-1.5">
            <Clock className="size-4" />
            {t.common.minutesRead(readingTime(insight.content))}
          </span>
        </div>
      </PageHeader>

      <article className="container-page pb-12">
        {insight.coverImage && (
          <div className="relative mx-auto mb-14 aspect-[21/9] max-w-5xl overflow-hidden rounded-[var(--radius-panel)] border border-border">
            <Image src={insight.coverImage} alt="" fill priority sizes="(min-width: 1024px) 64rem, 100vw" className="object-cover" />
          </div>
        )}
        <div className="mx-auto max-w-3xl">
          <Markdown content={insight.content} />
          <div className="mt-14 flex items-center justify-between border-t border-border pt-8">
            <Link href="/insights" className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline">
              <ArrowRight className="size-4 ltr:rotate-180" />
              كل المقالات
            </Link>
            <span className="text-sm text-subtle">{t.brand.name}</span>
          </div>
        </div>
      </article>

      {related.length > 0 && (
        <section className="container-page section-y">
          <SectionHeading eyebrow="Keep Reading" title="مقالات أخرى" />
          <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {related.map((i) => (
              <li key={i.id}>
                <InsightCard insight={i} />
              </li>
            ))}
          </ul>
        </section>
      )}

      <CTA />
      <JsonLd data={articleSchema(insight)} />
    </>
  );
}
