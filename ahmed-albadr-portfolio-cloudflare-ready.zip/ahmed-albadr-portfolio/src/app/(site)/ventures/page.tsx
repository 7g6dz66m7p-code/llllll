import { PageHeader } from "@/components/shared/page-header";
import { CTA } from "@/components/shared/cta";
import { VentureGrid } from "@/components/ventures/venture-grid";
import { t } from "@/lib/i18n";
import { buildMetadata } from "@/lib/seo/metadata";
import { getVentures } from "@/services/content";
import { VENTURE_STATUSES } from "@/types/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "المشاريع",
  description: "مشاريع أحمد البدر الرقمية: مهارة، منصة باحث، SALEEM AI ونظم العراق — منتجات ذكاء اصطناعي ومنصات وأنظمة أعمال.",
  path: "/ventures",
});

export default async function VenturesPage() {
  const ventures = await getVentures();
  const counts = VENTURE_STATUSES.map((s) => ({ status: s, count: ventures.filter((v) => v.status === s).length })).filter((c) => c.count);

  return (
    <>
      <PageHeader
        eyebrow="Ventures"
        title="المشاريع"
        description="منتجات وأنظمة رقمية أؤسسها وأبنيها — كل مشروع يبدأ من مشكلة حقيقية ويُصمم ليتحول إلى عمل قابل للنمو."
        breadcrumbs={[{ name: "المشاريع", path: "/ventures" }]}
      >
        <ul className="flex flex-wrap gap-3 text-sm">
          <li className="glass rounded-full px-4 py-1.5">
            <span className="latin font-bold text-foreground">{ventures.length}</span> <span className="text-muted">مشاريع</span>
          </li>
          {counts.map(({ status, count }) => (
            <li key={status} className="glass rounded-full px-4 py-1.5">
              <span className="latin font-bold text-primary">{count}</span> <span className="text-muted">{t.ventureStatus[status]}</span>
            </li>
          ))}
        </ul>
      </PageHeader>
      <section className="container-page pb-12">
        <VentureGrid ventures={ventures} highlightFirst />
      </section>
      <CTA title="لديك فكرة مشروع؟" description="أعمل أيضًا مع رواد أعمال وشركات لتحويل أفكارهم إلى منتجات رقمية ناجحة." />
    </>
  );
}
