import type { Metadata } from "next";
import Image from "next/image";
import { notFound } from "next/navigation";
import { ArrowUpLeft, CalendarDays, CheckCircle2, Layers3, Sparkles, Target, Users } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeading } from "@/components/shared/section-heading";
import { Reveal } from "@/components/shared/reveal";
import { Markdown } from "@/components/shared/markdown";
import { CTA } from "@/components/shared/cta";
import { GithubIcon } from "@/components/shared/brand-icons";
import { VentureCard } from "@/components/ventures/venture-card";
import { VentureCover } from "@/components/ventures/venture-cover";
import { VentureLogo } from "@/components/ventures/venture-logo";
import { Badge } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { t } from "@/lib/i18n";
import { buildMetadata } from "@/lib/seo/metadata";
import { JsonLd, ventureSchema } from "@/lib/seo/json-ld";
import { formatDate } from "@/lib/utils";
import { getRelatedVentures, getVentureBySlug, getVentures } from "@/services/content";

export const revalidate = 300;

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  const ventures = await getVentures();
  return ventures.map((v) => ({ slug: v.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const venture = await getVentureBySlug(decodeURIComponent(slug));
  if (!venture) return { title: t.states.notFoundTitle, robots: { index: false } };
  return buildMetadata({
    title: venture.nameEn && venture.nameEn !== venture.name ? `${venture.name} — ${venture.nameEn}` : venture.name,
    description: venture.shortDescription,
    path: `/ventures/${venture.slug}`,
    image: venture.coverImage ?? venture.logo,
    keywords: [venture.name, ...(venture.nameEn ? [venture.nameEn] : []), venture.category, ...venture.technologies],
  });
}

export default async function VenturePage({ params }: Props) {
  const { slug } = await params;
  const venture = await getVentureBySlug(decodeURIComponent(slug));
  if (!venture) notFound();
  const related = await getRelatedVentures(venture.slug, 3);

  const facts = [
    { icon: Sparkles, label: "الحالة", value: <StatusBadge status={venture.status} /> },
    { icon: Layers3, label: "التصنيف", value: <span className="latin">{venture.category}</span> },
    ...(venture.launchedAt ? [{ icon: CalendarDays, label: "تاريخ الإطلاق", value: formatDate(venture.launchedAt) }] : []),
  ];

  return (
    <>
      <PageHeader
        breadcrumbs={[
          { name: "المشاريع", path: "/ventures" },
          { name: venture.name, path: `/ventures/${venture.slug}` },
        ]}
        title={
          <span className="flex flex-wrap items-center gap-5">
            <VentureLogo name={venture.name} logo={venture.logo} accentColor={venture.accentColor} size={68} className="shadow-2xl" />
            <span>
              {venture.name}
              {venture.nameEn && venture.nameEn !== venture.name && (
                <span className="latin mt-2 block text-base font-semibold tracking-[0.2em] text-subtle">{venture.nameEn.toUpperCase()}</span>
              )}
            </span>
          </span>
        }
        description={venture.tagline ? <><span className="text-foreground">{venture.tagline}.</span> {venture.shortDescription}</> : venture.shortDescription}
      >
        <div className="flex flex-wrap items-center gap-3">
          {venture.websiteUrl && (
            <ButtonLink href={venture.websiteUrl} external size="lg">
              {t.common.visitWebsite}
              <ArrowUpLeft className="size-4 ltr:-scale-x-100" />
            </ButtonLink>
          )}
          {venture.githubUrl && (
            <ButtonLink href={venture.githubUrl} external size="lg" variant="secondary">
              <GithubIcon className="size-4" />
              {t.common.sourceCode}
            </ButtonLink>
          )}
          <ButtonLink href={`/contact?type=PARTNERSHIP&venture=${encodeURIComponent(venture.slug)}`} size="lg" variant={venture.websiteUrl ? "outline" : "primary"}>
            تواصل بخصوص المشروع
          </ButtonLink>
        </div>
      </PageHeader>

      <section className="container-page">
        <Reveal>
          <div className="group overflow-hidden rounded-[var(--radius-panel)] border border-border shadow-[0_40px_120px_-50px_rgb(var(--glow)/0.5)]">
            <VentureCover venture={venture} priority className="aspect-[21/9] min-h-64 w-full" sizes="(min-width: 1280px) 1200px, 100vw" />
          </div>
        </Reveal>
      </section>

      <section className="container-page section-y">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <Reveal>
              <h2 className="mb-6 text-2xl font-bold">عن المشروع</h2>
              <Markdown content={venture.fullDescription} />
            </Reveal>
          </div>
          <aside className="lg:col-span-4">
            <Reveal delay={0.1} className="card-surface sticky top-28 rounded-[var(--radius-card)] p-6">
              <dl className="divide-y divide-border">
                {facts.map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex items-center justify-between gap-4 py-4 first:pt-0">
                    <dt className="flex items-center gap-2 text-sm text-muted">
                      <Icon className="size-4 text-primary" />
                      {label}
                    </dt>
                    <dd className="text-sm font-medium text-foreground">{value}</dd>
                  </div>
                ))}
              </dl>
              {venture.technologies.length > 0 && (
                <div className="border-t border-border pt-5">
                  <p className="mb-3 text-sm text-muted">التقنيات</p>
                  <ul className="flex flex-wrap gap-2">
                    {venture.technologies.map((tech) => (
                      <li key={tech}>
                        <Badge className="latin">{tech}</Badge>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </Reveal>
          </aside>
        </div>
      </section>

      {(venture.problem || venture.solution) && (
        <section className="container-page pb-8">
          <div className="grid gap-5 md:grid-cols-2">
            {venture.problem && (
              <Reveal className="card-surface h-full rounded-[var(--radius-card)] p-8">
                <span className="mb-6 grid size-12 place-items-center rounded-2xl bg-warning/10 text-warning">
                  <Target className="size-5" />
                </span>
                <p className="latin text-xs font-semibold uppercase tracking-[0.25em] text-subtle">The Problem</p>
                <h2 className="mt-2 text-2xl font-bold">المشكلة</h2>
                <p className="mt-4 leading-8 text-muted">{venture.problem}</p>
              </Reveal>
            )}
            {venture.solution && (
              <Reveal delay={0.08} className="relative h-full overflow-hidden rounded-[var(--radius-card)] border border-primary/25 bg-gradient-to-br from-primary/10 via-surface to-surface p-8">
                <span className="mb-6 grid size-12 place-items-center rounded-2xl bg-primary/15 text-primary">
                  <CheckCircle2 className="size-5" />
                </span>
                <p className="latin text-xs font-semibold uppercase tracking-[0.25em] text-primary">The Solution</p>
                <h2 className="mt-2 text-2xl font-bold">الحل</h2>
                <p className="mt-4 leading-8 text-muted">{venture.solution}</p>
              </Reveal>
            )}
          </div>
        </section>
      )}

      {venture.features.length > 0 && (
        <section className="container-page section-y">
          <SectionHeading eyebrow="Key Features" title="المميزات الرئيسية" />
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {venture.features.map((f, i) => (
              <Reveal as="li" key={f.title} delay={(i % 3) * 0.06}>
                <div className="group card-surface h-full rounded-[var(--radius-card)] p-7 transition-all duration-500 hover:-translate-y-1 hover:border-primary/25">
                  <span className="latin text-sm font-bold text-primary">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="mt-4 text-lg font-bold">{f.title}</h3>
                  {f.description && <p className="mt-2 text-muted">{f.description}</p>}
                </div>
              </Reveal>
            ))}
          </ul>
        </section>
      )}

      {venture.targetAudience.length > 0 && (
        <section className="container-page pb-8">
          <Reveal className="card-surface flex flex-col gap-6 rounded-[var(--radius-panel)] p-8 md:flex-row md:items-center md:p-10">
            <div className="flex items-center gap-4 md:w-72 md:shrink-0">
              <span className="grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary">
                <Users className="size-5" />
              </span>
              <div>
                <p className="latin text-xs font-semibold uppercase tracking-[0.25em] text-subtle">Audience</p>
                <h2 className="text-xl font-bold">الجمهور المستهدف</h2>
              </div>
            </div>
            <ul className="flex flex-wrap gap-2.5">
              {venture.targetAudience.map((a) => (
                <li key={a} className="rounded-full border border-border bg-surface-2/60 px-4 py-2 text-sm text-foreground">
                  {a}
                </li>
              ))}
            </ul>
          </Reveal>
        </section>
      )}

      {venture.screenshots.length > 0 && (
        <section className="container-page section-y">
          <SectionHeading eyebrow="Screenshots" title="لقطات من المنتج" />
          <ul className="grid gap-5 md:grid-cols-2">
            {venture.screenshots.map((src, i) => (
              <Reveal as="li" key={src} delay={(i % 2) * 0.08}>
                <div className="relative aspect-[16/10] overflow-hidden rounded-[var(--radius-card)] border border-border bg-surface-2">
                  <Image src={src} alt={`لقطة شاشة ${i + 1} من ${venture.name}`} fill sizes="(min-width: 768px) 50vw, 100vw" className="object-cover" />
                </div>
              </Reveal>
            ))}
          </ul>
        </section>
      )}

      {related.length > 0 && (
        <section className="container-page section-y">
          <SectionHeading eyebrow="More Ventures" title="مشاريع أخرى" />
          <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {related.map((v, i) => (
              <Reveal as="li" key={v.id} delay={i * 0.08}>
                <VentureCard venture={v} />
              </Reveal>
            ))}
          </ul>
        </section>
      )}

      <CTA />
      <JsonLd data={ventureSchema(venture)} />
    </>
  );
}
