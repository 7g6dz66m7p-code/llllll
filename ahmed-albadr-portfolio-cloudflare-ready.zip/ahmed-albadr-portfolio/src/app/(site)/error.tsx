"use client";

import { useEffect } from "react";
import { ErrorState } from "@/components/shared/states";

export default function SiteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("[site.error]", error.digest ?? error.message);
  }, [error]);
  return (
    <div className="container-page pt-40 pb-24">
      <ErrorState onRetry={reset} />
    </div>
  );
}
