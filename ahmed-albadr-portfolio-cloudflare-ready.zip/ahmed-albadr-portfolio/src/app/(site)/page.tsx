import { ArrowLeft } from "lucide-react";
import { Hero } from "@/components/home/hero";
import { Stats } from "@/components/home/stats";
import { FocusPillars } from "@/components/home/focus-pillars";
import { VisionProcess } from "@/components/home/vision-process";
import { AchievementTimeline } from "@/components/home/achievement-timeline";
import { VentureGrid } from "@/components/ventures/venture-grid";
import { ServiceCard } from "@/components/services/service-card";
import { InsightCard } from "@/components/insights/insight-card";
import { SectionHeading } from "@/components/shared/section-heading";
import { Reveal } from "@/components/shared/reveal";
import { CTA } from "@/components/shared/cta";
import { ButtonLink } from "@/components/ui/button";
import {
  getAchievements,
  getFeaturedVentures,
  getInsights,
  getServices,
  getSiteSettings,
  getStats,
} from "@/services/content";

export const revalidate = 300;

function ViewAll({ href, label = "عرض الكل" }: { href: string; label?: string }) {
  return (
    <ButtonLink href={href} variant="outline" size="sm">
      {label}
      <ArrowLeft className="size-4 transition-transform duration-300 group-hover/btn:-translate-x-0.5 ltr:rotate-180" />
    </ButtonLink>
  );
}

export default async function HomePage() {
  const [settings, stats, ventures, services, achievements, insights] = await Promise.all([
    getSiteSettings(),
    getStats(),
    getFeaturedVentures(4),
    getServices(),
    getAchievements(),
    getInsights(),
  ]);

  return (
    <>
      <Hero settings={settings} />
      <Stats stats={stats} />

      <section id="ventures" className="container-page section-y" aria-labelledby="ventures-heading">
        <SectionHeading
          eyebrow="Ventures"
          title={<span id="ventures-heading">مشاريع أبنيها اليوم</span>}
          description="منتجات وأنظمة رقمية في مراحل مختلفة من رحلتها — من الفكرة إلى السوق. كل مشروع يحل مشكلة حقيقية ومصمم ليكبر."
          action={<ViewAll href="/ventures" label="كل المشاريع" />}
        />
        <VentureGrid ventures={ventures} highlightFirst />
      </section>

      <section className="relative section-y" aria-labelledby="focus-heading">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-surface/40 to-transparent" aria-hidden />
        <div className="container-page">
          <SectionHeading
            eyebrow="Focus"
            title={<span id="focus-heading">ثلاثة محاور تقود كل ما أبنيه</span>}
            description="أجمع بين عقلية رائد الأعمال وأدوات الذكاء الاصطناعي وحرفية بناء المنتجات — لأن المنتج الناجح يحتاج الثلاثة معًا."
            action={<ViewAll href="/about" label="تعرّف عليّ" />}
          />
          <FocusPillars />
        </div>
      </section>

      <section className="container-page section-y" aria-labelledby="services-heading">
        <SectionHeading
          eyebrow="Services"
          title={<span id="services-heading">كيف يمكنني مساعدتك؟</span>}
          description="من صياغة الفكرة إلى إطلاق المنتج وتوسيعه — شراكة عملية تركّز على النتائج."
          action={<ViewAll href="/services" label="كل الخدمات" />}
        />
        <ul className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {services.slice(0, 6).map((service, i) => (
            <Reveal as="li" key={service.id} delay={(i % 3) * 0.08}>
              <ServiceCard service={service} index={i} compact />
            </Reveal>
          ))}
        </ul>
      </section>

      <section className="relative section-y overflow-hidden" aria-labelledby="vision-heading">
        <div className="bg-grid mask-radial pointer-events-none absolute inset-0 -z-10 opacity-60" aria-hidden />
        <div className="container-page">
          <SectionHeading
            align="center"
            eyebrow="Vision"
            title={<span id="vision-heading">رؤيتي</span>}
            description={<span className="text-xl text-foreground/90 md:text-2xl">{settings.visionStatement}</span>}
          />
          <VisionProcess />
          <div className="mt-12 text-center">
            <ViewAll href="/vision" label="اقرأ الرؤية كاملة" />
          </div>
        </div>
      </section>

      <section className="container-page section-y" aria-labelledby="milestones-heading">
        <SectionHeading
          eyebrow="Milestones"
          title={<span id="milestones-heading">محطات الرحلة</span>}
          description="إطلاقات ومراحل فارقة في بناء المشاريع."
          action={<ViewAll href="/achievements" />}
        />
        <AchievementTimeline achievements={achievements} limit={4} />
      </section>

      {insights.length > 0 && (
        <section className="container-page section-y" aria-labelledby="insights-heading">
          <SectionHeading
            eyebrow="Insights"
            title={<span id="insights-heading">أفكار ورؤى</span>}
            description="كتابات عن الذكاء الاصطناعي، ريادة الأعمال، وبناء المنتجات في السوق العربي."
            action={<ViewAll href="/insights" label="كل المقالات" />}
          />
          <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {insights.slice(0, 3).map((insight, i) => (
              <Reveal as="li" key={insight.id} delay={i * 0.08}>
                <InsightCard insight={insight} />
              </Reveal>
            ))}
          </ul>
        </section>
      )}

      <CTA />
    </>
  );
}
