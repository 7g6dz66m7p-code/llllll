import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { t } from "@/lib/i18n";
import { JsonLd, personSchema, websiteSchema } from "@/lib/seo/json-ld";
import { getSiteSettings, getSocialLinks, getVentures } from "@/services/content";
import type { Metadata } from "next";

export async function generateMetadata(): Promise<Metadata> {
  const settings = await getSiteSettings();
  return {
    description: settings.seoDescription,
    ...(settings.ogImage && { openGraph: { images: [{ url: settings.ogImage, width: 1200, height: 630 }] } }),
  };
}

export default async function SiteLayout({ children }: { children: React.ReactNode }) {
  const [ventures, socialLinks, settings] = await Promise.all([getVentures(), getSocialLinks(), getSiteSettings()]);
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:start-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-fg"
      >
        {t.nav.skipToContent}
      </a>
      <Navbar />
      <main id="main" className="relative min-h-dvh overflow-x-clip">
        {children}
      </main>
      <Footer ventures={ventures} socialLinks={socialLinks} email={settings.contactEmail} />
      <JsonLd
        data={[personSchema({ description: settings.seoDescription, image: settings.heroImage, socialLinks }), websiteSchema()]}
      />
    </>
  );
}
