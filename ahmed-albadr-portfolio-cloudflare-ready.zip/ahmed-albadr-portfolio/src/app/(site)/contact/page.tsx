import { Suspense } from "react";
import { Clock, DatabaseZap, Mail, MapPin, MessageCircle } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { ContactForm } from "@/components/shared/contact-form";
import { SocialLinks } from "@/components/shared/social-links";
import { Reveal } from "@/components/shared/reveal";
import { LoadingState } from "@/components/shared/states";
import { isDatabaseConfigured } from "@/lib/env";
import { buildMetadata } from "@/lib/seo/metadata";
import { getSiteSettings, getSocialLinks } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "تواصل",
  description: "تواصل مع أحمد البدر بخصوص الشراكات، المشاريع الجديدة، الاستثمار أو الاستشارات في المنتجات الرقمية والذكاء الاصطناعي.",
  path: "/contact",
});

export default async function ContactPage() {
  const [settings, socialLinks] = await Promise.all([getSiteSettings(), getSocialLinks()]);
  const contactFormReady = isDatabaseConfigured();
  const whatsappDigits = settings.whatsappNumber?.replace(/\D/g, "");

  const channels = [
    settings.contactEmail && { icon: Mail, label: "البريد الإلكتروني", value: settings.contactEmail, href: `mailto:${settings.contactEmail}`, ltr: true },
    whatsappDigits && { icon: MessageCircle, label: "واتساب", value: `+${whatsappDigits}`, href: `https://wa.me/${whatsappDigits}`, ltr: true },
    settings.location && { icon: MapPin, label: "الموقع", value: settings.location },
    { icon: Clock, label: "وقت الرد", value: "خلال 24–48 ساعة عمل" },
  ].filter(Boolean) as { icon: typeof Mail; label: string; value: string; href?: string; ltr?: boolean }[];

  return (
    <>
      <PageHeader
        eyebrow="Contact"
        title="لنتحدث عن فكرتك"
        description="شراكة، مشروع جديد، استثمار أو استشارة — اكتب لي وسأعود إليك بأقرب وقت."
        breadcrumbs={[{ name: "تواصل", path: "/contact" }]}
      />
      <section className="container-page pb-24">
        <div className="grid gap-8 lg:grid-cols-12">
          <Reveal className="lg:col-span-7">
            <div className="card-surface relative rounded-[var(--radius-panel)] p-6 sm:p-10">
              <h2 className="mb-8 text-2xl font-bold">أرسل رسالة</h2>
              {contactFormReady ? (
                <Suspense fallback={<LoadingState variant="list" count={4} />}>
                  <ContactForm />
                </Suspense>
              ) : (
                <div className="rounded-2xl border border-warning/30 bg-warning/5 p-5" role="status">
                  <div className="flex items-start gap-4">
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-warning/10 text-warning">
                      <DatabaseZap className="size-5" />
                    </span>
                    <div>
                      <h3 className="font-semibold text-foreground">الإرسال المباشر غير مفعّل بعد</h3>
                      <p className="mt-1 leading-7 text-muted">
                        نموذج التواصل يحتاج ربط قاعدة البيانات. يمكنك استخدام البريد الإلكتروني أو واتساب من بيانات التواصل في هذه الصفحة إلى أن يكتمل الربط.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Reveal>
          <Reveal delay={0.1} className="space-y-6 lg:col-span-5">
            <ul className="card-surface divide-y divide-border rounded-[var(--radius-panel)] p-2">
              {channels.map(({ icon: Icon, label, value, href, ltr }) => {
                const content = (
                  <>
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                      <Icon className="size-5" />
                    </span>
                    <span>
                      <span className="block text-xs text-subtle">{label}</span>
                      <span className={ltr ? "latin block font-medium" : "block font-medium"} dir={ltr ? "ltr" : undefined}>
                        {value}
                      </span>
                    </span>
                  </>
                );
                return (
                  <li key={label}>
                    {href ? (
                      <a href={href} {...(href.startsWith("http") && { target: "_blank", rel: "noopener noreferrer" })} className="flex items-center gap-4 rounded-2xl p-4 transition-colors hover:bg-surface-2">
                        {content}
                      </a>
                    ) : (
                      <div className="flex items-center gap-4 p-4">{content}</div>
                    )}
                  </li>
                );
              })}
            </ul>
            {socialLinks.length > 0 && (
              <div className="card-surface rounded-[var(--radius-panel)] p-6">
                <h2 className="mb-5 text-sm font-semibold text-muted">تابعني على</h2>
                <SocialLinks links={socialLinks} variant="buttons" />
              </div>
            )}
          </Reveal>
        </div>
      </section>
    </>
  );
}
