import { Compass, Globe2, HeartHandshake, ShieldCheck } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { SectionHeading } from "@/components/shared/section-heading";
import { Reveal } from "@/components/shared/reveal";
import { CTA } from "@/components/shared/cta";
import { VisionProcess } from "@/components/home/vision-process";
import { buildMetadata } from "@/lib/seo/metadata";
import { getSiteSettings } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "رؤيتي",
  description: "رؤية أحمد البدر: بناء منتجات تقنية عربية تحل مشكلات حقيقية وتتحول إلى أعمال قابلة للتوسع — ومنهج تطوير المشروع من الفكرة إلى التوسع.",
  path: "/vision",
});

const commitments = [
  { icon: Compass, title: "مشكلات حقيقية", text: "كل منتج يبدأ من ألم واضح في السوق، لا من رغبة في استخدام تقنية جديدة." },
  { icon: Globe2, title: "هوية عربية، معايير عالمية", text: "تجربة تحترم لغة المستخدم وثقافته، وجودة تنافس أفضل المنتجات العالمية." },
  { icon: ShieldCheck, title: "ثقة وحوكمة", text: "خصوصية البيانات، وضوح التسعير، وموافقة بشرية قبل أي إجراء حساس." },
  { icon: HeartHandshake, title: "قيمة مستدامة", text: "أعمال تكبر لأنها مفيدة لعملائها، لا لأنها تحرق المال على النمو." },
];

export default async function VisionPage() {
  const settings = await getSiteSettings();
  return (
    <>
      <PageHeader
        eyebrow="Vision"
        title="رؤيتي"
        description={<span className="text-xl text-foreground/90 md:text-2xl md:leading-[1.8]">{settings.visionStatement}</span>}
        breadcrumbs={[{ name: "الرؤية", path: "/vision" }]}
      />

      <section className="relative section-y overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-surface/50 to-transparent" aria-hidden />
        <div className="container-page">
          <SectionHeading
            align="center"
            eyebrow="Venture Process"
            title={<span dir="ltr" className="latin">Idea → Validation → Product → Launch → Growth → Scale</span>}
            description="المنهج الذي أتبعه في كل مشروع: مراحل واضحة، ولكل مرحلة سؤال يجب أن نجيب عنه قبل الانتقال إلى التالية."
          />
          <VisionProcess />
        </div>
      </section>

      <section className="container-page section-y">
        <SectionHeading eyebrow="Commitments" title="ما الذي أبنيه ولماذا" />
        <ul className="grid gap-5 sm:grid-cols-2">
          {commitments.map(({ icon: Icon, title, text }, i) => (
            <Reveal as="li" key={title} delay={(i % 2) * 0.08}>
              <div className="group card-surface flex h-full gap-5 rounded-[var(--radius-card)] p-7 transition-colors hover:border-primary/25">
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary">
                  <Icon className="size-5" />
                </span>
                <div>
                  <h3 className="text-lg font-bold">{title}</h3>
                  <p className="mt-2 text-muted">{text}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </ul>
      </section>

      <CTA title="شاركني الرؤية" description="إن كنت تؤمن بأن المنطقة تستحق منتجات تقنية أفضل، فلنتحدث عن كيف نبنيها معًا." primaryLabel="تواصل معي" />
    </>
  );
}
