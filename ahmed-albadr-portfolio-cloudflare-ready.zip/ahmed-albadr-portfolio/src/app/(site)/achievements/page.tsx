import { PageHeader } from "@/components/shared/page-header";
import { CTA } from "@/components/shared/cta";
import { AchievementTimeline } from "@/components/home/achievement-timeline";
import { buildMetadata } from "@/lib/seo/metadata";
import { getAchievements } from "@/services/content";

export const revalidate = 300;

export const metadata = buildMetadata({
  title: "الإنجازات",
  description: "محطات أحمد البدر في ريادة الأعمال: إطلاق منصة مهارة، تطوير SALEEM AI، إطلاق حلول نظم العراق وتطوير منصة باحث.",
  path: "/achievements",
});

export default async function AchievementsPage() {
  const achievements = await getAchievements();
  return (
    <>
      <PageHeader
        eyebrow="Business Milestones"
        title="الإنجازات"
        description="محطات فارقة في رحلة بناء المشاريع: إطلاقات، منتجات جديدة، وخطوات نمو."
        breadcrumbs={[{ name: "الإنجازات", path: "/achievements" }]}
      />
      <section className="container-page pb-12">
        <AchievementTimeline achievements={achievements} />
      </section>
      <CTA />
    </>
  );
}
