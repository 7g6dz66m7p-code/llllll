import Link from "next/link";
import { FileCheck2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { Reveal } from "@/components/shared/reveal";
import { ButtonLink } from "@/components/ui/button";
import { buildMetadata } from "@/lib/seo/metadata";

export const metadata = buildMetadata({
  title: "شروط الاستخدام",
  description: "شروط استخدام موقع أحمد البدر والمحتوى المنشور فيه وخدمات التواصل وعرض المشاريع الرقمية.",
  path: "/terms",
});

const sections = [
  {
    title: "طبيعة الموقع",
    body: "هذا موقع شخصي ومهني لعرض المشاريع والخدمات والرؤى وفتح قنوات التواصل. المعلومات المنشورة فيه تعريفية ولا تمثل بحد ذاتها عقدًا أو التزامًا بتنفيذ خدمة ما ما لم يتم الاتفاق عليها بصورة مستقلة وواضحة.",
  },
  {
    title: "الاستخدام المقبول",
    body: "يجب استخدام الموقع بصورة مشروعة ومن دون محاولة تعطيله، تجاوز آليات الحماية، إرسال محتوى ضار أو آلي على نحو مسيء، أو استخدام نماذج التواصل للإزعاج أو الاحتيال.",
  },
  {
    title: "المحتوى والملكية الفكرية",
    body: "ما لم يُذكر خلاف ذلك، تصميم الموقع ونصوصه الأصلية وعناصر الهوية والمحتوى المنشور فيه مخصصة لصاحب الموقع. لا يمنح تصفح الموقع ترخيصًا لإعادة بيع المحتوى أو نسبه إلى جهة أخرى. قد تحمل أسماء وشعارات المشاريع المعروضة حقوقًا أو شروطًا مستقلة.",
  },
  {
    title: "المشاريع والروابط الخارجية",
    body: "قد تقود بعض الروابط إلى منتجات أو خدمات أو مستودعات خارج هذا الموقع. توفر تلك الجهات خدماتها وفق شروطها الخاصة، وقد تتغير حالة مشروع أو رابط أو ميزة مع تطور المنتج.",
  },
  {
    title: "التواصل والخدمات",
    body: "إرسال طلب عبر الموقع لا يضمن قبول المشروع أو الشراكة ولا ينشئ التزامًا ماليًا. أي نطاق عمل أو سعر أو مدة تنفيذ أو التزامات متبادلة تُحدد لاحقًا في اتفاق واضح بين الأطراف المعنية.",
  },
  {
    title: "تحديث الشروط",
    body: "قد تتغير هذه الشروط مع إضافة ميزات أو خدمات جديدة. يظهر تاريخ آخر تحديث في هذه الصفحة، ويصبح الإصدار المنشور هو المرجع للاستخدام اللاحق للموقع.",
  },
];

export default function TermsPage() {
  return (
    <>
      <PageHeader
        eyebrow="Terms"
        title="شروط الاستخدام"
        description="قواعد واضحة وبسيطة لاستخدام الموقع والتعامل مع المحتوى والروابط وطلبات التواصل."
        breadcrumbs={[{ name: "شروط الاستخدام", path: "/terms" }]}
      >
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-surface/70 px-4 py-2 text-sm text-muted">
          <FileCheck2 className="size-4 text-primary" />
          آخر تحديث: 3 أكتوبر 2026
        </span>
      </PageHeader>

      <section className="container-page pb-24">
        <div className="mx-auto max-w-4xl space-y-5">
          {sections.map((section, index) => (
            <Reveal key={section.title} delay={(index % 3) * 0.04}>
              <article className="card-surface rounded-[var(--radius-card)] p-6 sm:p-8">
                <h2 className="text-xl font-bold">{section.title}</h2>
                <p className="mt-3 leading-8 text-muted">{section.body}</p>
              </article>
            </Reveal>
          ))}

          <Reveal>
            <div className="flex flex-col items-start justify-between gap-5 rounded-[var(--radius-card)] border border-primary/25 bg-primary/5 p-6 sm:flex-row sm:items-center sm:p-8">
              <div>
                <h2 className="text-xl font-bold">لديك سؤال؟</h2>
                <p className="mt-2 text-muted">تواصل بخصوص استخدام الموقع أو أي مشروع أو خدمة معروضة فيه.</p>
              </div>
              <div className="flex gap-2">
                <ButtonLink href="/contact" size="sm">تواصل معي</ButtonLink>
                <Link href="/privacy" className="inline-flex items-center rounded-full px-4 py-2 text-sm font-medium text-muted transition-colors hover:text-primary">
                  الخصوصية
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
