import { ArrowLeft, Compass } from "lucide-react";
import { BrandMark } from "@/components/shared/brand-mark";
import { ButtonLink } from "@/components/ui/button";
import { t } from "@/lib/i18n";

export default function NotFound() {
  return (
    <main className="relative isolate grid min-h-dvh place-items-center overflow-hidden px-6">
      <div className="bg-grid mask-radial pointer-events-none absolute inset-0 -z-10" aria-hidden />
      <div className="pointer-events-none absolute -top-40 start-1/2 -z-10 h-96 w-[40rem] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px] rtl:translate-x-1/2" aria-hidden />
      <div className="text-center">
        <BrandMark className="mb-14 justify-center" />
        <p className="latin text-gradient text-8xl font-bold sm:text-9xl">404</p>
        <h1 className="mt-6 text-3xl font-bold">{t.states.notFoundTitle}</h1>
        <p className="mx-auto mt-3 max-w-md text-muted">{t.states.notFoundDescription}</p>
        <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
          <ButtonLink href="/">
            {t.nav.home}
            <ArrowLeft className="size-4 ltr:rotate-180" />
          </ButtonLink>
          <ButtonLink href="/ventures" variant="secondary">
            <Compass className="size-4" />
            {t.nav.ventures}
          </ButtonLink>
        </div>
      </div>
    </main>
  );
}
