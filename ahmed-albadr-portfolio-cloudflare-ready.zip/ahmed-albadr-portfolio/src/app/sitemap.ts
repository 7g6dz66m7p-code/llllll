import type { MetadataRoute } from "next";
import { absoluteUrl } from "@/lib/site";
import { getInsights, getVentures } from "@/services/content";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [ventures, insights] = await Promise.all([getVentures(), getInsights()]);
  const now = new Date();

  const staticRoutes: MetadataRoute.Sitemap = [
    { path: "/", priority: 1, changeFrequency: "weekly" as const },
    { path: "/ventures", priority: 0.9, changeFrequency: "weekly" as const },
    { path: "/about", priority: 0.8, changeFrequency: "monthly" as const },
    { path: "/services", priority: 0.8, changeFrequency: "monthly" as const },
    { path: "/vision", priority: 0.6, changeFrequency: "monthly" as const },
    { path: "/achievements", priority: 0.6, changeFrequency: "monthly" as const },
    { path: "/insights", priority: 0.8, changeFrequency: "weekly" as const },
    { path: "/contact", priority: 0.5, changeFrequency: "yearly" as const },
    { path: "/privacy", priority: 0.2, changeFrequency: "yearly" as const },
    { path: "/terms", priority: 0.2, changeFrequency: "yearly" as const },
  ].map(({ path, ...rest }) => ({ url: absoluteUrl(path), lastModified: now, ...rest }));

  return [
    ...staticRoutes,
    ...ventures.map((v) => ({
      url: absoluteUrl(`/ventures/${v.slug}`),
      lastModified: v.updatedAt,
      changeFrequency: "monthly" as const,
      priority: v.featured ? 0.9 : 0.7,
      ...((v.coverImage || v.logo) && { images: [((v.coverImage ?? v.logo)!).startsWith("http") ? (v.coverImage ?? v.logo)! : absoluteUrl((v.coverImage ?? v.logo)!)] }),
    })),
    ...insights.map((i) => ({
      url: absoluteUrl(`/insights/${i.slug}`),
      lastModified: i.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
      ...(i.coverImage && { images: [i.coverImage.startsWith("http") ? i.coverImage : absoluteUrl(i.coverImage)] }),
    })),
  ];
}
