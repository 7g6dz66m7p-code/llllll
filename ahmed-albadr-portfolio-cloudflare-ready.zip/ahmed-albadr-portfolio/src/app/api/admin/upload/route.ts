import { NextResponse, type NextRequest } from "next/server";
import { assertAdmin, UnauthorizedError } from "@/lib/auth";
import { db } from "@/lib/db/prisma";
import { isDatabaseConfigured, isStorageConfigured } from "@/lib/env";
import { HttpError, handleRouteError } from "@/lib/http";
import { logger } from "@/lib/logger";
import { isSameOrigin } from "@/lib/security/request";
import { MAX_UPLOAD_BYTES, sniffImageType, uploadObject } from "@/lib/storage";
import { sanitizeText } from "@/lib/utils/sanitize";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    await assertAdmin().catch((e) => {
      if (e instanceof UnauthorizedError) throw new HttpError(401, "UNAUTHORIZED", "يجب تسجيل الدخول");
      throw e;
    });
    if (!isSameOrigin(request.headers)) throw new HttpError(403, "FORBIDDEN", "طلب غير مسموح");
    if (!isStorageConfigured()) throw new HttpError(503, "STORAGE_DISABLED", "التخزين السحابي (R2) غير مُعدّ. أضف متغيرات R2 في البيئة.");

    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new HttpError(400, "NO_FILE", "لم يتم اختيار ملف");
    if (file.size === 0) throw new HttpError(400, "EMPTY", "الملف فارغ");
    if (file.size > MAX_UPLOAD_BYTES) throw new HttpError(413, "TOO_LARGE", "الحد الأقصى لحجم الصورة 5 ميغابايت");

    const bytes = new Uint8Array(await file.arrayBuffer());
    const type = sniffImageType(bytes);
    if (!type) throw new HttpError(415, "UNSUPPORTED", "الصيغ المسموحة: PNG, JPG, WEBP, AVIF, GIF");

    const folder = form.get("folder") === "logos" ? "logos" : "uploads";
    const { key, url } = await uploadObject(bytes, type, folder);
    const filename = sanitizeText(file.name).slice(0, 200) || key;
    const alt = typeof form.get("alt") === "string" ? sanitizeText(String(form.get("alt"))).slice(0, 200) || null : null;

    const media = isDatabaseConfigured()
      ? await db().media.create({ data: { key, url, filename, mimeType: type, size: file.size, alt } })
      : { id: key, key, url, filename, mimeType: type, size: file.size, alt };

    logger.info("media.uploaded", { key, size: file.size, type });
    return NextResponse.json({ ok: true, media }, { status: 201 });
  } catch (error) {
    return handleRouteError(error, "admin.upload");
  }
}
