import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/lib/db/prisma";
import { isDatabaseConfigured } from "@/lib/env";
import { HttpError, handleRouteError } from "@/lib/http";
import { logger } from "@/lib/logger";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp, hashIp, isSameOrigin } from "@/lib/security/request";
import { contactSchema } from "@/lib/validations/contact";

export const runtime = "nodejs";

const MIN_FILL_MS = 2500;
const DB_WINDOW_MS = 60 * 60 * 1000;
const DB_MAX_PER_WINDOW = 5;

export async function POST(request: NextRequest) {
  try {
    if (!isSameOrigin(request.headers)) throw new HttpError(403, "FORBIDDEN", "طلب غير مسموح");
    if (Number(request.headers.get("content-length") ?? 0) > 20_000) throw new HttpError(413, "TOO_LARGE", "حجم الطلب كبير جدًا");

    const ipHash = hashIp(clientIp(request.headers));
    const limited = rateLimit(`contact:${ipHash}`, { limit: 3, windowMs: 10 * 60 * 1000 });
    if (!limited.ok) {
      return NextResponse.json(
        { ok: false, code: "RATE_LIMITED", message: "أرسلت عدة رسائل خلال وقت قصير. حاول مجددًا لاحقًا." },
        { status: 429, headers: { "Retry-After": String(limited.retryAfter) } },
      );
    }

    const body = await request.json().catch(() => {
      throw new HttpError(400, "BAD_REQUEST", "صيغة الطلب غير صحيحة");
    });
    const data = contactSchema.parse(body);

    // Bots: filled honeypot or inhumanly fast submit. Respond with success so they learn nothing.
    if (data.website || (data.elapsed !== undefined && data.elapsed < MIN_FILL_MS)) {
      logger.warn("contact.spam_blocked", { ipHash, reason: data.website ? "honeypot" : "too_fast" });
      return NextResponse.json({ ok: true });
    }

    if (!isDatabaseConfigured()) {
      logger.error("contact.storage_unavailable", { ipHash });
      throw new HttpError(503, "UNAVAILABLE", "خدمة الرسائل غير متاحة مؤقتًا. يمكنك التواصل عبر البريد أو واتساب.");
    }

    const recent = await db().contactMessage.count({
      where: { ipHash, createdAt: { gte: new Date(Date.now() - DB_WINDOW_MS) } },
    });
    if (recent >= DB_MAX_PER_WINDOW) throw new HttpError(429, "RATE_LIMITED", "أرسلت عدة رسائل خلال وقت قصير. حاول مجددًا لاحقًا.");

    await db().contactMessage.create({
      data: {
        name: data.name,
        email: data.email,
        phone: data.phone ?? null,
        type: data.type,
        message: data.message,
        ipHash,
        userAgent: request.headers.get("user-agent")?.slice(0, 300) ?? null,
      },
    });
    logger.info("contact.received", { type: data.type, ipHash });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (error) {
    return handleRouteError(error, "contact");
  }
}
