import { redirect } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { BrandMark } from "@/components/shared/brand-mark";
import { LoginForm } from "@/components/admin/login-form";
import { auth } from "@/lib/auth";
import { env } from "@/lib/env";

export const metadata = { title: "تسجيل الدخول" };

export default async function LoginPage() {
  const session = await auth();
  if (session?.user) redirect("/admin");
  const configured = Boolean(env().ADMIN_EMAIL && env().ADMIN_PASSWORD_HASH_B64 && env().AUTH_SECRET);

  return (
    <main className="relative isolate grid min-h-dvh place-items-center px-4 py-12">
      <div className="bg-grid mask-radial pointer-events-none absolute inset-0 -z-10" aria-hidden />
      <div className="pointer-events-none absolute top-0 start-1/2 -z-10 h-80 w-[36rem] -translate-x-1/2 rounded-full bg-primary/15 blur-[120px] rtl:translate-x-1/2" aria-hidden />
      <div className="w-full max-w-md">
        <BrandMark className="mb-10 flex justify-center" />
        <div className="card-surface rounded-[var(--radius-panel)] p-7 sm:p-9">
          <div className="mb-8 flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" />
            </span>
            <div>
              <h1 className="text-xl font-bold">لوحة الإدارة</h1>
              <p className="text-sm text-muted">سجّل الدخول للمتابعة</p>
            </div>
          </div>
          {!configured && (
            <p className="mb-6 rounded-xl border border-warning/30 bg-warning/5 p-4 text-sm text-muted" role="status">
              لم يتم إعداد حساب الإدارة بعد. أضف <code className="latin">AUTH_SECRET</code> و<code className="latin">ADMIN_EMAIL</code> و
              <code className="latin">ADMIN_PASSWORD_HASH_B64</code> إلى متغيرات البيئة.
            </p>
          )}
          <LoginForm />
        </div>
      </div>
    </main>
  );
}
