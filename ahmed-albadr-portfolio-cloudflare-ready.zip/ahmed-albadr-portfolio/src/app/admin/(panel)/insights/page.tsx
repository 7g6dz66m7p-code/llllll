import Link from "next/link";
import { ExternalLink, Pencil, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { Badge } from "@/components/ui/badge";
import { buttonStyles } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { adminQueries } from "@/services/admin/queries";
import { deleteInsight } from "@/services/admin/insights";

export const metadata = { title: "المقالات" };

export default async function AdminInsights() {
  const insights = await adminQueries.insights();
  return (
    <>
      <AdminPageHeader title="أفكار ورؤى" description="اكتب المقالات وانشرها أو احفظها كمسودات." createHref="/admin/insights/new" createLabel="مقال جديد" />
      <AdminTable head={["العنوان", "التصنيف", "الحالة", "تاريخ النشر", ""]} empty={!insights.length}>
        {insights.map((i) => (
          <tr key={i.id} className="hover:bg-surface-2/40">
            <Td>
              <Link href={`/admin/insights/${i.id}`} className="font-semibold hover:text-primary">
                {i.title}
              </Link>
              {i.featured && <Badge tone="primary" className="ms-2">مميز</Badge>}
            </Td>
            <Td className="text-muted">{i.category}</Td>
            <Td>
              <Badge tone={i.status === "PUBLISHED" ? "success" : "neutral"}>{i.status === "PUBLISHED" ? "منشور" : "مسودة"}</Badge>
            </Td>
            <Td className="text-muted">{formatDate(i.publishedAt) || "—"}</Td>
            <Td end>
              <div className="flex items-center justify-end gap-1">
                {i.status === "PUBLISHED" && (
                  <Link href={`/insights/${i.slug}`} target="_blank" rel="noopener noreferrer" className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="عرض">
                    <ExternalLink className="size-4" />
                  </Link>
                )}
                <Link href={`/admin/insights/${i.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل">
                  <Pencil className="size-4" />
                </Link>
                <ActionButton action={deleteInsight.bind(null, i.id)} size="icon" title="حذف" confirmMessage={`حذف "${i.title}"؟`} className="hover:text-danger">
                  <Trash2 className="size-4" />
                </ActionButton>
              </div>
            </Td>
          </tr>
        ))}
      </AdminTable>
    </>
  );
}
