import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { InsightForm } from "@/components/admin/forms/insight-form";
import { adminQueries } from "@/services/admin/queries";
import { deleteInsight, saveInsight } from "@/services/admin/insights";

export const metadata = { title: "تعديل مقال" };

export default async function EditInsight({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const insight = await adminQueries.insight(id);
  if (!insight) notFound();
  return (
    <>
      <AdminPageHeader title={`تعديل: ${insight.title}`} />
      <InsightForm
        action={saveInsight.bind(null, insight.id)}
        insight={insight}
        extraActions={
          <ActionButton action={deleteInsight.bind(null, insight.id)} variant="danger" confirmMessage="حذف هذا المقال نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
