import { AdminPageHeader } from "@/components/admin/ui";
import { InsightForm } from "@/components/admin/forms/insight-form";
import { saveInsight } from "@/services/admin/insights";

export const metadata = { title: "مقال جديد" };

export default function NewInsight() {
  return (
    <>
      <AdminPageHeader title="مقال جديد" />
      <InsightForm action={saveInsight.bind(null, null)} />
    </>
  );
}
