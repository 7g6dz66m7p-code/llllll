import Link from "next/link";
import { Pencil, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { socialMeta } from "@/components/shared/social-links";
import { Badge } from "@/components/ui/badge";
import { buttonStyles } from "@/components/ui/button";
import { adminQueries } from "@/services/admin/queries";
import { deleteSocialLink } from "@/services/admin/catalog";

export const metadata = { title: "روابط التواصل" };

export default async function AdminSocial() {
  const links = await adminQueries.socialLinks();
  return (
    <>
      <AdminPageHeader title="روابط التواصل" description="WhatsApp، Email، Instagram، LinkedIn، GitHub وغيرها — تظهر في التذييل وصفحة التواصل." createHref="/admin/social/new" createLabel="رابط جديد" />
      <AdminTable head={["المنصة", "الرابط", "الحالة", ""]} empty={!links.length}>
        {links.map((l) => {
          const { icon: Icon, label } = socialMeta[l.platform];
          return (
            <tr key={l.id} className="hover:bg-surface-2/40">
              <Td>
                <Link href={`/admin/social/${l.id}`} className="flex items-center gap-3 font-semibold hover:text-primary">
                  <Icon className="size-4 text-primary" />
                  <span className="latin">{l.label || label}</span>
                </Link>
              </Td>
              <Td className="latin max-w-xs truncate text-muted" ><span dir="ltr">{l.url}</span></Td>
              <Td><Badge tone={l.active ? "success" : "neutral"}>{l.active ? "ظاهر" : "مخفي"}</Badge></Td>
              <Td end>
                <div className="flex justify-end gap-1">
                  <Link href={`/admin/social/${l.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل"><Pencil className="size-4" /></Link>
                  <ActionButton action={deleteSocialLink.bind(null, l.id)} size="icon" title="حذف" confirmMessage="حذف هذا الرابط؟" className="hover:text-danger"><Trash2 className="size-4" /></ActionButton>
                </div>
              </Td>
            </tr>
          );
        })}
      </AdminTable>
    </>
  );
}
