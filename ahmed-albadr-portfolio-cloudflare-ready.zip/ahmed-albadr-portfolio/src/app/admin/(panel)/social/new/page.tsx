import { AdminPageHeader } from "@/components/admin/ui";
import { SocialLinkForm } from "@/components/admin/forms/catalog-forms";
import { saveSocialLink } from "@/services/admin/catalog";

export const metadata = { title: "رابط جديد" };

export default function NewPage() {
  return (
    <>
      <AdminPageHeader title="رابط جديد" />
      <SocialLinkForm action={saveSocialLink.bind(null, null)} />
    </>
  );
}
