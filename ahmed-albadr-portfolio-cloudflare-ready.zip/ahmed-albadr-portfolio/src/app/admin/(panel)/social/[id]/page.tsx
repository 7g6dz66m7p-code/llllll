import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { SocialLinkForm } from "@/components/admin/forms/catalog-forms";
import { adminQueries } from "@/services/admin/queries";
import { deleteSocialLink, saveSocialLink } from "@/services/admin/catalog";

export const metadata = { title: "تعديل رابط" };

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = await adminQueries.socialLink(id);
  if (!item) notFound();
  return (
    <>
      <AdminPageHeader title="تعديل رابط" />
      <SocialLinkForm
        action={saveSocialLink.bind(null, item.id)}
        link={item}
        extraActions={
          <ActionButton action={deleteSocialLink.bind(null, item.id)} variant="danger" confirmMessage="حذف هذا العنصر نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
