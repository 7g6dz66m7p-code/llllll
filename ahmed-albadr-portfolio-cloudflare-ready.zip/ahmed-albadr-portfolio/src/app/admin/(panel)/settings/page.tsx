import { AdminForm, FormActions, FormSection, TextAreaField, TextField } from "@/components/admin/form-kit";
import { ImageField } from "@/components/admin/image-field";
import { AdminPageHeader } from "@/components/admin/ui";
import { defaultSiteSettings } from "@/data/site";
import { adminQueries } from "@/services/admin/queries";
import { saveSettings } from "@/services/admin/settings";

export const metadata = { title: "إعدادات الموقع" };

export default async function AdminSettings() {
  const s = (await adminQueries.settings()) ?? defaultSiteSettings;
  return (
    <>
      <AdminPageHeader title="إعدادات الموقع" description="النصوص الرئيسية، صورة الصفحة الرئيسية، بيانات التواصل وSEO." />
      <AdminForm action={saveSettings}>
        <FormSection title="الصفحة الرئيسية (Hero)">
          <TextField name="heroName" label="الاسم" defaultValue={s.heroName} required />
          <TextField name="heroNameEn" label="الاسم بالإنجليزية" defaultValue={s.heroNameEn} dir="ltr" required />
          <TextField name="heroRole" label="الوصف" defaultValue={s.heroRole} required />
          <TextField name="heroIdentity" label="الهوية الإنجليزية" defaultValue={s.heroIdentity} dir="ltr" required />
          <TextAreaField name="heroDescription" label="النص التعريفي" defaultValue={s.heroDescription} rows={3} className="sm:col-span-2" required />
          <TextField name="primaryCtaLabel" label="الزر الأساسي" defaultValue={s.primaryCtaLabel} required />
          <TextField name="secondaryCtaLabel" label="الزر الثانوي" defaultValue={s.secondaryCtaLabel} required />
          <TextField name="availability" label="شارة الحالة (أعلى العنوان)" defaultValue={s.availability} />
          <ImageField name="heroImage" label="الصورة الشخصية" defaultValue={s.heroImage} aspect="aspect-[4/5]" hint="يفضّل صورة عمودية 4:5 بدقة 1200×1500 على الأقل" />
        </FormSection>

        <FormSection title="صفحة عن أحمد والرؤية">
          <TextField name="aboutHeadline" label="العنوان" defaultValue={s.aboutHeadline} required />
          <TextField name="aboutIdentity" label="الهوية" defaultValue={s.aboutIdentity} dir="ltr" required />
          <TextAreaField name="aboutBody" label="النص" defaultValue={s.aboutBody} rows={8} className="sm:col-span-2" hint="افصل الفقرات بسطر فارغ" required />
          <TextAreaField name="visionStatement" label="نص الرؤية" defaultValue={s.visionStatement} rows={2} className="sm:col-span-2" required />
        </FormSection>

        <FormSection title="بيانات التواصل">
          <TextField name="contactEmail" label="البريد الإلكتروني" defaultValue={s.contactEmail} dir="ltr" type="email" />
          <TextField name="whatsappNumber" label="رقم واتساب (مع رمز الدولة)" defaultValue={s.whatsappNumber} dir="ltr" placeholder="9647700000000" />
          <TextField name="location" label="الموقع" defaultValue={s.location} />
        </FormSection>

        <FormSection title="SEO">
          <TextAreaField name="seoDescription" label="الوصف الافتراضي" defaultValue={s.seoDescription} rows={3} className="sm:col-span-2" required />
          <ImageField name="ogImage" label="صورة المشاركة (Open Graph)" defaultValue={s.ogImage} hint="1200×630 — فارغ = الصورة المولّدة تلقائيًا" />
        </FormSection>

        <FormActions />
      </AdminForm>
    </>
  );
}
