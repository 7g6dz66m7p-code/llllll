import { AdminSidebar } from "@/components/admin/sidebar";
import { DatabaseNotice } from "@/components/admin/ui";
import { requireAdmin } from "@/lib/auth";
import { isDatabaseConfigured } from "@/lib/env";
import { db } from "@/lib/db/prisma";

export default async function AdminPanelLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdmin();
  const dbReady = isDatabaseConfigured();
  const newMessages = dbReady ? await db().contactMessage.count({ where: { status: "NEW" } }) : 0;

  return (
    <div className="min-h-dvh bg-background lg:flex">
      <AdminSidebar newMessages={newMessages} email={session.user?.email} />
      <main className="min-w-0 flex-1 px-4 py-8 sm:px-8 lg:px-10 lg:py-10">
        <div className="mx-auto max-w-6xl">
          {!dbReady && <DatabaseNotice />}
          {children}
        </div>
      </main>
    </div>
  );
}
