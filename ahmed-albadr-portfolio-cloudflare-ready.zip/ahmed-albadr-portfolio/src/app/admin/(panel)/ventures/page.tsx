import Link from "next/link";
import { ExternalLink, Pencil, Star, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { VentureLogo } from "@/components/ventures/venture-logo";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import { buttonStyles } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { adminQueries } from "@/services/admin/queries";
import { deleteVenture, toggleVentureFeatured } from "@/services/admin/ventures";

export const metadata = { title: "المشاريع" };

export default async function AdminVentures() {
  const ventures = await adminQueries.ventures();
  return (
    <>
      <AdminPageHeader title="المشاريع" description="أضف وعدّل المشاريع وحدد المميز منها وحالتها." createHref="/admin/ventures/new" createLabel="مشروع جديد" />
      <AdminTable head={["المشروع", "الحالة", "النشر", "الترتيب", ""]} empty={!ventures.length}>
        {ventures.map((v) => (
          <tr key={v.id} className="hover:bg-surface-2/40">
            <Td>
              <Link href={`/admin/ventures/${v.id}`} className="flex items-center gap-3">
                <VentureLogo name={v.name} logo={v.logo} accentColor={v.accentColor} size={36} />
                <span>
                  <span className="block font-semibold hover:text-primary">{v.name}</span>
                  <span className="latin text-xs text-subtle">/{v.slug}</span>
                </span>
              </Link>
            </Td>
            <Td>
              <StatusBadge status={v.status} />
            </Td>
            <Td>
              <div className="flex gap-1.5">
                <Badge tone={v.published ? "success" : "neutral"}>{v.published ? "منشور" : "مخفي"}</Badge>
                {v.featured && <Badge tone="primary">مميز</Badge>}
              </div>
            </Td>
            <Td className="latin">{v.sortOrder}</Td>
            <Td end>
              <div className="flex items-center justify-end gap-1">
                <ActionButton action={toggleVentureFeatured.bind(null, v.id)} size="icon" title={v.featured ? "إلغاء التمييز" : "تمييز"}>
                  <Star className={cn("size-4", v.featured && "fill-primary text-primary")} />
                </ActionButton>
                <Link href={`/ventures/${v.slug}`} target="_blank" rel="noopener noreferrer" className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="عرض">
                  <ExternalLink className="size-4" />
                </Link>
                <Link href={`/admin/ventures/${v.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل">
                  <Pencil className="size-4" />
                </Link>
                <ActionButton action={deleteVenture.bind(null, v.id)} size="icon" title="حذف" confirmMessage={`حذف مشروع "${v.name}" نهائيًا؟`} className="hover:text-danger">
                  <Trash2 className="size-4" />
                </ActionButton>
              </div>
            </Td>
          </tr>
        ))}
      </AdminTable>
    </>
  );
}
