import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { VentureForm } from "@/components/admin/forms/venture-form";
import { adminQueries } from "@/services/admin/queries";
import { deleteVenture, saveVenture } from "@/services/admin/ventures";

export const metadata = { title: "تعديل مشروع" };

export default async function EditVenture({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const venture = await adminQueries.venture(id);
  if (!venture) notFound();
  return (
    <>
      <AdminPageHeader title={`تعديل: ${venture.name}`} />
      <VentureForm
        action={saveVenture.bind(null, venture.id)}
        venture={venture}
        extraActions={
          <ActionButton action={deleteVenture.bind(null, venture.id)} variant="danger" confirmMessage="حذف هذا المشروع نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
