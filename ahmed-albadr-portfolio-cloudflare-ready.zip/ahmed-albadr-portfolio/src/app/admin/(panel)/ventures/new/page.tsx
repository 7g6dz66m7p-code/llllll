import { AdminPageHeader } from "@/components/admin/ui";
import { VentureForm } from "@/components/admin/forms/venture-form";
import { saveVenture } from "@/services/admin/ventures";

export const metadata = { title: "مشروع جديد" };

export default function NewVenture() {
  return (
    <>
      <AdminPageHeader title="مشروع جديد" />
      <VentureForm action={saveVenture.bind(null, null)} />
    </>
  );
}
