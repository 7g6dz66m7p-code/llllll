import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { StatForm } from "@/components/admin/forms/catalog-forms";
import { adminQueries } from "@/services/admin/queries";
import { deleteStat, saveStat } from "@/services/admin/catalog";

export const metadata = { title: "تعديل رقم" };

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = await adminQueries.stat(id);
  if (!item) notFound();
  return (
    <>
      <AdminPageHeader title="تعديل رقم" />
      <StatForm
        action={saveStat.bind(null, item.id)}
        stat={item}
        extraActions={
          <ActionButton action={deleteStat.bind(null, item.id)} variant="danger" confirmMessage="حذف هذا العنصر نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
