import { AdminPageHeader } from "@/components/admin/ui";
import { StatForm } from "@/components/admin/forms/catalog-forms";
import { saveStat } from "@/services/admin/catalog";

export const metadata = { title: "رقم جديد" };

export default function NewPage() {
  return (
    <>
      <AdminPageHeader title="رقم جديد" />
      <StatForm action={saveStat.bind(null, null)} />
    </>
  );
}
