import Link from "next/link";
import { Pencil, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { buttonStyles } from "@/components/ui/button";
import { DynamicIcon } from "@/lib/icons";
import { adminQueries } from "@/services/admin/queries";
import { deleteStat } from "@/services/admin/catalog";

export const metadata = { title: "الإحصائيات" };

export default async function AdminStats() {
  const stats = await adminQueries.stats();
  return (
    <>
      <AdminPageHeader title="الإحصائيات" description="الأرقام المعروضة أسفل قسم Hero في الصفحة الرئيسية." createHref="/admin/stats/new" createLabel="رقم جديد" />
      <AdminTable head={["العنوان", "القيمة", "الترتيب", ""]} empty={!stats.length}>
        {stats.map((s) => {
          return (
            <tr key={s.id} className="hover:bg-surface-2/40">
              <Td>
                <Link href={`/admin/stats/${s.id}`} className="flex items-center gap-3 font-semibold hover:text-primary">
                  <DynamicIcon name={s.icon} className="size-4 text-primary" />
                  {s.label}
                </Link>
              </Td>
              <Td className="latin text-lg font-bold">{s.value}{s.suffix}</Td>
              <Td className="latin">{s.sortOrder}</Td>
              <Td end>
                <div className="flex justify-end gap-1">
                  <Link href={`/admin/stats/${s.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل"><Pencil className="size-4" /></Link>
                  <ActionButton action={deleteStat.bind(null, s.id)} size="icon" title="حذف" confirmMessage={`حذف "${s.label}"؟`} className="hover:text-danger"><Trash2 className="size-4" /></ActionButton>
                </div>
              </Td>
            </tr>
          );
        })}
      </AdminTable>
    </>
  );
}
