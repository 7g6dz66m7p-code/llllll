import { AdminPageHeader } from "@/components/admin/ui";
import { MediaLibrary } from "@/components/admin/media-library";
import { isStorageConfigured } from "@/lib/env";
import { adminQueries } from "@/services/admin/queries";

export const metadata = { title: "مكتبة الوسائط" };

export default async function AdminMedia() {
  const media = await adminQueries.media();
  return (
    <>
      <AdminPageHeader title="مكتبة الوسائط" description="ارفع الصور (شعارات، أغلفة، لقطات شاشة) وانسخ روابطها لاستخدامها في المحتوى." />
      {!isStorageConfigured() && (
        <p className="mb-6 rounded-2xl border border-warning/30 bg-warning/5 p-4 text-sm text-muted" role="status">
          التخزين السحابي غير مُعدّ. أضف متغيرات <code className="latin">R2_*</code> لتفعيل الرفع.
        </p>
      )}
      <MediaLibrary items={media.map((m) => ({ id: m.id, url: m.url, filename: m.filename, size: m.size, mimeType: m.mimeType }))} />
    </>
  );
}
