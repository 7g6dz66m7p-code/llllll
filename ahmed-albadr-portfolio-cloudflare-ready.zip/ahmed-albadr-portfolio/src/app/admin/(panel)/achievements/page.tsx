import Link from "next/link";
import { Pencil, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { Badge } from "@/components/ui/badge";
import { buttonStyles } from "@/components/ui/button";
import { adminQueries } from "@/services/admin/queries";
import { deleteAchievement } from "@/services/admin/catalog";

export const metadata = { title: "الإنجازات" };

export default async function AdminAchievements() {
  const items = await adminQueries.achievements();
  return (
    <>
      <AdminPageHeader title="الإنجازات" description="محطات الأعمال (Business Milestones) المعروضة على الخط الزمني." createHref="/admin/achievements/new" createLabel="إنجاز جديد" />
      <AdminTable head={["السنة", "العنوان", "المشروع", "الحالة", ""]} empty={!items.length}>
        {items.map((a) => (
          <tr key={a.id} className="hover:bg-surface-2/40">
            <Td className="latin font-bold text-primary">{a.year}</Td>
            <Td><Link href={`/admin/achievements/${a.id}`} className="font-semibold hover:text-primary">{a.title}</Link></Td>
            <Td className="text-muted">{a.venture?.name ?? "—"}</Td>
            <Td><Badge tone={a.published ? "success" : "neutral"}>{a.published ? "منشور" : "مخفي"}</Badge></Td>
            <Td end>
              <div className="flex justify-end gap-1">
                <Link href={`/admin/achievements/${a.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل"><Pencil className="size-4" /></Link>
                <ActionButton action={deleteAchievement.bind(null, a.id)} size="icon" title="حذف" confirmMessage={`حذف "${a.title}"؟`} className="hover:text-danger"><Trash2 className="size-4" /></ActionButton>
              </div>
            </Td>
          </tr>
        ))}
      </AdminTable>
    </>
  );
}
