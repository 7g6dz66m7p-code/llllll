import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { AchievementForm } from "@/components/admin/forms/catalog-forms";
import { adminQueries } from "@/services/admin/queries";
import { deleteAchievement, saveAchievement } from "@/services/admin/catalog";

export const metadata = { title: "تعديل إنجاز" };

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = await adminQueries.achievement(id);
  if (!item) notFound();
  const ventures = await adminQueries.ventureOptions();
  return (
    <>
      <AdminPageHeader title="تعديل إنجاز" />
      <AchievementForm
        action={saveAchievement.bind(null, item.id)}
        achievement={item} ventures={ventures}
        extraActions={
          <ActionButton action={deleteAchievement.bind(null, item.id)} variant="danger" confirmMessage="حذف هذا العنصر نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
