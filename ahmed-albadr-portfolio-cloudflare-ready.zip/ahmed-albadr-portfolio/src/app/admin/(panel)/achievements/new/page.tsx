import { AdminPageHeader } from "@/components/admin/ui";
import { AchievementForm } from "@/components/admin/forms/catalog-forms";
import { adminQueries } from "@/services/admin/queries";
import { saveAchievement } from "@/services/admin/catalog";

export const metadata = { title: "إنجاز جديد" };

export default async function NewPage() {
  const ventures = await adminQueries.ventureOptions();
  return (
    <>
      <AdminPageHeader title="إنجاز جديد" />
      <AchievementForm action={saveAchievement.bind(null, null)} ventures={ventures} />
    </>
  );
}
