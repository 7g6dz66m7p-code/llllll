import Link from "next/link";
import { Award, Briefcase, Image as ImageIcon, Mail, NotebookPen, Plus, Settings, Sparkles } from "lucide-react";
import { AdminPageHeader } from "@/components/admin/ui";
import { Badge } from "@/components/ui/badge";
import { t } from "@/lib/i18n";
import { formatDate } from "@/lib/utils";
import { adminQueries } from "@/services/admin/queries";

export const metadata = { title: "نظرة عامة" };

export default async function AdminOverview() {
  const o = await adminQueries.overview();
  const cards = [
    { label: "المشاريع", value: o.ventures, icon: Briefcase, href: "/admin/ventures" },
    { label: "المقالات", value: o.insights, icon: NotebookPen, href: "/admin/insights" },
    { label: "الخدمات", value: o.services, icon: Sparkles, href: "/admin/services" },
    { label: "الإنجازات", value: o.achievements, icon: Award, href: "/admin/achievements" },
    { label: "رسائل جديدة", value: o.newMessages, icon: Mail, href: "/admin/messages", highlight: o.newMessages > 0 },
    { label: "الوسائط", value: o.media, icon: ImageIcon, href: "/admin/media" },
  ];
  const quick = [
    { label: "مشروع جديد", href: "/admin/ventures/new", icon: Briefcase },
    { label: "مقال جديد", href: "/admin/insights/new", icon: NotebookPen },
    { label: "إنجاز جديد", href: "/admin/achievements/new", icon: Award },
    { label: "إعدادات الموقع", href: "/admin/settings", icon: Settings },
  ];

  return (
    <>
      <AdminPageHeader title="مرحبًا أحمد 👋" description="نظرة سريعة على محتوى الموقع ونشاطه." />
      <ul className="grid grid-cols-2 gap-4 lg:grid-cols-3">
        {cards.map(({ label, value, icon: Icon, href, highlight }) => (
          <li key={label}>
            <Link href={href} className="group card-surface flex items-center justify-between rounded-[var(--radius-card)] p-5 transition-all hover:-translate-y-0.5 hover:border-primary/25">
              <div>
                <p className="text-sm text-muted">{label}</p>
                <p className={`latin mt-2 text-3xl font-bold ${highlight ? "text-primary" : ""}`}>{value}</p>
              </div>
              <span className="grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary transition-transform group-hover:scale-110">
                <Icon className="size-5" />
              </span>
            </Link>
          </li>
        ))}
      </ul>

      <div className="mt-8 grid gap-6 lg:grid-cols-5">
        <section className="card-surface rounded-[var(--radius-card)] p-6 lg:col-span-3">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="font-bold">أحدث الرسائل</h2>
            <Link href="/admin/messages" className="text-sm text-primary hover:underline">
              عرض الكل
            </Link>
          </div>
          {o.recentMessages.length ? (
            <ul className="divide-y divide-border">
              {o.recentMessages.map((m) => (
                <li key={m.id}>
                  <Link href={`/admin/messages/${m.id}`} className="flex items-center justify-between gap-4 py-3 hover:text-primary">
                    <span className="min-w-0">
                      <span className="block truncate font-medium">{m.name}</span>
                      <span className="text-xs text-subtle">
                        {t.inquiryType[m.type]} · {formatDate(m.createdAt)}
                      </span>
                    </span>
                    <Badge tone={m.status === "NEW" ? "primary" : "neutral"}>{t.messageStatus[m.status]}</Badge>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="py-8 text-center text-sm text-muted">لا توجد رسائل بعد.</p>
          )}
        </section>
        <section className="card-surface rounded-[var(--radius-card)] p-6 lg:col-span-2">
          <h2 className="mb-5 font-bold">إجراءات سريعة</h2>
          <ul className="space-y-2">
            {quick.map(({ label, href, icon: Icon }) => (
              <li key={href}>
                <Link href={href} className="flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary">
                  <Icon className="size-4 text-primary" />
                  <span className="flex-1">{label}</span>
                  <Plus className="size-4 text-subtle" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  );
}
