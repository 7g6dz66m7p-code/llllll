import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Mail, MessageCircle, Phone, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { Badge } from "@/components/ui/badge";
import { buttonStyles } from "@/components/ui/button";
import { db } from "@/lib/db/prisma";
import { t } from "@/lib/i18n";
import { formatDate } from "@/lib/utils";
import { adminQueries } from "@/services/admin/queries";
import { deleteMessage, setMessageStatus } from "@/services/admin/messages";
import { MESSAGE_STATUSES } from "@/types/content";

export const metadata = { title: "رسالة" };

export default async function MessagePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const message = await adminQueries.message(id);
  if (!message) notFound();
  // Opening a new message marks it as read.
  if (message.status === "NEW") await db().contactMessage.update({ where: { id }, data: { status: "READ" } });
  const status = message.status === "NEW" ? "READ" : message.status;
  const phoneDigits = message.phone?.replace(/\D/g, "");

  return (
    <>
      <Link href="/admin/messages" className="mb-6 inline-flex items-center gap-2 text-sm text-muted hover:text-primary">
        <ArrowRight className="size-4 ltr:rotate-180" />
        كل الرسائل
      </Link>
      <article className="card-surface rounded-[var(--radius-panel)] p-6 sm:p-8">
        <header className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold">{message.name}</h1>
            <p className="latin mt-1 text-sm text-muted" dir="ltr">{message.email}{message.phone ? ` · ${message.phone}` : ""}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge tone="primary">{t.inquiryType[message.type]}</Badge>
              <Badge>{formatDate(message.createdAt)}</Badge>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <a href={`mailto:${message.email}?subject=${encodeURIComponent("رد: رسالتك إلى أحمد البدر")}`} className={buttonStyles({ size: "sm" })}>
              <Mail className="size-4" /> رد بالبريد
            </a>
            {phoneDigits && (
              <>
                <a href={`https://wa.me/${phoneDigits}`} target="_blank" rel="noopener noreferrer" className={buttonStyles({ size: "sm", variant: "secondary" })}>
                  <MessageCircle className="size-4" /> واتساب
                </a>
                <a href={`tel:${message.phone}`} className={buttonStyles({ size: "icon", variant: "ghost" })} aria-label="اتصال"><Phone className="size-4" /></a>
              </>
            )}
          </div>
        </header>
        <p className="whitespace-pre-wrap py-6 leading-8 text-foreground">{message.message}</p>
        <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
          <div className="flex flex-wrap gap-2">
            {MESSAGE_STATUSES.filter((s) => s !== "NEW").map((s) => (
              <ActionButton key={s} action={setMessageStatus.bind(null, message.id, s)} variant={status === s ? "primary" : "outline"}>
                {t.messageStatus[s]}
              </ActionButton>
            ))}
          </div>
          <ActionButton action={deleteMessage.bind(null, message.id)} variant="danger" confirmMessage="حذف الرسالة نهائيًا؟">
            <Trash2 className="size-4" /> حذف
          </ActionButton>
        </footer>
      </article>
    </>
  );
}
