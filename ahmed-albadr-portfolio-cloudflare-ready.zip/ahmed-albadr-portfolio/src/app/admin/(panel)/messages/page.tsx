import Link from "next/link";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { Badge } from "@/components/ui/badge";
import { t } from "@/lib/i18n";
import { cn, formatDate } from "@/lib/utils";
import { adminQueries } from "@/services/admin/queries";
import { MESSAGE_STATUSES } from "@/types/content";

export const metadata = { title: "الرسائل" };

export default async function AdminMessages({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status } = await searchParams;
  const filter = (MESSAGE_STATUSES as readonly string[]).includes(status ?? "") ? status : undefined;
  const messages = await adminQueries.messages(filter);
  const tabs = [{ value: undefined, label: "الواردة" }, ...MESSAGE_STATUSES.map((s) => ({ value: s, label: t.messageStatus[s] }))];

  return (
    <>
      <AdminPageHeader title="رسائل التواصل" description="الرسائل الواردة من نموذج صفحة التواصل." />
      <nav className="mb-5 flex gap-2 overflow-x-auto" aria-label="تصفية">
        {tabs.map((tab) => (
          <Link
            key={tab.label}
            href={tab.value ? `/admin/messages?status=${tab.value}` : "/admin/messages"}
            className={cn("shrink-0 rounded-full border px-4 py-1.5 text-sm", filter === tab.value ? "border-primary/40 bg-primary/10 text-primary" : "border-border text-muted hover:text-foreground")}
          >
            {tab.label}
          </Link>
        ))}
      </nav>
      <AdminTable head={["المرسل", "النوع", "الحالة", "التاريخ"]} empty={!messages.length}>
        {messages.map((m) => (
          <tr key={m.id} className={cn("hover:bg-surface-2/40", m.status === "NEW" && "bg-primary/[0.03]")}>
            <Td>
              <Link href={`/admin/messages/${m.id}`} className="block hover:text-primary">
                <span className={cn("block", m.status === "NEW" ? "font-bold" : "font-medium")}>{m.name}</span>
                <span className="line-clamp-1 text-xs text-subtle">{m.message}</span>
              </Link>
            </Td>
            <Td className="text-muted">{t.inquiryType[m.type]}</Td>
            <Td><Badge tone={m.status === "NEW" ? "primary" : m.status === "REPLIED" ? "success" : "neutral"}>{t.messageStatus[m.status]}</Badge></Td>
            <Td end className="text-muted">{formatDate(m.createdAt)}</Td>
          </tr>
        ))}
      </AdminTable>
    </>
  );
}
