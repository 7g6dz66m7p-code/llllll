import { AdminPageHeader } from "@/components/admin/ui";
import { ServiceForm } from "@/components/admin/forms/catalog-forms";
import { saveService } from "@/services/admin/catalog";

export const metadata = { title: "خدمة جديدة" };

export default function NewPage() {
  return (
    <>
      <AdminPageHeader title="خدمة جديدة" />
      <ServiceForm action={saveService.bind(null, null)} />
    </>
  );
}
