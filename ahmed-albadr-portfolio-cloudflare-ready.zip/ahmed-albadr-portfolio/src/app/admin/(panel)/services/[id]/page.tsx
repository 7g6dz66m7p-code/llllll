import { notFound } from "next/navigation";
import { Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader } from "@/components/admin/ui";
import { ServiceForm } from "@/components/admin/forms/catalog-forms";
import { adminQueries } from "@/services/admin/queries";
import { deleteService, saveService } from "@/services/admin/catalog";

export const metadata = { title: "تعديل خدمة" };

export default async function EditPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const item = await adminQueries.service(id);
  if (!item) notFound();
  return (
    <>
      <AdminPageHeader title="تعديل خدمة" />
      <ServiceForm
        action={saveService.bind(null, item.id)}
        service={item}
        extraActions={
          <ActionButton action={deleteService.bind(null, item.id)} variant="danger" confirmMessage="حذف هذا العنصر نهائيًا؟">
            <Trash2 className="size-4" />
            حذف
          </ActionButton>
        }
      />
    </>
  );
}
