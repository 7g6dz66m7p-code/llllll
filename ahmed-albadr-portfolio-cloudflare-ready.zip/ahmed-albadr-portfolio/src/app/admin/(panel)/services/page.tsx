import Link from "next/link";
import { Pencil, Trash2 } from "lucide-react";
import { ActionButton } from "@/components/admin/action-button";
import { AdminPageHeader, AdminTable, Td } from "@/components/admin/ui";
import { Badge } from "@/components/ui/badge";
import { buttonStyles } from "@/components/ui/button";
import { DynamicIcon } from "@/lib/icons";
import { adminQueries } from "@/services/admin/queries";
import { deleteService } from "@/services/admin/catalog";

export const metadata = { title: "الخدمات" };

export default async function AdminServices() {
  const services = await adminQueries.services();
  return (
    <>
      <AdminPageHeader title="الخدمات" description="الخدمات المعروضة في صفحة الخدمات والصفحة الرئيسية." createHref="/admin/services/new" createLabel="خدمة جديدة" />
      <AdminTable head={["الخدمة", "الحالة", "الترتيب", ""]} empty={!services.length}>
        {services.map((s) => {
          return (
            <tr key={s.id} className="hover:bg-surface-2/40">
              <Td>
                <Link href={`/admin/services/${s.id}`} className="flex items-center gap-3 font-semibold hover:text-primary">
                  <span className="grid size-9 place-items-center rounded-xl bg-primary/10 text-primary"><DynamicIcon name={s.icon} className="size-4" /></span>
                  {s.title}
                </Link>
              </Td>
              <Td><Badge tone={s.published ? "success" : "neutral"}>{s.published ? "منشورة" : "مخفية"}</Badge></Td>
              <Td className="latin">{s.sortOrder}</Td>
              <Td end>
                <div className="flex justify-end gap-1">
                  <Link href={`/admin/services/${s.id}`} className={buttonStyles({ variant: "ghost", size: "icon" })} aria-label="تعديل"><Pencil className="size-4" /></Link>
                  <ActionButton action={deleteService.bind(null, s.id)} size="icon" title="حذف" confirmMessage={`حذف "${s.title}"؟`} className="hover:text-danger"><Trash2 className="size-4" /></ActionButton>
                </div>
              </Td>
            </tr>
          );
        })}
      </AdminTable>
    </>
  );
}
