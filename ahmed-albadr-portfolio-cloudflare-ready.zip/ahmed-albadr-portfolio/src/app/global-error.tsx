"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="ar" dir="rtl">
      <body style={{ margin: 0, minHeight: "100dvh", display: "grid", placeItems: "center", background: "#05080f", color: "#e6edf7", fontFamily: "system-ui, sans-serif" }}>
        <div style={{ textAlign: "center", padding: 24 }}>
          <h1 style={{ fontSize: 28, marginBottom: 12 }}>حدث خطأ غير متوقع</h1>
          <p style={{ color: "#94a3b8", marginBottom: 24 }}>نعتذر عن ذلك. حاول تحديث الصفحة.</p>
          <button onClick={reset} style={{ background: "#22d3ee", color: "#03101c", border: 0, borderRadius: 999, padding: "12px 28px", fontWeight: 600, cursor: "pointer" }}>
            إعادة المحاولة
          </button>
        </div>
      </body>
    </html>
  );
}
