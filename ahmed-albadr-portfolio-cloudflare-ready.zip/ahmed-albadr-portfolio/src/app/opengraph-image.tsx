import { ImageResponse } from "next/og";

export const alt = "أحمد البدر | Ahmed Al-Badr — Founder • Entrepreneur • AI Product Builder";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

// Latin-only artwork: the edge OG renderer has no Arabic shaping without bundling a font file.
export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: "72px 80px",
          background: "radial-gradient(circle at 85% 10%, rgba(34,211,238,0.35), transparent 45%), radial-gradient(circle at 0% 100%, rgba(56,189,248,0.18), transparent 50%), #05080f",
          color: "#e6edf7",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div
            style={{
              width: 72,
              height: 72,
              borderRadius: 20,
              background: "linear-gradient(135deg, #22d3ee, #0284c7)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 40,
              fontWeight: 800,
              color: "#03101c",
            }}
          >
            A
          </div>
          <div style={{ fontSize: 24, letterSpacing: 8, color: "#94a3b8" }}>FOUNDER · BUILDER</div>
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 96, fontWeight: 800, letterSpacing: -2, lineHeight: 1 }}>AHMED AL-BADR</div>
          <div style={{ marginTop: 28, fontSize: 36, color: "#22d3ee", letterSpacing: 2 }}>Founder • Entrepreneur • AI Product Builder</div>
        </div>
        <div style={{ display: "flex", gap: 16, fontSize: 24, color: "#94a3b8" }}>
          {["Mahara AI", "Bahith", "SALEEM AI", "Nuzum Iraq"].map((v) => (
            <div key={v} style={{ padding: "10px 22px", border: "1px solid rgba(148,163,184,0.25)", borderRadius: 999 }}>
              {v}
            </div>
          ))}
        </div>
      </div>
    ),
    size,
  );
}
