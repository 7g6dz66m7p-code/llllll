import type { Achievement, Service, SiteSettings, SocialLink, SocialPlatform, Stat } from "@/types/content";

export const defaultSiteSettings: SiteSettings = {
  heroName: "أحمد البدر",
  heroNameEn: "AHMED AL-BADR",
  heroRole: "مؤسس أعمال ومشاريع رقمية",
  heroIdentity: "Founder • Entrepreneur • AI Product Builder",
  heroDescription:
    "أبني منتجات رقمية وأنظمة تعتمد على التقنية والذكاء الاصطناعي لتحويل الأفكار إلى أعمال قابلة للنمو.",
  heroImage: "/images/ahmed-albadr-portrait.webp",
  primaryCtaLabel: "استكشف مشاريعي",
  secondaryCtaLabel: "تواصل معي",
  aboutHeadline: "أحمد البدر",
  aboutIdentity: "Entrepreneur & Digital Product Builder",
  aboutBody:
    "أعمل على تحويل الأفكار إلى منتجات رقمية حقيقية يستخدمها الناس وتدرّ قيمة مستدامة. أبدأ من المشكلة لا من التقنية، وأختبر الفكرة مع السوق قبل أن أكتب سطرًا واحدًا من الكود، ثم أبني بسرعة وأطلق مبكرًا وأتعلم من المستخدمين.\n\nأركّز على منتجات الذكاء الاصطناعي ومنصات SaaS والأنظمة التي تخدم السوق العراقي والعربي — منتجات عربية الهوية، عالمية الجودة، ومصممة لتكبر.",
  visionStatement: "بناء منتجات تقنية عربية تحل مشكلات حقيقية وتتحول إلى أعمال قابلة للتوسع.",
  contactEmail: process.env.CONTACT_EMAIL ?? null,
  whatsappNumber: process.env.CONTACT_WHATSAPP ?? null,
  location: "العراق",
  availability: "متاح لشراكات ومشاريع مختارة",
  seoDescription:
    "أحمد البدر — مؤسس أعمال ومشاريع رقمية وباني منتجات ذكاء اصطناعي. مؤسس مهارة، منصة باحث، SALEEM AI ونظم العراق.",
  ogImage: null,
};

export const statSeeds: Omit<Stat, "id">[] = [
  { label: "المشاريع النشطة", value: 4, suffix: null, icon: "Rocket", sortOrder: 1 },
  { label: "المنتجات الرقمية", value: 4, suffix: "+", icon: "Boxes", sortOrder: 2 },
  { label: "الأنظمة والمنصات", value: 8, suffix: "+", icon: "Layers", sortOrder: 3 },
  { label: "مشاريع قيد التطوير", value: 2, suffix: null, icon: "Hammer", sortOrder: 4 },
];

export const serviceSeeds: Omit<Service, "id">[] = [
  {
    title: "تطوير الأفكار الرقمية",
    description:
      "نحوّل الفكرة الخام إلى نموذج عمل واضح: المشكلة، الشريحة المستهدفة، القيمة المقدّمة، ونموذج الإيرادات — قبل استثمار أي ميزانية في التطوير.",
    icon: "Lightbulb",
    highlights: ["جلسات صياغة الفكرة", "تحليل السوق والمنافسين", "خارطة طريق المنتج"],
    ctaLabel: "ناقش فكرتك",
    ctaHref: "/contact?type=CONSULTING",
    published: true,
    sortOrder: 1,
  },
  {
    title: "بناء MVP",
    description:
      "نسخة أولى قابلة للإطلاق خلال أسابيع لا أشهر، تركّز على الميزات الجوهرية فقط لتختبر السوق وتجمع أول المستخدمين الحقيقيين.",
    icon: "Rocket",
    highlights: ["تصميم تجربة المستخدم", "تطوير سريع وقابل للتوسع", "إطلاق وقياس"],
    ctaLabel: "ابدأ مشروعك",
    ctaHref: "/contact?type=NEW_PROJECT",
    published: true,
    sortOrder: 2,
  },
  {
    title: "حلول الذكاء الاصطناعي",
    description:
      "دمج نماذج الذكاء الاصطناعي داخل منتجك أو عملياتك: مساعدات ذكية، تحليل المستندات، البحث في المعرفة الداخلية، وتوليد المحتوى.",
    icon: "BrainCircuit",
    highlights: ["مساعدات ووكلاء أذكياء", "RAG على بياناتك", "تقييم الجودة والتكلفة"],
    ctaLabel: "اكتشف الإمكانيات",
    ctaHref: "/contact?type=NEW_PROJECT",
    published: true,
    sortOrder: 3,
  },
  {
    title: "أتمتة الأعمال",
    description:
      "نرصد المهام المتكررة التي تستهلك وقت فريقك ونحوّلها إلى مسارات عمل آلية تربط أدواتك ببعضها وتقلل الأخطاء البشرية.",
    icon: "Workflow",
    highlights: ["تحليل العمليات الحالية", "ربط الأنظمة والأدوات", "أتمتة بموافقة بشرية"],
    ctaLabel: "أتمت عملك",
    ctaHref: "/contact?type=CONSULTING",
    published: true,
    sortOrder: 4,
  },
  {
    title: "تطوير المنصات والأنظمة",
    description:
      "منصات SaaS وأنظمة إدارة مبنية ببنية حديثة وآمنة: صلاحيات، اشتراكات، لوحات تحكم، وتكاملات — جاهزة للنمو من اليوم الأول.",
    icon: "Layers",
    highlights: ["معمارية قابلة للتوسع", "أمان وصلاحيات", "لوحات تحكم وتقارير"],
    ctaLabel: "ابنِ منصتك",
    ctaHref: "/contact?type=NEW_PROJECT",
    published: true,
    sortOrder: 5,
  },
  {
    title: "استشارات المنتجات الرقمية",
    description:
      "مراجعة منتجك الحالي أو خطتك التقنية: أولويات الميزات، اختيار التقنيات، التسعير، ومؤشرات النمو التي يجب أن تراقبها.",
    icon: "Compass",
    highlights: ["مراجعة المنتج", "استراتيجية تقنية", "خطط النمو والتسعير"],
    ctaLabel: "احجز استشارة",
    ctaHref: "/contact?type=CONSULTING",
    published: true,
    sortOrder: 6,
  },
];

export type AchievementSeed = Omit<Achievement, "id" | "ventureId" | "venture"> & { ventureSlug?: string };

export const achievementSeeds: AchievementSeed[] = [
  {
    year: 2026,
    title: "إطلاق منصة مهارة",
    description: "إطلاق منصة الذكاء الاصطناعي العربية بوحداتها الأساسية: المحادثة، المعرفة، الوكلاء، الأتمتة والاستوديو.",
    date: new Date("2026-01-15T00:00:00.000Z"),
    ventureSlug: "mahara",
    published: true,
    sortOrder: 1,
  },
  {
    year: 2026,
    title: "تطوير SALEEM AI",
    description: "بدء تطوير مساعد الأعمال الذكي لإدارة محادثات العملاء وأتمتة المهام عبر قنوات التواصل.",
    date: new Date("2026-02-10T00:00:00.000Z"),
    ventureSlug: "saleem-ai",
    published: true,
    sortOrder: 2,
  },
  {
    year: 2026,
    title: "إطلاق حلول نظم العراق",
    description: "إطلاق أول حزمة من أنظمة إدارة الأعمال المصممة لاحتياجات الشركات العراقية.",
    date: new Date("2026-03-01T00:00:00.000Z"),
    ventureSlug: "nuzum-iraq",
    published: true,
    sortOrder: 3,
  },
  {
    year: 2026,
    title: "تطوير منصة باحث",
    description: "بناء منصة البحث واكتشاف المعرفة المدعومة بالذكاء الاصطناعي مع إسناد موثّق للمصادر.",
    date: new Date("2026-04-01T00:00:00.000Z"),
    ventureSlug: "bahith",
    published: true,
    sortOrder: 4,
  },
];

/** Social links come from the database; these env-driven defaults cover the no-database mode. */
const socialEnv: Partial<Record<SocialPlatform, string | undefined>> = {
  WHATSAPP: process.env.CONTACT_WHATSAPP ? `https://wa.me/${process.env.CONTACT_WHATSAPP.replace(/\D/g, "")}` : undefined,
  EMAIL: process.env.CONTACT_EMAIL ? `mailto:${process.env.CONTACT_EMAIL}` : undefined,
  INSTAGRAM: process.env.SOCIAL_INSTAGRAM,
  LINKEDIN: process.env.SOCIAL_LINKEDIN,
  GITHUB: process.env.SOCIAL_GITHUB,
};

export const fallbackSocialLinks: SocialLink[] = (Object.entries(socialEnv) as [SocialPlatform, string | undefined][])
  .filter((entry): entry is [SocialPlatform, string] => Boolean(entry[1]))
  .map(([platform, url], index) => ({
    id: `seed-${platform.toLowerCase()}`,
    platform,
    url,
    label: null,
    active: true,
    sortOrder: index + 1,
  }));
