import NextAuth from "next-auth";
import { authConfig } from "@/lib/auth/auth.config";

const { auth } = NextAuth(authConfig);

/**
 * Optimistic gate for the admin area (redirects to /admin/login when no valid session).
 * Authoritative checks also run in the admin layout, every Server Action and every admin API route.
 */
export default auth;

export const config = {
  matcher: ["/admin/:path*", "/api/admin/:path*"],
};
