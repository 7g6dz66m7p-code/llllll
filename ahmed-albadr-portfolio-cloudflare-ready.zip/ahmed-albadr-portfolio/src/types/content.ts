// Domain types shared by public pages, admin and the static fallback content.
// They intentionally mirror the Prisma models without depending on the generated client,
// so the site can render from `src/data` when no database is configured.

export const VENTURE_STATUSES = ["LIVE", "BETA", "IN_DEVELOPMENT", "PLANNED"] as const;
export type VentureStatus = (typeof VENTURE_STATUSES)[number];

export const INQUIRY_TYPES = [
  "NEW_PROJECT",
  "PARTNERSHIP",
  "INVESTMENT",
  "CONSULTING",
  "MEDIA",
  "OTHER",
] as const;
export type InquiryType = (typeof INQUIRY_TYPES)[number];

export const MESSAGE_STATUSES = ["NEW", "READ", "REPLIED", "ARCHIVED"] as const;
export type MessageStatus = (typeof MESSAGE_STATUSES)[number];

export const SOCIAL_PLATFORMS = [
  "WHATSAPP",
  "EMAIL",
  "INSTAGRAM",
  "LINKEDIN",
  "GITHUB",
  "X",
  "YOUTUBE",
  "TELEGRAM",
] as const;
export type SocialPlatform = (typeof SOCIAL_PLATFORMS)[number];

export type PublishStatus = "DRAFT" | "PUBLISHED";

export interface VentureFeature {
  title: string;
  description: string;
}

export interface Venture {
  id: string;
  name: string;
  nameEn: string | null;
  slug: string;
  tagline: string | null;
  logo: string | null;
  coverImage: string | null;
  shortDescription: string;
  fullDescription: string;
  problem: string | null;
  solution: string | null;
  features: VentureFeature[];
  targetAudience: string[];
  screenshots: string[];
  category: string;
  status: VentureStatus;
  technologies: string[];
  websiteUrl: string | null;
  githubUrl: string | null;
  accentColor: string | null;
  featured: boolean;
  published: boolean;
  sortOrder: number;
  launchedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Insight {
  id: string;
  title: string;
  slug: string;
  coverImage: string | null;
  excerpt: string;
  content: string;
  category: string;
  status: PublishStatus;
  featured: boolean;
  publishedAt: Date | null;
  seoTitle: string | null;
  metaDescription: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  highlights: string[];
  ctaLabel: string;
  ctaHref: string;
  published: boolean;
  sortOrder: number;
}

export interface Achievement {
  id: string;
  year: number;
  title: string;
  description: string | null;
  date: Date | null;
  ventureId: string | null;
  venture?: { slug: string; name: string } | null;
  published: boolean;
  sortOrder: number;
}

export interface Stat {
  id: string;
  label: string;
  value: number;
  suffix: string | null;
  icon: string;
  sortOrder: number;
}

export interface SocialLink {
  id: string;
  platform: SocialPlatform;
  url: string;
  label: string | null;
  active: boolean;
  sortOrder: number;
}

export interface SiteSettings {
  heroName: string;
  heroNameEn: string;
  heroRole: string;
  heroIdentity: string;
  heroDescription: string;
  heroImage: string | null;
  primaryCtaLabel: string;
  secondaryCtaLabel: string;
  aboutHeadline: string;
  aboutIdentity: string;
  aboutBody: string;
  visionStatement: string;
  contactEmail: string | null;
  whatsappNumber: string | null;
  location: string | null;
  availability: string | null;
  seoDescription: string;
  ogImage: string | null;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  type: InquiryType;
  message: string;
  status: MessageStatus;
  createdAt: Date;
}

export interface MediaItem {
  id: string;
  key: string;
  url: string;
  filename: string;
  mimeType: string;
  size: number;
  alt: string | null;
  createdAt: Date;
}
