"use server";

import { db } from "@/lib/db/prisma";
import { settingsSchema } from "@/lib/validations/admin";
import { runAdminAction, type ActionResult } from "./shared";

export async function saveSettings(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("settings.save", settingsSchema, formData, async (data) => {
    await db().siteSettings.upsert({ where: { id: "main" }, create: { id: "main", ...data }, update: data });
    return { ok: true, message: "تم حفظ إعدادات الموقع" };
  });
}
