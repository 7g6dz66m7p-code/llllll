"use server";

import { db } from "@/lib/db/prisma";
import { ventureSchema } from "@/lib/validations/admin";
import { runAdminAction, runAdminMutation, type ActionResult } from "./shared";

export async function saveVenture(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("venture.save", ventureSchema, formData, async (data) => {
    if (id) {
      const before = await db().venture.findUniqueOrThrow({ where: { id }, select: { slug: true } });
      await db().venture.update({ where: { id }, data });
      return { ok: true, message: "تم تحديث المشروع", revalidate: [`/ventures/${before.slug}`, `/ventures/${data.slug}`] };
    }
    const created = await db().venture.create({ data });
    return { ok: true, message: "تم إنشاء المشروع", redirectTo: `/admin/ventures/${created.id}`, revalidate: [`/ventures/${data.slug}`] };
  });
}

export async function deleteVenture(id: string): Promise<ActionResult> {
  return runAdminMutation("venture.delete", async () => {
    const deleted = await db().venture.delete({ where: { id } });
    return { ok: true, message: "تم حذف المشروع", redirectTo: "/admin/ventures", revalidate: [`/ventures/${deleted.slug}`] };
  });
}

export async function toggleVentureFeatured(id: string): Promise<ActionResult> {
  return runAdminMutation("venture.feature", async () => {
    const v = await db().venture.findUniqueOrThrow({ where: { id }, select: { featured: true } });
    const updated = await db().venture.update({ where: { id }, data: { featured: !v.featured } });
    return { ok: true, revalidate: [`/ventures/${updated.slug}`] };
  });
}
