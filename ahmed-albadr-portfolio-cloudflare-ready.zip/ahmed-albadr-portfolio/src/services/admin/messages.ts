"use server";

import { db } from "@/lib/db/prisma";
import { messageStatusSchema } from "@/lib/validations/admin";
import { runAdminMutation, type ActionResult } from "./shared";

export async function setMessageStatus(id: string, status: string): Promise<ActionResult> {
  return runAdminMutation("message.status", async () => {
    await db().contactMessage.update({ where: { id }, data: { status: messageStatusSchema.parse(status) } });
  });
}

export async function deleteMessage(id: string): Promise<ActionResult> {
  return runAdminMutation("message.delete", async () => {
    await db().contactMessage.delete({ where: { id } });
    return { ok: true, message: "تم حذف الرسالة", redirectTo: "/admin/messages" };
  });
}
