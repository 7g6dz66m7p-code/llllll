"use server";

import { db } from "@/lib/db/prisma";
import { achievementSchema, serviceSchema, socialLinkSchema, statSchema } from "@/lib/validations/admin";
import { runAdminAction, runAdminMutation, type ActionResult } from "./shared";

// ---------- Services ----------
export async function saveService(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("service.save", serviceSchema, formData, async (data) => {
    if (id) await db().service.update({ where: { id }, data });
    else await db().service.create({ data });
    return { ok: true, message: id ? "تم تحديث الخدمة" : "تمت إضافة الخدمة", redirectTo: id ? undefined : "/admin/services" };
  });
}
export async function deleteService(id: string): Promise<ActionResult> {
  return runAdminMutation("service.delete", async () => {
    await db().service.delete({ where: { id } });
    return { ok: true, message: "تم حذف الخدمة" };
  });
}

// ---------- Achievements ----------
export async function saveAchievement(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("achievement.save", achievementSchema, formData, async (data) => {
    if (id) await db().achievement.update({ where: { id }, data });
    else await db().achievement.create({ data });
    return { ok: true, message: id ? "تم تحديث الإنجاز" : "تمت إضافة الإنجاز", redirectTo: id ? undefined : "/admin/achievements" };
  });
}
export async function deleteAchievement(id: string): Promise<ActionResult> {
  return runAdminMutation("achievement.delete", async () => {
    await db().achievement.delete({ where: { id } });
    return { ok: true, message: "تم حذف الإنجاز" };
  });
}

// ---------- Stats ----------
export async function saveStat(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("stat.save", statSchema, formData, async (data) => {
    if (id) await db().stat.update({ where: { id }, data });
    else await db().stat.create({ data });
    return { ok: true, message: id ? "تم تحديث الرقم" : "تمت إضافة الرقم", redirectTo: id ? undefined : "/admin/stats" };
  });
}
export async function deleteStat(id: string): Promise<ActionResult> {
  return runAdminMutation("stat.delete", async () => {
    await db().stat.delete({ where: { id } });
    return { ok: true, message: "تم الحذف" };
  });
}

// ---------- Social links ----------
export async function saveSocialLink(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("social.save", socialLinkSchema, formData, async (data) => {
    if (id) await db().socialLink.update({ where: { id }, data });
    else await db().socialLink.create({ data });
    return { ok: true, message: id ? "تم تحديث الرابط" : "تمت إضافة الرابط", redirectTo: id ? undefined : "/admin/social" };
  });
}
export async function deleteSocialLink(id: string): Promise<ActionResult> {
  return runAdminMutation("social.delete", async () => {
    await db().socialLink.delete({ where: { id } });
    return { ok: true, message: "تم حذف الرابط" };
  });
}
