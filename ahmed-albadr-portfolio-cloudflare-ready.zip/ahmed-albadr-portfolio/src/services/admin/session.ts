"use server";

import { AuthError } from "next-auth";
import { signIn, signOut } from "@/lib/auth";
import type { ActionResult } from "./shared";

export async function login(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  try {
    await signIn("credentials", {
      email: String(formData.get("email") ?? ""),
      password: String(formData.get("password") ?? ""),
      redirectTo: "/admin",
    });
    return { ok: true };
  } catch (error) {
    if (error instanceof AuthError) {
      const code = (error as AuthError & { code?: string }).code;
      return {
        ok: false,
        message: code === "rate_limited" ? "محاولات كثيرة. انتظر 15 دقيقة ثم حاول مجددًا." : "بيانات الدخول غير صحيحة.",
        values: { email: String(formData.get("email") ?? "") },
      };
    }
    throw error; // NEXT_REDIRECT on success
  }
}

export async function logout() {
  await signOut({ redirectTo: "/admin/login" });
}
