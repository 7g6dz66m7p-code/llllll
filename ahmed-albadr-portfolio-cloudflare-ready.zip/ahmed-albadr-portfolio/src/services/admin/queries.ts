import "server-only";
import { db } from "@/lib/db/prisma";
import { isDatabaseConfigured } from "@/lib/env";

/** Admin reads: uncached, include drafts/unpublished. Return empty data when no database is configured. */
const guard = <T>(fallback: T, run: () => Promise<T>) => (isDatabaseConfigured() ? run() : Promise.resolve(fallback));

export const adminQueries = {
  overview: () =>
    guard({ ventures: 0, insights: 0, services: 0, achievements: 0, newMessages: 0, media: 0, recentMessages: [] as Awaited<ReturnType<typeof recentMessages>> }, async () => {
      const [ventures, insights, services, achievements, newMessages, media, recent] = await Promise.all([
        db().venture.count(),
        db().insight.count(),
        db().service.count(),
        db().achievement.count(),
        db().contactMessage.count({ where: { status: "NEW" } }),
        db().media.count(),
        recentMessages(),
      ]);
      return { ventures, insights, services, achievements, newMessages, media, recentMessages: recent };
    }),
  ventures: () => guard([], () => db().venture.findMany({ orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }] })),
  venture: (id: string) => guard(null, () => db().venture.findUnique({ where: { id } })),
  ventureOptions: () => guard([], () => db().venture.findMany({ select: { id: true, name: true }, orderBy: { sortOrder: "asc" } })),
  insights: () => guard([], () => db().insight.findMany({ orderBy: [{ updatedAt: "desc" }] })),
  insight: (id: string) => guard(null, () => db().insight.findUnique({ where: { id } })),
  services: () => guard([], () => db().service.findMany({ orderBy: { sortOrder: "asc" } })),
  service: (id: string) => guard(null, () => db().service.findUnique({ where: { id } })),
  achievements: () => guard([], () => db().achievement.findMany({ orderBy: [{ year: "desc" }, { sortOrder: "asc" }], include: { venture: { select: { name: true } } } })),
  achievement: (id: string) => guard(null, () => db().achievement.findUnique({ where: { id } })),
  stats: () => guard([], () => db().stat.findMany({ orderBy: { sortOrder: "asc" } })),
  stat: (id: string) => guard(null, () => db().stat.findUnique({ where: { id } })),
  socialLinks: () => guard([], () => db().socialLink.findMany({ orderBy: { sortOrder: "asc" } })),
  socialLink: (id: string) => guard(null, () => db().socialLink.findUnique({ where: { id } })),
  messages: (status?: string) =>
    guard([], () =>
      db().contactMessage.findMany({
        where: status ? { status: status as never } : { status: { not: "ARCHIVED" } },
        orderBy: { createdAt: "desc" },
        take: 200,
      }),
    ),
  message: (id: string) => guard(null, () => db().contactMessage.findUnique({ where: { id } })),
  settings: () => guard(null, () => db().siteSettings.findUnique({ where: { id: "main" } })),
  media: () => guard([], () => db().media.findMany({ orderBy: { createdAt: "desc" }, take: 300 })),
};

function recentMessages() {
  return db().contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 5, select: { id: true, name: true, type: true, status: true, createdAt: true } });
}
