import "server-only";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { assertAdmin, UnauthorizedError } from "@/lib/auth";
import { isDatabaseConfigured } from "@/lib/env";
import { logger } from "@/lib/logger";
import { zodIssuesToFieldErrors } from "@/lib/validations/errors";

export type ActionResult = {
  ok: boolean;
  message?: string;
  fieldErrors?: Record<string, string>;
  /** Echo of submitted values so forms keep user input after a failed submit. */
  values?: Record<string, string>;
  redirectTo?: string;
  /** Concrete public paths affected by the mutation (e.g. `/ventures/mahara`). Not sent to the client. */
  revalidate?: string[];
};

export const initialActionResult: ActionResult = { ok: false };

export function formToObject(formData: FormData) {
  const out: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value === "string" && !key.startsWith("$ACTION")) out[key] = value;
  }
  return out;
}

const PUBLIC_PATHS = ["/", "/about", "/ventures", "/services", "/vision", "/achievements", "/insights", "/contact", "/privacy", "/terms", "/sitemap.xml"];

/**
 * Content can surface anywhere (home, footer, sitemap), so every public page is revalidated.
 * Dynamic pages are listed explicitly too: a layout-level revalidation alone does not purge
 * on-demand ISR entries such as `/ventures/[slug]`.
 */
export function revalidateSite(extraPaths: string[] = []) {
  revalidatePath("/", "layout");
  revalidatePath("/ventures/[slug]", "page");
  revalidatePath("/insights/[slug]", "page");
  // Arabic slugs: cover both the raw and the percent-encoded form of the path.
  const extras = extraPaths.flatMap((p) => [p, encodeURI(p)]);
  for (const path of new Set([...PUBLIC_PATHS, ...extras])) revalidatePath(path);
}

/**
 * Wraps an admin mutation: authorisation, database availability, validation and
 * central error handling. Known Prisma errors become friendly Arabic messages.
 */
export async function runAdminAction<S extends z.ZodType>(
  context: string,
  schema: S,
  formData: FormData,
  run: (data: z.output<S>) => Promise<ActionResult | void>,
): Promise<ActionResult> {
  const values = formToObject(formData);
  try {
    await assertAdmin();
    if (!isDatabaseConfigured()) return { ok: false, message: "قاعدة البيانات غير مُعدّة. أضف DATABASE_URL لتفعيل التعديل.", values };
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      return { ok: false, message: "تحقق من الحقول المدخلة", fieldErrors: zodIssuesToFieldErrors(parsed.error.issues), values };
    }
    const result = await run(parsed.data);
    return finish(result, { ok: true, message: "تم الحفظ بنجاح" });
  } catch (error) {
    return mapError(error, context, values);
  }
}

/** For simple id-based mutations (delete, toggle). */
export async function runAdminMutation(context: string, run: () => Promise<ActionResult | void>): Promise<ActionResult> {
  try {
    await assertAdmin();
    if (!isDatabaseConfigured()) return { ok: false, message: "قاعدة البيانات غير مُعدّة." };
    const result = await run();
    return finish(result, { ok: true, message: "تم التنفيذ" });
  } catch (error) {
    return mapError(error, context);
  }
}

function finish(result: ActionResult | void, fallback: ActionResult): ActionResult {
  const { revalidate, ...rest } = result ?? fallback;
  revalidateSite(revalidate);
  return rest;
}

function mapError(error: unknown, context: string, values?: Record<string, string>): ActionResult {
  if (error instanceof UnauthorizedError) return { ok: false, message: "انتهت الجلسة، سجّل الدخول مجددًا." };
  const code = (error as { code?: string })?.code;
  if (code === "P2002") return { ok: false, message: "القيمة مستخدمة مسبقًا (المعرّف أو المنصة مكرر).", fieldErrors: { slug: "هذا المعرّف مستخدم مسبقًا" }, values };
  if (code === "P2025") return { ok: false, message: "العنصر غير موجود أو تم حذفه.", values };
  logger.error(`admin.action.failed:${context}`, { error });
  return { ok: false, message: "حدث خطأ غير متوقع أثناء الحفظ.", values };
}
