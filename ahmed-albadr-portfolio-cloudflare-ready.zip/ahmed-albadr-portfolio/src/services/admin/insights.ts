"use server";

import { db } from "@/lib/db/prisma";
import { insightSchema } from "@/lib/validations/admin";
import { runAdminAction, runAdminMutation, type ActionResult } from "./shared";

export async function saveInsight(id: string | null, _prev: ActionResult, formData: FormData): Promise<ActionResult> {
  return runAdminAction("insight.save", insightSchema, formData, async (data) => {
    // Publishing without a date publishes now.
    const publishedAt = data.status === "PUBLISHED" ? (data.publishedAt ?? new Date()) : data.publishedAt;
    const payload = { ...data, publishedAt };
    if (id) {
      const before = await db().insight.findUniqueOrThrow({ where: { id }, select: { slug: true } });
      await db().insight.update({ where: { id }, data: payload });
      return { ok: true, message: "تم تحديث المقال", revalidate: [`/insights/${before.slug}`, `/insights/${data.slug}`] };
    }
    const created = await db().insight.create({ data: payload });
    return { ok: true, message: "تم إنشاء المقال", redirectTo: `/admin/insights/${created.id}`, revalidate: [`/insights/${data.slug}`] };
  });
}

export async function deleteInsight(id: string): Promise<ActionResult> {
  return runAdminMutation("insight.delete", async () => {
    const deleted = await db().insight.delete({ where: { id } });
    return { ok: true, message: "تم حذف المقال", redirectTo: "/admin/insights", revalidate: [`/insights/${deleted.slug}`] };
  });
}
