"use server";

import { db } from "@/lib/db/prisma";
import { isStorageConfigured } from "@/lib/env";
import { deleteObject } from "@/lib/storage";
import { runAdminMutation, type ActionResult } from "./shared";

export async function deleteMedia(id: string): Promise<ActionResult> {
  return runAdminMutation("media.delete", async () => {
    const media = await db().media.findUniqueOrThrow({ where: { id } });
    if (isStorageConfigured()) await deleteObject(media.key);
    await db().media.delete({ where: { id } });
    return { ok: true, message: "تم حذف الملف" };
  });
}
