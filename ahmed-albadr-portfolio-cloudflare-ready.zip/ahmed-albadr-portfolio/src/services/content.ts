import "server-only";
import { cache } from "react";
import { db } from "@/lib/db/prisma";
import { isDatabaseConfigured } from "@/lib/env";
import { logger } from "@/lib/logger";
import { fallbackVentures } from "@/data/ventures";
import { fallbackInsights } from "@/data/insights";
import { achievementSeeds, defaultSiteSettings, fallbackSocialLinks, serviceSeeds, statSeeds } from "@/data/site";
import type {
  Achievement,
  Insight,
  Service,
  SiteSettings,
  SocialLink,
  Stat,
  Venture,
  VentureFeature,
} from "@/types/content";

/**
 * Public content read layer.
 *
 * - With DATABASE_URL: PostgreSQL is the single source of truth. Errors propagate so that ISR keeps
 *   serving the last good page and failures surface in logs instead of silently showing stale seed data.
 * - Without DATABASE_URL (local preview, first deploy): the curated seed content in `src/data` is served.
 */
async function read<T>(label: string, fromDb: () => Promise<T>, fallback: () => T): Promise<T> {
  if (!isDatabaseConfigured()) return fallback();
  try {
    return await fromDb();
  } catch (error) {
    logger.error(`content.read.failed:${label}`, { error });
    throw error;
  }
}

function parseFeatures(value: unknown): VentureFeature[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((item) => {
    if (item && typeof item === "object" && "title" in item && typeof item.title === "string") {
      const description = "description" in item && typeof item.description === "string" ? item.description : "";
      return [{ title: item.title, description }];
    }
    return [];
  });
}

type VentureRow = Omit<Venture, "features"> & { features: unknown };
const toVenture = (row: VentureRow): Venture => ({ ...row, features: parseFeatures(row.features) });

// ---------- Ventures ----------

export const getVentures = cache(async (): Promise<Venture[]> =>
  read(
    "ventures",
    async () => {
      const rows = await db().venture.findMany({
        where: { published: true },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
      });
      return rows.map(toVenture);
    },
    () => fallbackVentures.filter((v) => v.published),
  ),
);

export const getFeaturedVentures = cache(async (limit = 4): Promise<Venture[]> => {
  const ventures = await getVentures();
  const featured = ventures.filter((v) => v.featured);
  return (featured.length ? featured : ventures).slice(0, limit);
});

export const getVentureBySlug = cache(async (slug: string): Promise<Venture | null> =>
  read(
    "venture",
    async () => {
      const row = await db().venture.findFirst({ where: { slug, published: true } });
      return row ? toVenture(row) : null;
    },
    () => fallbackVentures.find((v) => v.slug === slug && v.published) ?? null,
  ),
);

export async function getRelatedVentures(slug: string, limit = 3): Promise<Venture[]> {
  const ventures = await getVentures();
  return ventures.filter((v) => v.slug !== slug).slice(0, limit);
}

// ---------- Insights ----------

export const getInsights = cache(async (): Promise<Insight[]> =>
  read(
    "insights",
    () =>
      db().insight.findMany({
        where: { status: "PUBLISHED", publishedAt: { lte: new Date() } },
        orderBy: { publishedAt: "desc" },
      }),
    () =>
      fallbackInsights
        .filter((i) => i.status === "PUBLISHED")
        .sort((a, b) => (b.publishedAt?.getTime() ?? 0) - (a.publishedAt?.getTime() ?? 0)),
  ),
);

export const getInsightBySlug = cache(async (slug: string): Promise<Insight | null> =>
  read(
    "insight",
    () => db().insight.findFirst({ where: { slug, status: "PUBLISHED", publishedAt: { lte: new Date() } } }),
    () => fallbackInsights.find((i) => i.slug === slug && i.status === "PUBLISHED") ?? null,
  ),
);

// ---------- Services / Achievements / Stats ----------

export const getServices = cache(async (): Promise<Service[]> =>
  read(
    "services",
    () => db().service.findMany({ where: { published: true }, orderBy: { sortOrder: "asc" } }),
    () => serviceSeeds.map((s, i) => ({ ...s, id: `seed-service-${i + 1}` })),
  ),
);

export const getAchievements = cache(async (): Promise<Achievement[]> =>
  read(
    "achievements",
    () =>
      db().achievement.findMany({
        where: { published: true },
        orderBy: [{ year: "desc" }, { sortOrder: "asc" }],
        include: { venture: { select: { slug: true, name: true } } },
      }),
    () =>
      achievementSeeds.map(({ ventureSlug, ...a }, i) => {
        const venture = fallbackVentures.find((v) => v.slug === ventureSlug);
        return {
          ...a,
          id: `seed-achievement-${i + 1}`,
          ventureId: venture?.id ?? null,
          venture: venture ? { slug: venture.slug, name: venture.name } : null,
        };
      }),
  ),
);

export const getStats = cache(async (): Promise<Stat[]> =>
  read(
    "stats",
    () => db().stat.findMany({ orderBy: { sortOrder: "asc" } }),
    () => statSeeds.map((s, i) => ({ ...s, id: `seed-stat-${i + 1}` })),
  ),
);

// ---------- Settings / Social ----------

export const getSiteSettings = cache(async (): Promise<SiteSettings> =>
  read(
    "settings",
    async () => {
      const row = await db().siteSettings.findUnique({ where: { id: "main" } });
      if (!row) return defaultSiteSettings;
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { id, updatedAt, ...settings } = row;
      return settings;
    },
    () => defaultSiteSettings,
  ),
);

export const getSocialLinks = cache(async (): Promise<SocialLink[]> =>
  read(
    "social",
    () => db().socialLink.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    () => fallbackSocialLinks,
  ),
);
