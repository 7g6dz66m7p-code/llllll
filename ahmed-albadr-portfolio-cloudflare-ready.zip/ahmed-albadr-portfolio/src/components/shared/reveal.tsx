"use client";

import { useEffect, useRef, type CSSProperties, type HTMLAttributes, type ReactNode } from "react";

/**
 * Scroll reveal as progressive enhancement: content is fully visible in the server HTML
 * (crawlers, no-JS, slow hydration). Only when the `js` class is present on <html> does CSS
 * hide un-revealed elements; a single shared IntersectionObserver then reveals them.
 * Reduced-motion users get no animation (see globals.css).
 */
let observer: IntersectionObserver | null = null;

function getObserver() {
  if (!observer) {
    observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.setAttribute("data-revealed", "");
            observer?.unobserve(entry.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.05 },
    );
  }
  return observer;
}

export function Reveal({
  as = "div",
  delay = 0,
  className,
  style,
  children,
  ...props
}: {
  as?: "div" | "li" | "section";
  delay?: number;
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
} & Omit<HTMLAttributes<HTMLElement>, "style" | "className" | "children">) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = getObserver();
    obs.observe(el);
    return () => obs.unobserve(el);
  }, []);

  const Tag = as;
  return (
    <Tag
      ref={ref as never}
      data-reveal=""
      className={className}
      style={delay ? { ...style, transitionDelay: `${Math.round(delay * 1000)}ms` } : style}
      {...props}
    >
      {children}
    </Tag>
  );
}
