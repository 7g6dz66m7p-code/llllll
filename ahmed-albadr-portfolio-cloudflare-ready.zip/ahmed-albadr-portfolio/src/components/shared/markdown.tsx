import ReactMarkdown, { type Components } from "react-markdown";
import remarkGfm from "remark-gfm";
import { cn } from "@/lib/utils";

const SAFE_PROTOCOL = /^(https?:|mailto:|tel:|\/|#)/i;

const components: Components = {
  a: ({ href, children }) => {
    const safe = href && SAFE_PROTOCOL.test(href) ? href : undefined;
    const external = safe?.startsWith("http");
    return (
      <a href={safe} {...(external && { target: "_blank", rel: "noopener noreferrer nofollow" })}>
        {children}
      </a>
    );
  },
  // eslint-disable-next-line @next/next/no-img-element
  img: ({ src, alt }) => (typeof src === "string" && SAFE_PROTOCOL.test(src) ? <img src={src} alt={alt ?? ""} loading="lazy" decoding="async" className="rounded-2xl" /> : null),
};

/**
 * Markdown renderer for admin-authored content. Raw HTML is skipped entirely (no XSS surface),
 * and link/image URLs are restricted to safe protocols.
 */
export function Markdown({ content, className }: { content: string; className?: string }) {
  return (
    <div className={cn("prose-article", className)}>
      <ReactMarkdown remarkPlugins={[remarkGfm]} skipHtml components={components}>
        {content}
      </ReactMarkdown>
    </div>
  );
}
