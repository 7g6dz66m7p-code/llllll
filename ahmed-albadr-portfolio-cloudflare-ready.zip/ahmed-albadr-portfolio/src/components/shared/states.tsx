import { AlertTriangle, Inbox, RotateCcw } from "lucide-react";
import type { ReactNode } from "react";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export function EmptyState({
  title = t.states.emptyTitle,
  description = t.states.emptyDescription,
  action,
  className,
}: {
  title?: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("card-surface flex flex-col items-center rounded-[var(--radius-card)] px-6 py-16 text-center", className)}>
      <span className="mb-5 grid size-14 place-items-center rounded-2xl bg-primary/10 text-primary">
        <Inbox className="size-6" />
      </span>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-muted">{description}</p>
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}

export function ErrorState({
  title = t.states.errorTitle,
  description = t.states.errorDescription,
  onRetry,
  className,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
  className?: string;
}) {
  return (
    <div role="alert" className={cn("card-surface flex flex-col items-center rounded-[var(--radius-card)] px-6 py-16 text-center", className)}>
      <span className="mb-5 grid size-14 place-items-center rounded-2xl bg-danger/10 text-danger">
        <AlertTriangle className="size-6" />
      </span>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 max-w-sm text-sm text-muted">{description}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-6 inline-flex items-center gap-2 rounded-full border border-border-strong px-5 py-2 text-sm font-medium transition-colors hover:border-primary/50 hover:text-primary"
        >
          <RotateCcw className="size-4" />
          {t.common.retry}
        </button>
      )}
    </div>
  );
}

export function LoadingState({ variant = "cards", count = 3 }: { variant?: "cards" | "page" | "list"; count?: number }) {
  if (variant === "page") {
    return (
      <div className="container-page section-y" aria-busy="true" aria-label={t.common.loading}>
        <Skeleton className="mb-6 h-4 w-32" />
        <Skeleton className="mb-4 h-12 w-2/3" />
        <Skeleton className="mb-12 h-5 w-1/2" />
        <div className="grid gap-6 md:grid-cols-3">
          {Array.from({ length: count }).map((_, i) => (
            <Skeleton key={i} className="h-72 rounded-[var(--radius-card)]" />
          ))}
        </div>
      </div>
    );
  }
  if (variant === "list") {
    return (
      <div className="space-y-3" aria-busy="true" aria-label={t.common.loading}>
        {Array.from({ length: count }).map((_, i) => (
          <Skeleton key={i} className="h-16" />
        ))}
      </div>
    );
  }
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3" aria-busy="true" aria-label={t.common.loading}>
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className="h-80 rounded-[var(--radius-card)]" />
      ))}
    </div>
  );
}
