import Link from "next/link";
import { cn } from "@/lib/utils";

/** AB monogram + wordmark. Pure SVG/CSS so it renders instantly with no image request. */
export function BrandMark({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <Link href="/" className={cn("group inline-flex items-center gap-3", className)} aria-label="أحمد البدر — الرئيسية">
      <span className="relative grid size-10 place-items-center overflow-hidden rounded-xl bg-gradient-to-br from-primary/90 to-accent/70 shadow-[0_8px_24px_-8px_rgb(var(--primary)/0.7)] transition-transform duration-500 group-hover:scale-105 group-hover:rotate-[-4deg]">
        <svg viewBox="0 0 32 32" className="size-6 text-primary-fg" aria-hidden>
          <path d="M6 25 13.2 7h2.6L23 25h-3.1l-1.7-4.4h-7.4L9.1 25H6Zm5.8-7h5.4L14.5 11l-2.7 7Z" fill="currentColor" />
          <circle cx="25.5" cy="8.5" r="2.5" fill="currentColor" opacity="0.85" />
        </svg>
      </span>
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-[1.05rem] font-bold text-foreground">أحمد البدر</span>
          <span className="latin mt-1 text-[0.62rem] font-semibold tracking-[0.22em] text-subtle">AHMED AL-BADR</span>
        </span>
      )}
    </Link>
  );
}
