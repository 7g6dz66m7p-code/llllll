"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useRef, useState, type FormEvent } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { t } from "@/lib/i18n";
import { contactSchema } from "@/lib/validations/contact";
import { zodIssuesToFieldErrors } from "@/lib/validations/errors";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/form";
import { INQUIRY_TYPES, type InquiryType } from "@/types/content";

type Status = "idle" | "submitting" | "success";

export function ContactForm() {
  const params = useSearchParams();
  const initialType = (INQUIRY_TYPES as readonly string[]).includes(params.get("type") ?? "") ? (params.get("type") as InquiryType) : "NEW_PROJECT";
  const venture = params.get("venture");
  const [status, setStatus] = useState<Status>("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const startedAt = useRef<number>(0);
  const formRef = useRef<HTMLFormElement>(null);

  const markStarted = () => {
    if (!startedAt.current) startedAt.current = Date.now();
  };

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = {
      name: String(form.get("name") ?? ""),
      email: String(form.get("email") ?? ""),
      phone: String(form.get("phone") ?? ""),
      type: String(form.get("type") ?? ""),
      message: String(form.get("message") ?? ""),
      website: String(form.get("website") ?? ""),
      elapsed: startedAt.current ? Date.now() - startedAt.current : 0,
    };

    const parsed = contactSchema.safeParse(payload);
    if (!parsed.success) {
      setErrors(zodIssuesToFieldErrors(parsed.error.issues));
      return;
    }
    setErrors({});
    setStatus("submitting");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await res.json().catch(() => ({}))) as { ok?: boolean; message?: string; fieldErrors?: Record<string, string> };
      if (!res.ok || !data.ok) {
        if (data.fieldErrors) setErrors(data.fieldErrors);
        toast.error(res.status === 429 ? t.contact.rateLimited : (data.message ?? t.contact.genericError));
        setStatus("idle");
        return;
      }
      setStatus("success");
      formRef.current?.reset();
      toast.success(t.contact.success);
    } catch {
      toast.error(t.contact.genericError);
      setStatus("idle");
    }
  }

  if (status === "success") {
    return (
      <div className="flex flex-col items-center py-16 text-center" role="status">
        <span className="mb-6 grid size-16 place-items-center rounded-full bg-success/10 text-success ring-8 ring-success/5">
          <CheckCircle2 className="size-8" />
        </span>
        <h3 className="text-2xl font-bold">شكرًا لتواصلك!</h3>
        <p className="mt-3 max-w-sm text-muted">{t.contact.success}</p>
        <Button variant="outline" className="mt-8" onClick={() => setStatus("idle")}>
          إرسال رسالة أخرى
        </Button>
      </div>
    );
  }

  const describe = (name: string) => (errors[name] ? { "aria-invalid": true, "aria-describedby": `${name}-error` } : {});
  const submitting = status === "submitting";

  return (
    <form ref={formRef} onSubmit={onSubmit} onFocus={markStarted} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={t.contact.name} htmlFor="name" error={errors.name}>
          <Input id="name" name="name" autoComplete="name" required maxLength={100} {...describe("name")} />
        </Field>
        <Field label={t.contact.email} htmlFor="email" error={errors.email}>
          <Input id="email" name="email" type="email" dir="ltr" autoComplete="email" required maxLength={160} className="text-start" {...describe("email")} />
        </Field>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={t.contact.phone} htmlFor="phone" error={errors.phone}>
          <Input id="phone" name="phone" type="tel" dir="ltr" autoComplete="tel" maxLength={30} className="text-start" {...describe("phone")} />
        </Field>
        <Field label={t.contact.type} htmlFor="type" error={errors.type}>
          <Select id="type" name="type" defaultValue={initialType} {...describe("type")}>
            {INQUIRY_TYPES.map((type) => (
              <option key={type} value={type}>
                {t.inquiryType[type]}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <Field label={t.contact.message} htmlFor="message" error={errors.message}>
        <Textarea
          id="message"
          name="message"
          required
          maxLength={4000}
          rows={6}
          placeholder={t.contact.messagePlaceholder}
          defaultValue={venture ? `أرغب بالتواصل بخصوص مشروع: ${venture}\n\n` : undefined}
          {...describe("message")}
        />
      </Field>

      {/* Honeypot — hidden from humans and assistive tech */}
      <div aria-hidden className="absolute -start-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor="website">Website</label>
        <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <div className="flex flex-col-reverse items-start gap-4 pt-2 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-subtle">
          {t.contact.privacy}{" "}
          <Link href="/privacy" className="font-medium text-primary underline-offset-4 hover:underline">
            اقرأ السياسة
          </Link>
        </p>
        <Button type="submit" size="lg" disabled={submitting} className="w-full sm:w-auto">
          {submitting ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4 ltr:-scale-x-100" />}
          {submitting ? t.contact.sending : t.contact.submit}
        </Button>
      </div>
    </form>
  );
}
