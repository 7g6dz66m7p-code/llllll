import Link from "next/link";
import { ChevronLeft } from "lucide-react";
import type { ReactNode } from "react";
import { t } from "@/lib/i18n";
import { JsonLd, breadcrumbSchema } from "@/lib/seo/json-ld";

/** Inner-page hero with breadcrumbs (+ BreadcrumbList structured data). */
export function PageHeader({
  eyebrow,
  title,
  description,
  breadcrumbs,
  children,
}: {
  eyebrow?: string;
  title: ReactNode;
  description?: ReactNode;
  breadcrumbs: { name: string; path: string }[];
  children?: ReactNode;
}) {
  const trail = [{ name: t.nav.home, path: "/" }, ...breadcrumbs];
  return (
    <section className="relative isolate overflow-hidden pt-36 pb-14 md:pt-44 md:pb-20">
      <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden>
        <div className="bg-grid mask-radial absolute inset-0" />
        <div className="absolute -top-48 start-1/2 h-[30rem] w-[44rem] -translate-x-1/2 rounded-full bg-primary/12 blur-[120px] rtl:translate-x-1/2" />
      </div>
      <div className="container-page">
        <nav aria-label="مسار التنقل" className="animate-fade-up mb-8">
          <ol className="flex flex-wrap items-center gap-1.5 text-xs text-subtle">
            {trail.map((item, i) => (
              <li key={item.path} className="flex items-center gap-1.5">
                {i < trail.length - 1 ? (
                  <>
                    <Link href={item.path} className="transition-colors hover:text-primary">
                      {item.name}
                    </Link>
                    <ChevronLeft className="size-3 ltr:rotate-180" aria-hidden />
                  </>
                ) : (
                  <span aria-current="page" className="text-muted">
                    {item.name}
                  </span>
                )}
              </li>
            ))}
          </ol>
        </nav>
        {eyebrow && (
          <p className="latin animate-fade-up mb-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.25em] text-primary" style={{ animationDelay: "60ms" }}>
            <span className="h-px w-6 bg-primary/60" aria-hidden />
            {eyebrow}
          </p>
        )}
        <h1 className="animate-fade-up max-w-4xl text-4xl font-bold sm:text-5xl md:text-6xl" style={{ animationDelay: "120ms" }}>
          {title}
        </h1>
        {description && (
          <p className="animate-fade-up mt-6 max-w-2xl text-lg leading-9 text-muted" style={{ animationDelay: "200ms" }}>
            {description}
          </p>
        )}
        {children && <div className="animate-fade-up mt-10" style={{ animationDelay: "280ms" }}>{children}</div>}
      </div>
      <JsonLd data={breadcrumbSchema(trail)} />
    </section>
  );
}
