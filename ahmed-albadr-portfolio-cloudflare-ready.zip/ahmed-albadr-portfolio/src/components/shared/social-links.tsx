import { Mail, MessageCircle, Send } from "lucide-react";
import { GithubIcon, InstagramIcon, LinkedinIcon, XIcon, YoutubeIcon, type IconComponent } from "./brand-icons";
import { cn } from "@/lib/utils";
import type { SocialLink, SocialPlatform } from "@/types/content";

export const socialMeta: Record<SocialPlatform, { icon: IconComponent; label: string }> = {
  WHATSAPP: { icon: MessageCircle, label: "WhatsApp" },
  EMAIL: { icon: Mail, label: "Email" },
  INSTAGRAM: { icon: InstagramIcon, label: "Instagram" },
  LINKEDIN: { icon: LinkedinIcon, label: "LinkedIn" },
  GITHUB: { icon: GithubIcon, label: "GitHub" },
  X: { icon: XIcon, label: "X" },
  YOUTUBE: { icon: YoutubeIcon, label: "YouTube" },
  TELEGRAM: { icon: Send, label: "Telegram" },
};

export function SocialLinks({
  links,
  variant = "icons",
  className,
}: {
  links: SocialLink[];
  variant?: "icons" | "buttons";
  className?: string;
}) {
  if (!links.length) return null;
  return (
    <ul className={cn("flex flex-wrap gap-2", variant === "buttons" && "gap-3", className)}>
      {links.map((link) => {
        const meta = socialMeta[link.platform];
        const Icon = meta.icon;
        const label = link.label || meta.label;
        const external = !link.url.startsWith("mailto:") && !link.url.startsWith("tel:");
        return (
          <li key={link.id}>
            <a
              href={link.url}
              {...(external && { target: "_blank", rel: "noopener noreferrer" })}
              aria-label={label}
              className={cn(
                "group inline-flex items-center transition-all duration-300",
                variant === "icons"
                  ? "size-10 justify-center rounded-full border border-border text-muted hover:-translate-y-0.5 hover:border-primary/40 hover:text-primary"
                  : "glass h-12 gap-3 rounded-2xl px-5 text-sm font-medium text-foreground hover:-translate-y-0.5 hover:border-primary/40",
              )}
            >
              <Icon className={cn("size-[1.1rem]", variant === "buttons" && "text-primary")} />
              {variant === "buttons" && <span className="latin">{label}</span>}
            </a>
          </li>
        );
      })}
    </ul>
  );
}
