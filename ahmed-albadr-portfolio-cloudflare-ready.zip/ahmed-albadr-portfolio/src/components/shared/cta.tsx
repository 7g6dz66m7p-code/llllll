import { ArrowLeft, MessageSquareText } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import { Reveal } from "./reveal";

export function CTA({
  title = "لديك فكرة تستحق أن تتحول إلى منتج؟",
  description = "سواء كنت تبحث عن شريك لبناء منتج رقمي، أو تريد دمج الذكاء الاصطناعي في عملك — لنبدأ بمحادثة.",
  primaryLabel = "ابدأ مشروعك",
  primaryHref = "/contact",
  secondaryLabel = "استكشف المشاريع",
  secondaryHref = "/ventures",
}: {
  title?: string;
  description?: string;
  primaryLabel?: string;
  primaryHref?: string;
  secondaryLabel?: string;
  secondaryHref?: string;
}) {
  return (
    <section className="container-page section-y">
      <Reveal className="relative overflow-hidden rounded-[var(--radius-panel)] border border-primary/20 bg-gradient-to-br from-surface-2 via-surface to-background px-6 py-16 text-center sm:px-12 md:py-20">
        <div className="bg-grid mask-radial pointer-events-none absolute inset-0 opacity-60" aria-hidden />
        <div className="pointer-events-none absolute -top-24 start-1/2 h-64 w-[36rem] -translate-x-1/2 rounded-full bg-primary/20 blur-3xl rtl:translate-x-1/2" aria-hidden />
        <div className="relative mx-auto max-w-2xl">
          <span className="mx-auto mb-6 grid size-14 place-items-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/20">
            <MessageSquareText className="size-6" />
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl">{title}</h2>
          <p className="mx-auto mt-5 max-w-xl text-muted md:text-lg">{description}</p>
          <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <ButtonLink href={primaryHref} size="lg">
              {primaryLabel}
              <ArrowLeft className="size-4 transition-transform duration-300 group-hover/btn:-translate-x-1 ltr:rotate-180" />
            </ButtonLink>
            <ButtonLink href={secondaryHref} size="lg" variant="secondary">
              {secondaryLabel}
            </ButtonLink>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
