"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { m } from "framer-motion";
import { mainNav, isActivePath } from "@/lib/navigation";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { BrandMark } from "@/components/shared/brand-mark";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { ButtonLink } from "@/components/ui/button";
import { MobileMenu } from "./mobile-menu";

export function Navbar() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 sm:px-4">
      <nav
        aria-label="التنقل الرئيسي"
        className={cn(
          "mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 rounded-2xl px-3 transition-all duration-500 ease-[var(--ease-premium)] sm:px-5",
          scrolled ? "glass shadow-[0_12px_40px_-20px_rgb(0_0_0/0.6)]" : "border border-transparent",
        )}
      >
        <BrandMark />

        <ul className="hidden items-center gap-1 lg:flex">
          {mainNav.map((item) => {
            const active = isActivePath(pathname, item.href);
            return (
              <li key={item.href} className="relative">
                <Link
                  href={item.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "relative z-10 block rounded-full px-3.5 py-2 text-sm font-medium transition-colors duration-300",
                    active ? "text-foreground" : "text-muted hover:text-foreground",
                  )}
                >
                  {item.label}
                </Link>
                {active && (
                  <m.span
                    layoutId="nav-active"
                    className="absolute inset-0 rounded-full bg-surface-2 ring-1 ring-border"
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                    aria-hidden
                  />
                )}
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-1.5">
          <ThemeToggle />
          <ButtonLink href="/contact" size="sm" className="hidden sm:inline-flex">
            {t.nav.cta}
            <ArrowLeft className="size-4 transition-transform duration-300 group-hover/btn:-translate-x-0.5 ltr:rotate-180" />
          </ButtonLink>
          <MobileMenu />
        </div>
      </nav>
    </header>
  );
}
