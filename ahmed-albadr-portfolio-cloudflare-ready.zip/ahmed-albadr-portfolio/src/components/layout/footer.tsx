import Link from "next/link";
import { ArrowUpLeft } from "lucide-react";
import { footerNav } from "@/lib/navigation";
import { t } from "@/lib/i18n";
import { BrandMark } from "@/components/shared/brand-mark";
import { SocialLinks } from "@/components/shared/social-links";
import type { SocialLink, Venture } from "@/types/content";

export function Footer({ ventures, socialLinks, email }: { ventures: Venture[]; socialLinks: SocialLink[]; email: string | null }) {
  const year = new Date().getFullYear();
  return (
    <footer className="relative mt-12 border-t border-border">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" aria-hidden />
      <div className="container-page grid gap-12 py-16 md:grid-cols-12">
        <div className="md:col-span-5">
          <BrandMark />
          <p className="mt-6 max-w-sm text-muted">{t.footer.tagline}</p>
          <p className="latin mt-3 text-xs font-semibold tracking-[0.2em] text-subtle">{t.brand.identity}</p>
          <SocialLinks links={socialLinks} className="mt-8" />
        </div>

        <div className="md:col-span-3">
          <h2 className="mb-5 text-sm font-semibold text-foreground">{t.footer.explore}</h2>
          <ul className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm md:grid-cols-1">
            {footerNav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-muted transition-colors hover:text-primary">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="md:col-span-4">
          <h2 className="mb-5 text-sm font-semibold text-foreground">{t.footer.ventures}</h2>
          <ul className="space-y-3 text-sm">
            {ventures.slice(0, 6).map((v) => (
              <li key={v.id}>
                <Link href={`/ventures/${v.slug}`} className="group inline-flex items-center gap-2 text-muted transition-colors hover:text-primary">
                  {v.name}
                  {v.nameEn && v.nameEn !== v.name && <span className="latin text-xs text-subtle">{v.nameEn}</span>}
                  <ArrowUpLeft className="size-3.5 opacity-0 transition-all duration-300 group-hover:opacity-100 ltr:-scale-x-100" />
                </Link>
              </li>
            ))}
          </ul>
          {email && (
            <a href={`mailto:${email}`} className="latin mt-8 inline-block text-sm text-foreground transition-colors hover:text-primary">
              {email}
            </a>
          )}
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container-page flex flex-col items-center justify-between gap-4 py-6 text-xs text-subtle sm:flex-row">
          <p>
            © {year} {t.brand.name}. {t.footer.rights}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2">
            <Link href="/privacy" className="transition-colors hover:text-primary">
              سياسة الخصوصية
            </Link>
            <Link href="/terms" className="transition-colors hover:text-primary">
              شروط الاستخدام
            </Link>
            <span className="latin tracking-[0.18em]">{t.brand.nameEn}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
