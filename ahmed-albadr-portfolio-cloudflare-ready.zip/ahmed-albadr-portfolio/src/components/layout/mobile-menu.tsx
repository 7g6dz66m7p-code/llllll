"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useId, useState } from "react";
import { AnimatePresence, m } from "framer-motion";
import { ArrowLeft, Menu, X } from "lucide-react";
import { footerNav, isActivePath, mainNav } from "@/lib/navigation";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { ButtonLink } from "@/components/ui/button";

export function MobileMenu() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const panelId = useId();
  const items = [...mainNav, footerNav[footerNav.length - 1]!];

  // Close on route change.
  const [lastPath, setLastPath] = useState(pathname);
  if (pathname !== lastPath) {
    setLastPath(pathname);
    setOpen(false);
  }

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls={panelId}
        aria-label={open ? t.nav.closeMenu : t.nav.openMenu}
        className="relative z-[60] inline-flex size-10 items-center justify-center rounded-full text-foreground transition-colors hover:bg-surface-2"
      >
        {open ? <X className="size-5" /> : <Menu className="size-5" />}
      </button>

      <AnimatePresence>
        {open && (
          <m.div
            id={panelId}
            role="dialog"
            aria-modal="true"
            aria-label="القائمة"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl"
          >
            <div className="bg-grid mask-radial pointer-events-none absolute inset-0 opacity-50" aria-hidden />
            <nav className="relative flex h-full flex-col px-6 pb-10 pt-28">
              <ul className="flex flex-col gap-1">
                {items.map((item, i) => {
                  const active = isActivePath(pathname, item.href);
                  return (
                    <m.li
                      key={item.href}
                      initial={{ opacity: 0, x: 24 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.04 * i, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    >
                      <Link
                        href={item.href}
                        aria-current={active ? "page" : undefined}
                        className={cn(
                          "flex items-center justify-between rounded-2xl px-4 py-3.5 text-2xl font-semibold transition-colors",
                          active ? "bg-surface-2 text-primary" : "text-foreground hover:bg-surface-2/60",
                        )}
                      >
                        {item.label}
                        <ArrowLeft className="size-5 opacity-40 ltr:rotate-180" />
                      </Link>
                    </m.li>
                  );
                })}
              </ul>
              <div className="mt-auto">
                <ButtonLink href="/contact" size="lg" className="w-full">
                  {t.nav.cta}
                </ButtonLink>
                <p className="latin mt-6 text-center text-xs tracking-[0.2em] text-subtle">{t.brand.identity}</p>
              </div>
            </nav>
          </m.div>
        )}
      </AnimatePresence>
    </div>
  );
}
