import Image from "next/image";
import { cn, initials } from "@/lib/utils";

export function VentureLogo({
  name,
  logo,
  accentColor,
  size = 48,
  className,
}: {
  name: string;
  logo: string | null;
  accentColor?: string | null;
  size?: number;
  className?: string;
}) {
  if (logo) {
    return (
      <Image
        src={logo}
        alt={`شعار ${name}`}
        width={size}
        height={size}
        className={cn("shrink-0 rounded-[28%] object-contain", className)}
      />
    );
  }
  return (
    <span
      className={cn("grid shrink-0 place-items-center rounded-[28%] font-bold text-white", className)}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.36,
        background: `linear-gradient(135deg, ${accentColor ?? "rgb(var(--primary))"}, rgb(var(--surface-2)))`,
      }}
      aria-hidden
    >
      {initials(name)}
    </span>
  );
}
