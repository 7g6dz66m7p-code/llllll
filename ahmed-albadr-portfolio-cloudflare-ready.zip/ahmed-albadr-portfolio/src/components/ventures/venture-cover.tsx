import Image from "next/image";
import { cn } from "@/lib/utils";
import type { Venture } from "@/types/content";
import { VentureLogo } from "./venture-logo";

/**
 * Venture visual. Uses the uploaded cover when present; otherwise renders a branded, generative
 * cover from the venture's accent color so every card looks finished without stock imagery.
 */
export function VentureCover({
  venture,
  className,
  priority,
  sizes = "(min-width: 1024px) 40vw, 100vw",
}: {
  venture: Pick<Venture, "name" | "nameEn" | "logo" | "coverImage" | "accentColor" | "category">;
  className?: string;
  priority?: boolean;
  sizes?: string;
}) {
  const accent = venture.accentColor ?? "#22d3ee";
  return (
    <div className={cn("relative overflow-hidden bg-surface-2", className)}>
      {venture.coverImage ? (
        <Image
          src={venture.coverImage}
          alt={`غلاف ${venture.name}`}
          fill
          sizes={sizes}
          priority={priority}
          className="object-cover transition-transform duration-700 ease-[var(--ease-premium)] group-hover:scale-[1.04]"
        />
      ) : (
        <div className="absolute inset-0" aria-hidden>
          <div
            className="absolute inset-0 opacity-90"
            style={{
              background: `radial-gradient(120% 90% at 85% 0%, ${accent}40 0%, transparent 55%), radial-gradient(90% 80% at 0% 100%, ${accent}26 0%, transparent 60%)`,
            }}
          />
          <div className="bg-grid absolute inset-0 opacity-70 mask-fade-b" />
          <svg className="absolute -bottom-10 -end-10 size-64 opacity-30 transition-transform duration-1000 ease-[var(--ease-premium)] group-hover:rotate-12" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="98" fill="none" stroke={accent} strokeWidth="0.75" />
            <circle cx="100" cy="100" r="70" fill="none" stroke={accent} strokeWidth="0.75" strokeDasharray="3 6" />
            <circle cx="100" cy="100" r="42" fill="none" stroke={accent} strokeWidth="0.75" />
          </svg>
          <div className="absolute inset-0 grid place-items-center">
            <div className="relative transition-transform duration-700 ease-[var(--ease-premium)] group-hover:scale-110">
              <div className="absolute inset-0 scale-150 rounded-full blur-2xl" style={{ background: `${accent}55` }} />
              <VentureLogo name={venture.name} logo={venture.logo} accentColor={accent} size={76} className="relative shadow-2xl" />
            </div>
          </div>
          {venture.nameEn && (
            <span className="latin absolute bottom-4 start-5 text-[0.65rem] font-semibold uppercase tracking-[0.3em] text-foreground/40">
              {venture.nameEn}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
