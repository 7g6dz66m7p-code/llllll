import { EmptyState } from "@/components/shared/states";
import { Reveal } from "@/components/shared/reveal";
import { cn } from "@/lib/utils";
import type { Venture } from "@/types/content";
import { VentureCard } from "./venture-card";

/**
 * Responsive ventures grid. With `highlightFirst`, the first venture spans the full row
 * as a wide featured card — the layout stays balanced for any number of ventures.
 */
export function VentureGrid({ ventures, highlightFirst, className }: { ventures: Venture[]; highlightFirst?: boolean; className?: string }) {
  if (!ventures.length) return <EmptyState title="لا توجد مشاريع منشورة بعد" description="ستظهر المشاريع هنا فور نشرها من لوحة الإدارة." />;

  const [first, ...rest] = ventures;
  const list = highlightFirst ? rest : ventures;

  return (
    <div className={cn("space-y-6", className)}>
      {highlightFirst && first && (
        <Reveal>
          <VentureCard venture={first} featured priority />
        </Reveal>
      )}
      {list.length > 0 && (
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {list.map((venture, i) => (
            <Reveal as="li" key={venture.id} delay={(i % 3) * 0.08}>
              <VentureCard venture={venture} />
            </Reveal>
          ))}
        </ul>
      )}
    </div>
  );
}
