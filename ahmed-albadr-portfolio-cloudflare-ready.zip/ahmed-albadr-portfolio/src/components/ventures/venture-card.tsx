import Link from "next/link";
import { ArrowLeft, ArrowUpLeft } from "lucide-react";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/ui/status-badge";
import type { Venture } from "@/types/content";
import { VentureCover } from "./venture-cover";
import { VentureLogo } from "./venture-logo";

export function VentureCard({ venture, featured, priority }: { venture: Venture; featured?: boolean; priority?: boolean }) {
  const href = `/ventures/${venture.slug}`;
  return (
    <article
      className={cn(
        "group card-surface relative flex h-full flex-col overflow-hidden rounded-[var(--radius-card)] transition-all duration-500 ease-[var(--ease-premium)] hover:-translate-y-1 hover:border-primary/25 hover:shadow-[var(--shadow-glow)]",
        featured && "md:flex-row",
      )}
    >
      {/* Spotlight border on hover */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/70 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        aria-hidden
      />
      <VentureCover
        venture={venture}
        priority={priority}
        className={cn("aspect-[16/10] w-full", featured && "md:aspect-auto md:w-1/2")}
        sizes={featured ? "(min-width: 768px) 45vw, 100vw" : "(min-width: 1024px) 30vw, (min-width: 768px) 45vw, 100vw"}
      />

      <div className={cn("flex flex-1 flex-col p-6 sm:p-7", featured && "md:p-10")}>
        <div className="mb-5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <VentureLogo name={venture.name} logo={venture.logo} accentColor={venture.accentColor} size={40} />
            <div>
              <h3 className={cn("font-bold leading-tight text-foreground", featured ? "text-2xl" : "text-xl")}>
                <Link href={href} className="after:absolute after:inset-0 focus-visible:outline-none">
                  {venture.name}
                </Link>
              </h3>
              <p className="latin mt-1 text-xs text-subtle">{venture.category}</p>
            </div>
          </div>
          <StatusBadge status={venture.status} />
        </div>

        <p className={cn("text-muted", featured ? "text-base md:text-lg" : "line-clamp-3 text-[0.95rem]")}>{venture.shortDescription}</p>

        {venture.technologies.length > 0 && (
          <ul className="mt-5 flex flex-wrap gap-1.5" aria-label="التقنيات">
            {venture.technologies.slice(0, featured ? 6 : 4).map((tech) => (
              <li key={tech}>
                <Badge className="latin">{tech}</Badge>
              </li>
            ))}
          </ul>
        )}

        <div className="mt-auto flex items-center justify-between gap-4 pt-7">
          <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary">
            {t.common.exploreVenture}
            <ArrowLeft className="size-4 transition-transform duration-300 group-hover:-translate-x-1 ltr:rotate-180" />
          </span>
          {venture.websiteUrl && (
            <a
              href={venture.websiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="relative z-10 inline-flex items-center gap-1 text-xs text-subtle transition-colors hover:text-foreground"
              aria-label={`${t.common.visitWebsite}: ${venture.name}`}
            >
              {new URL(venture.websiteUrl).hostname.replace(/^www\./, "")}
              <ArrowUpLeft className="size-3.5 ltr:-scale-x-100" />
            </a>
          )}
        </div>
      </div>
    </article>
  );
}
