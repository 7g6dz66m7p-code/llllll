import Link from "next/link";
import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "outline" | "danger";
type Size = "sm" | "md" | "lg" | "icon";

const base =
  "group/btn relative inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-medium transition-all duration-300 ease-[var(--ease-premium)] select-none disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98]";

const variants: Record<Variant, string> = {
  primary:
    "bg-primary text-primary-fg shadow-[0_10px_30px_-10px_rgb(var(--primary)/0.6)] hover:shadow-[0_14px_40px_-10px_rgb(var(--primary)/0.75)] hover:-translate-y-0.5 hover:bg-primary-strong",
  secondary: "glass text-foreground hover:border-border-strong hover:bg-surface-2/80 hover:-translate-y-0.5",
  outline: "border border-border-strong text-foreground hover:border-primary/50 hover:text-primary",
  ghost: "text-muted hover:text-foreground hover:bg-surface-2/70",
  danger: "bg-danger/10 text-danger border border-danger/25 hover:bg-danger/15",
};

const sizes: Record<Size, string> = {
  sm: "h-9 px-4 text-sm",
  md: "h-11 px-6 text-[0.95rem]",
  lg: "h-13 px-8 text-base",
  icon: "h-10 w-10",
};

export function buttonStyles({ variant = "primary", size = "md", className }: { variant?: Variant; size?: Size; className?: string } = {}) {
  return cn(base, variants[variant], sizes[size], className);
}

interface CommonProps {
  variant?: Variant;
  size?: Size;
  className?: string;
  children: ReactNode;
}

export function Button({ variant, size, className, ...props }: CommonProps & ComponentPropsWithoutRef<"button">) {
  return <button className={buttonStyles({ variant, size, className })} {...props} />;
}

export function ButtonLink({
  href,
  variant,
  size,
  className,
  external,
  ...props
}: CommonProps & { href: string; external?: boolean } & Omit<ComponentPropsWithoutRef<"a">, "href">) {
  const classes = buttonStyles({ variant, size, className });
  if (external) {
    return <a href={href} target="_blank" rel="noopener noreferrer" className={classes} {...props} />;
  }
  return <Link href={href} className={classes} {...props} />;
}
