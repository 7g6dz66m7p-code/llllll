import type { ComponentPropsWithoutRef } from "react";
import { cn } from "@/lib/utils";

export function Card({ className, interactive, ...props }: ComponentPropsWithoutRef<"div"> & { interactive?: boolean }) {
  return (
    <div
      className={cn(
        "card-surface relative rounded-[var(--radius-card)]",
        interactive &&
          "transition-all duration-500 ease-[var(--ease-premium)] hover:-translate-y-1 hover:border-primary/25 hover:shadow-[var(--shadow-glow)]",
        className,
      )}
      {...props}
    />
  );
}
