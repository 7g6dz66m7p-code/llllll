import { Badge } from "./badge";
import { t } from "@/lib/i18n";
import type { VentureStatus } from "@/types/content";

const tone = { LIVE: "success", BETA: "primary", IN_DEVELOPMENT: "warning", PLANNED: "neutral" } as const;

export function StatusBadge({ status, className }: { status: VentureStatus; className?: string }) {
  return (
    <Badge tone={tone[status]} dot={status !== "PLANNED"} className={className}>
      {t.ventureStatus[status]}
    </Badge>
  );
}
