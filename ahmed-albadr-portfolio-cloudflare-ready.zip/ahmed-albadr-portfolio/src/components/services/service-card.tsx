import Link from "next/link";
import { ArrowLeft, Check } from "lucide-react";
import { DynamicIcon } from "@/lib/icons";
import type { Service } from "@/types/content";

export function ServiceCard({ service, index, compact }: { service: Service; index: number; compact?: boolean }) {
  return (
    <article className="group card-surface relative flex h-full flex-col overflow-hidden rounded-[var(--radius-card)] p-7 transition-all duration-500 ease-[var(--ease-premium)] hover:-translate-y-1 hover:border-primary/25 hover:shadow-[var(--shadow-glow)] sm:p-8">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" aria-hidden />
      <div className="mb-7 flex items-start justify-between">
        <span className="grid size-12 place-items-center rounded-2xl bg-gradient-to-br from-primary/20 to-accent/5 text-primary ring-1 ring-primary/20 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6">
          <DynamicIcon name={service.icon} className="size-5" />
        </span>
        <span className="latin text-xs font-semibold text-subtle">{String(index + 1).padStart(2, "0")}</span>
      </div>
      <h3 className="text-xl font-bold text-foreground">{service.title}</h3>
      <p className="mt-3 text-muted">{service.description}</p>

      {!compact && service.highlights.length > 0 && (
        <ul className="mt-6 space-y-2.5 border-t border-border pt-6">
          {service.highlights.map((h) => (
            <li key={h} className="flex items-center gap-2.5 text-sm text-foreground/90">
              <Check className="size-4 shrink-0 text-primary" />
              {h}
            </li>
          ))}
        </ul>
      )}

      <Link
        href={service.ctaHref}
        className="mt-auto inline-flex items-center gap-2 pt-8 text-sm font-semibold text-primary after:absolute after:inset-0"
      >
        {service.ctaLabel}
        <ArrowLeft className="size-4 transition-transform duration-300 group-hover:-translate-x-1 ltr:rotate-180" />
      </Link>
    </article>
  );
}
