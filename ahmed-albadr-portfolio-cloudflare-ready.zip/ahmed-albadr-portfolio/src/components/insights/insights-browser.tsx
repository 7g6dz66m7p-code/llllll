"use client";

import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { Reveal } from "@/components/shared/reveal";
import { EmptyState } from "@/components/shared/states";
import type { Insight } from "@/types/content";
import { InsightCard } from "./insight-card";

const ALL = "الكل";

/** Category filter + featured layout. Filtering is client-side so the page stays fully static. */
export function InsightsBrowser({ insights }: { insights: Insight[] }) {
  const [category, setCategory] = useState(ALL);
  const categories = useMemo(() => [ALL, ...new Set(insights.map((i) => i.category))], [insights]);
  const filtered = category === ALL ? insights : insights.filter((i) => i.category === category);
  const featured = category === ALL ? filtered.find((i) => i.featured) : undefined;
  const rest = featured ? filtered.filter((i) => i.id !== featured.id) : filtered;

  if (!insights.length) return <EmptyState title="لا توجد مقالات منشورة بعد" description="المقالات الجديدة ستظهر هنا قريبًا." />;

  return (
    <div className="space-y-8">
      {categories.length > 2 && (
        <div role="tablist" aria-label="التصنيفات" className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
          {categories.map((c) => (
            <button
              key={c}
              type="button"
              role="tab"
              aria-selected={category === c}
              onClick={() => setCategory(c)}
              className={cn(
                "shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-all duration-300",
                category === c ? "border-primary/40 bg-primary/10 text-primary" : "border-border text-muted hover:border-border-strong hover:text-foreground",
              )}
            >
              {c}
            </button>
          ))}
        </div>
      )}
      {featured && (
        <Reveal>
          <InsightCard insight={featured} featured />
        </Reveal>
      )}
      {rest.length > 0 ? (
        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {rest.map((insight, i) => (
            <Reveal as="li" key={insight.id} delay={(i % 3) * 0.06}>
              <InsightCard insight={insight} />
            </Reveal>
          ))}
        </ul>
      ) : (
        !featured && <EmptyState title="لا توجد مقالات في هذا التصنيف" />
      )}
    </div>
  );
}
