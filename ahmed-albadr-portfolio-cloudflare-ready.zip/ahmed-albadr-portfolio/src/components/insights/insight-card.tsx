import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Clock } from "lucide-react";
import { t } from "@/lib/i18n";
import { cn, formatDate, readingTime } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { Insight } from "@/types/content";

export function InsightCard({ insight, featured }: { insight: Insight; featured?: boolean }) {
  const href = `/insights/${insight.slug}`;
  return (
    <article
      className={cn(
        "group card-surface relative flex h-full flex-col overflow-hidden rounded-[var(--radius-card)] transition-all duration-500 ease-[var(--ease-premium)] hover:-translate-y-1 hover:border-primary/25",
        featured && "lg:flex-row",
      )}
    >
      <div className={cn("relative aspect-[16/9] overflow-hidden bg-surface-2", featured && "lg:aspect-auto lg:w-[45%]")}>
        {insight.coverImage ? (
          <Image
            src={insight.coverImage}
            alt=""
            fill
            sizes={featured ? "(min-width: 1024px) 40vw, 100vw" : "(min-width: 1024px) 30vw, 100vw"}
            className="object-cover transition-transform duration-700 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="absolute inset-0" aria-hidden>
            <div className="absolute inset-0 bg-[radial-gradient(90%_80%_at_80%_10%,rgb(var(--primary)/0.22),transparent_60%),radial-gradient(70%_70%_at_10%_100%,rgb(var(--accent)/0.14),transparent_60%)]" />
            <div className="bg-grid absolute inset-0 opacity-60" />
            <p className="absolute inset-0 grid place-items-center px-8 text-center text-2xl font-bold text-foreground/15">
              {insight.category}
            </p>
          </div>
        )}
      </div>
      <div className={cn("flex flex-1 flex-col p-6 sm:p-7", featured && "lg:p-10")}>
        <div className="mb-4 flex flex-wrap items-center gap-3 text-xs text-subtle">
          <Badge tone="primary">{insight.category}</Badge>
          {insight.publishedAt && <time dateTime={insight.publishedAt.toISOString()}>{formatDate(insight.publishedAt)}</time>}
          <span className="inline-flex items-center gap-1">
            <Clock className="size-3.5" />
            {t.common.minutesRead(readingTime(insight.content))}
          </span>
        </div>
        <h3 className={cn("font-bold leading-snug text-foreground transition-colors group-hover:text-primary", featured ? "text-2xl md:text-3xl" : "text-xl")}>
          <Link href={href} className="after:absolute after:inset-0">
            {insight.title}
          </Link>
        </h3>
        <p className={cn("mt-3 text-muted", !featured && "line-clamp-3")}>{insight.excerpt}</p>
        <span className="mt-auto inline-flex items-center gap-2 pt-6 text-sm font-semibold text-primary">
          {t.common.readMore}
          <ArrowLeft className="size-4 transition-transform duration-300 group-hover:-translate-x-1 ltr:rotate-180" />
        </span>
      </div>
    </article>
  );
}
