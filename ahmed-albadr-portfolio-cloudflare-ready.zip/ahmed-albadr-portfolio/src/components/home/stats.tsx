"use client";

import { animate, useInView, useReducedMotion } from "framer-motion";
import { useEffect, useRef } from "react";
import { DynamicIcon } from "@/lib/icons";
import type { Stat } from "@/types/content";

function CountUp({ value, suffix }: { value: number; suffix: string | null }) {
  const ref = useRef<HTMLSpanElement>(null);
  const numberRef = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-10% 0px" });
  const reduce = useReducedMotion();

  // The real value is server-rendered (SEO / no-JS); the count-up only rewrites the text node.
  useEffect(() => {
    if (!inView || reduce || !numberRef.current) return;
    const node = numberRef.current;
    const controls = animate(0, value, {
      duration: 1.6,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => {
        node.textContent = String(Math.round(v));
      },
    });
    return () => controls.stop();
  }, [inView, reduce, value]);

  return (
    <span ref={ref} dir="ltr" className="latin tabular-nums">
      <span ref={numberRef}>{value}</span>
      {suffix && <span className="text-primary">{suffix}</span>}
    </span>
  );
}

export function Stats({ stats }: { stats: Stat[] }) {
  if (!stats.length) return null;
  return (
    <section aria-label="أرقام" className="container-page relative z-10 -mt-6">
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-[var(--radius-panel)] border border-border bg-border shadow-[0_30px_80px_-40px_rgb(0_0_0/0.6)] lg:grid-cols-4">
        {stats.map((stat) => {
          return (
            <div
              key={stat.id}
              className="group relative flex flex-col gap-3 bg-elevated/95 p-6 backdrop-blur-xl transition-colors duration-500 hover:bg-surface-2 sm:p-8"
            >
              <DynamicIcon name={stat.icon} className="size-5 text-primary transition-transform duration-500 group-hover:-translate-y-0.5" />
              <dt className="order-3 text-sm text-muted">{stat.label}</dt>
              <dd className="order-2 text-4xl font-bold text-foreground sm:text-5xl">
                <CountUp value={stat.value} suffix={stat.suffix} />
              </dd>
            </div>
          );
        })}
      </dl>
    </section>
  );
}
