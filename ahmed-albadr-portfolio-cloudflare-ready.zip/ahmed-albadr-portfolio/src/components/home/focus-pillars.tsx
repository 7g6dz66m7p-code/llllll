import { BrainCircuit, Layers, TrendingUp } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";

export const pillars = [
  {
    icon: TrendingUp,
    title: "Entrepreneurship",
    titleAr: "ريادة الأعمال",
    description: "بناء وتحويل الأفكار إلى مشاريع قابلة للنمو، بنماذج عمل واضحة وقرارات مبنية على السوق.",
  },
  {
    icon: BrainCircuit,
    title: "Artificial Intelligence",
    titleAr: "الذكاء الاصطناعي",
    description: "توظيف الذكاء الاصطناعي داخل المنتجات والخدمات ليصبح قيمة ملموسة للمستخدم لا مجرد ميزة تسويقية.",
  },
  {
    icon: Layers,
    title: "Digital Products",
    titleAr: "المنتجات الرقمية",
    description: "تطوير منصات وأنظمة رقمية قابلة للتوسع، بتجربة استخدام راقية وبنية تقنية تتحمّل النمو.",
  },
];

export function FocusPillars() {
  return (
    <ul className="grid gap-5 md:grid-cols-3">
      {pillars.map(({ icon: Icon, title, titleAr, description }, i) => (
        <Reveal as="li" key={title} delay={i * 0.1}>
          <div className="group card-surface relative h-full overflow-hidden rounded-[var(--radius-card)] p-7 transition-all duration-500 ease-[var(--ease-premium)] hover:-translate-y-1 hover:border-primary/25 sm:p-8">
            <div className="pointer-events-none absolute -top-16 -end-16 size-40 rounded-full bg-primary/10 opacity-0 blur-2xl transition-opacity duration-700 group-hover:opacity-100" aria-hidden />
            <span className="latin absolute top-7 end-7 text-xs font-semibold text-subtle">0{i + 1}</span>
            <span className="mb-8 grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/15 transition-all duration-500 group-hover:bg-primary group-hover:text-primary-fg">
              <Icon className="size-5" />
            </span>
            <h3 className="latin text-xl font-bold text-foreground">
              <bdi dir="ltr">{title}</bdi>
            </h3>
            <p className="mt-1 text-sm font-medium text-primary">{titleAr}</p>
            <p className="mt-4 text-muted">{description}</p>
          </div>
        </Reveal>
      ))}
    </ul>
  );
}
