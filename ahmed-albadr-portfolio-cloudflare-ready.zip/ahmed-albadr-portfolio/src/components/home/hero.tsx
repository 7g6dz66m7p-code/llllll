import Image from "next/image";
import { ArrowLeft, BrainCircuit, Layers, Rocket } from "lucide-react";
import { ButtonLink } from "@/components/ui/button";
import type { SiteSettings } from "@/types/content";

/**
 * Hero is a Server Component animated with CSS only: no JS on the critical path,
 * so the headline (LCP element) paints immediately.
 */
export function Hero({ settings }: { settings: SiteSettings }) {
  return (
    <section className="relative isolate overflow-hidden pt-32 pb-20 md:pt-40 md:pb-28">
      <HeroBackground />

      <div className="container-page grid items-center gap-14 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-7">
          <p
            className="animate-fade-up glass mb-8 inline-flex items-center gap-2.5 rounded-full px-4 py-1.5 text-xs font-medium text-muted"
            style={{ animationDelay: "0ms" }}
          >
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex size-2 rounded-full bg-primary" />
            </span>
            {settings.availability ?? settings.heroRole}
          </p>

          <h1 className="animate-fade-up text-5xl font-bold leading-[1.1] sm:text-6xl md:text-7xl" style={{ animationDelay: "80ms" }}>
            <span className="text-gradient">{settings.heroName}</span>
          </h1>

          <p className="animate-fade-up mt-5 text-xl font-medium text-foreground sm:text-2xl" style={{ animationDelay: "160ms" }}>
            {settings.heroRole}
          </p>

          <p
            className="latin animate-fade-up mt-4 text-[0.7rem] font-semibold uppercase tracking-[0.28em] text-primary sm:text-xs"
            style={{ animationDelay: "220ms" }}
          >
            <bdi dir="ltr">{settings.heroIdentity}</bdi>
          </p>

          <p className="animate-fade-up mt-8 max-w-xl text-lg leading-9 text-muted" style={{ animationDelay: "300ms" }}>
            {settings.heroDescription}
          </p>

          <div className="animate-fade-up mt-10 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "380ms" }}>
            <ButtonLink href="/ventures" size="lg">
              {settings.primaryCtaLabel}
              <ArrowLeft className="size-4 transition-transform duration-300 group-hover/btn:-translate-x-1 ltr:rotate-180" />
            </ButtonLink>
            <ButtonLink href="/contact" size="lg" variant="secondary">
              {settings.secondaryCtaLabel}
            </ButtonLink>
          </div>
        </div>

        <div className="animate-fade-up lg:col-span-5" style={{ animationDelay: "200ms" }}>
          <HeroPortrait image={settings.heroImage} name={settings.heroName} />
        </div>
      </div>
    </section>
  );
}

function HeroBackground() {
  return (
    <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden>
      <div className="bg-grid mask-radial absolute inset-0" />
      <div className="absolute -top-40 end-[-10%] h-[36rem] w-[36rem] rounded-full bg-primary/15 blur-[120px]" />
      <div className="absolute top-1/3 start-[-15%] h-[28rem] w-[28rem] rounded-full bg-accent/10 blur-[120px]" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-background" />
    </div>
  );
}

const floatingChips = [
  { icon: BrainCircuit, label: "AI Products", className: "top-[8%] -start-2 sm:-start-6", delay: "0s" },
  { icon: Layers, label: "SaaS Platforms", className: "bottom-[22%] -end-2 sm:-end-8", delay: "-3s" },
  { icon: Rocket, label: "Ventures", className: "top-[42%] -start-4 sm:-start-12", delay: "-5s" },
];

function HeroPortrait({ image, name }: { image: string | null; name: string }) {
  return (
    <div className="relative mx-auto aspect-[4/5] w-full max-w-[18rem] sm:max-w-[22rem] lg:max-w-[26rem]">
      {/* Orbit rings */}
      <svg className="animate-spin-slow absolute -inset-10 -z-10 size-[calc(100%+5rem)] text-primary/25" viewBox="0 0 400 400" aria-hidden>
        <circle cx="200" cy="200" r="196" fill="none" stroke="currentColor" strokeWidth="0.6" />
        <circle cx="200" cy="200" r="160" fill="none" stroke="currentColor" strokeWidth="0.6" strokeDasharray="2 8" />
        <circle cx="200" cy="4" r="3" fill="rgb(var(--primary))" />
        <circle cx="40" cy="200" r="2" fill="rgb(var(--accent))" />
      </svg>

      <div className="relative h-full overflow-hidden rounded-[2rem] border border-border-strong bg-gradient-to-b from-surface-2 to-surface p-2 shadow-[0_40px_120px_-40px_rgb(var(--glow)/0.45)]">
        <div className="relative h-full overflow-hidden rounded-[1.6rem]">
          {image ? (
            <Image
              src={image}
              alt={`${name} — صورة شخصية`}
              fill
              priority
              sizes="(min-width: 1024px) 26rem, 90vw"
              className="object-cover"
            />
          ) : (
            <PortraitPlaceholder />
          )}
          <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-background/80 to-transparent" />
          <div className="absolute inset-x-4 bottom-4 flex items-center justify-between rounded-2xl glass px-4 py-3">
            <div>
              <p className="text-sm font-semibold">{name}</p>
              <p className="latin text-[0.65rem] tracking-[0.18em] text-subtle">FOUNDER · BUILDER</p>
            </div>
            <span className="grid size-9 place-items-center rounded-xl bg-primary/15 text-primary">
              <Rocket className="size-4" />
            </span>
          </div>
        </div>
      </div>

      {floatingChips.map(({ icon: Icon, label, className, delay }) => (
        <div
          key={label}
          className={`animate-float glass absolute hidden items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium shadow-lg sm:flex ${className}`}
          style={{ animationDelay: delay }}
          aria-hidden
        >
          <Icon className="size-4 text-primary" />
          <span className="latin">{label}</span>
        </div>
      ))}
    </div>
  );
}

/** Shown until a portrait is uploaded from /admin → Settings. */
function PortraitPlaceholder() {
  return (
    <div className="absolute inset-0 bg-[radial-gradient(80%_60%_at_50%_30%,rgb(var(--primary)/0.22),transparent_70%)]">
      <div className="bg-grid absolute inset-0 opacity-60" />
      <svg viewBox="0 0 200 250" className="absolute inset-x-0 bottom-0 mx-auto w-[78%] text-foreground/[0.08]" aria-hidden>
        <circle cx="100" cy="88" r="46" fill="currentColor" />
        <path d="M14 250c0-52 38-86 86-86s86 34 86 86Z" fill="currentColor" />
      </svg>
      <span className="absolute inset-0 grid place-items-center pb-16 text-7xl font-bold text-primary/30">أ.ب</span>
    </div>
  );
}
