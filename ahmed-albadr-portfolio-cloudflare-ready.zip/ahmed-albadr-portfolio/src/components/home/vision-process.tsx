import { BarChart3, CheckCircle2, Lightbulb, Package, Rocket, TrendingUp } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";

export const processSteps = [
  { key: "Idea", label: "الفكرة", icon: Lightbulb, description: "مشكلة حقيقية تستحق الحل، وشريحة واضحة تعاني منها." },
  { key: "Validation", label: "التحقق", icon: CheckCircle2, description: "اختبار الفكرة مع العملاء قبل كتابة سطر واحد من الكود." },
  { key: "Product", label: "المنتج", icon: Package, description: "أصغر نسخة تحقق الوعد الأساسي بإتقان." },
  { key: "Launch", label: "الإطلاق", icon: Rocket, description: "إطلاق مبكر، قياس فعلي، وتعلّم سريع من المستخدمين." },
  { key: "Growth", label: "النمو", icon: TrendingUp, description: "قنوات اكتساب فعّالة، وتحسين مستمر لتجربة العميل." },
  { key: "Scale", label: "التوسع", icon: BarChart3, description: "أنظمة وفرق وبنية تقنية تحمل المنتج إلى أسواق جديدة." },
];

/** Idea → Validation → Product → Launch → Growth → Scale. Horizontal on desktop, vertical on mobile. */
export function VisionProcess() {
  return (
    <ol className="relative grid gap-4 md:grid-cols-3 lg:grid-cols-6 lg:gap-3">
      {/* Connector line (desktop) */}
      <div
        className="pointer-events-none absolute inset-x-[8%] top-9 hidden h-px bg-gradient-to-l from-primary/0 via-primary/50 to-primary/0 lg:block"
        aria-hidden
      />
      {processSteps.map(({ key, label, icon: Icon, description }, i) => (
        <Reveal as="li" key={key} delay={i * 0.08} className="relative">
          <div className="group flex h-full gap-4 lg:flex-col lg:items-center lg:text-center">
            <div className="relative flex flex-col items-center">
              <span className="relative z-10 grid size-[4.5rem] shrink-0 place-items-center rounded-2xl border border-border-strong bg-elevated text-primary shadow-[0_10px_40px_-15px_rgb(var(--glow)/0.5)] transition-all duration-500 ease-[var(--ease-premium)] group-hover:-translate-y-1 group-hover:border-primary/50 group-hover:bg-primary group-hover:text-primary-fg">
                <Icon className="size-6" />
              </span>
              {/* Connector line (mobile / tablet) */}
              {i < processSteps.length - 1 && (
                <span className="mt-2 w-px flex-1 bg-gradient-to-b from-primary/50 to-transparent md:hidden" aria-hidden />
              )}
            </div>
            <div className="pb-8 lg:pb-0 lg:pt-5">
              <p className="latin text-xs font-semibold text-subtle">
                0{i + 1} · <span dir="ltr">{key}</span>
              </p>
              <h3 className="mt-1 text-lg font-bold text-foreground">{label}</h3>
              <p className="mt-2 text-sm leading-7 text-muted">{description}</p>
            </div>
          </div>
        </Reveal>
      ))}
    </ol>
  );
}
