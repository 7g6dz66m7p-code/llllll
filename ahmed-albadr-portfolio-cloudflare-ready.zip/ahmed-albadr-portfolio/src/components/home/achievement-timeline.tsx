import Link from "next/link";
import { ArrowLeft, Flag } from "lucide-react";
import { Reveal } from "@/components/shared/reveal";
import { EmptyState } from "@/components/shared/states";
import { formatDate } from "@/lib/utils";
import type { Achievement } from "@/types/content";

/** Business milestones grouped by year, newest first. */
export function AchievementTimeline({ achievements, limit }: { achievements: Achievement[]; limit?: number }) {
  const items = limit ? achievements.slice(0, limit) : achievements;
  if (!items.length) return <EmptyState title="لا توجد محطات منشورة بعد" />;

  const years = [...new Set(items.map((a) => a.year))].sort((a, b) => b - a);

  return (
    <div className="space-y-14">
      {years.map((year) => (
        <section key={year} aria-labelledby={`year-${year}`} className="grid gap-6 md:grid-cols-[10rem_1fr]">
          <Reveal>
            <h3 id={`year-${year}`} className="latin text-5xl font-bold text-foreground/15 md:sticky md:top-28">
              {year}
            </h3>
          </Reveal>
          <ol className="relative space-y-4 border-s border-border ps-8">
            {items
              .filter((a) => a.year === year)
              .map((a, i) => (
                <Reveal as="li" key={a.id} delay={i * 0.06} className="relative">
                  <span className="absolute -start-[2.55rem] top-6 grid size-5 place-items-center rounded-full border border-primary/40 bg-background" aria-hidden>
                    <span className="size-2 rounded-full bg-primary shadow-[0_0_12px_rgb(var(--primary))]" />
                  </span>
                  <div className="group card-surface rounded-[var(--radius-card)] p-6 transition-all duration-500 hover:border-primary/25">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <h4 className="flex items-center gap-2.5 text-lg font-bold text-foreground">
                        <Flag className="size-4 text-primary" />
                        {a.title}
                      </h4>
                      {a.date && <time className="text-xs text-subtle" dateTime={a.date.toISOString()}>{formatDate(a.date)}</time>}
                    </div>
                    {a.description && <p className="mt-3 text-muted">{a.description}</p>}
                    {a.venture && (
                      <Link
                        href={`/ventures/${a.venture.slug}`}
                        className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                      >
                        {a.venture.name}
                        <ArrowLeft className="size-3.5 ltr:rotate-180" />
                      </Link>
                    )}
                  </div>
                </Reveal>
              ))}
          </ol>
        </section>
      ))}
    </div>
  );
}
