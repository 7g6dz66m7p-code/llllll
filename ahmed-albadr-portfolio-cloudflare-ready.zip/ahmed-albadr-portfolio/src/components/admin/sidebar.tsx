"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  Award,
  BarChart3,
  Briefcase,
  ExternalLink,
  Image as ImageIcon,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  NotebookPen,
  Settings,
  Share2,
  Sparkles,
  X,
} from "lucide-react";
import { BrandMark } from "@/components/shared/brand-mark";
import { ThemeToggle } from "@/components/shared/theme-toggle";
import { cn } from "@/lib/utils";
import { logout } from "@/services/admin/session";

const items = [
  { href: "/admin", label: "نظرة عامة", icon: LayoutDashboard },
  { href: "/admin/ventures", label: "المشاريع", icon: Briefcase },
  { href: "/admin/insights", label: "المقالات", icon: NotebookPen },
  { href: "/admin/services", label: "الخدمات", icon: Sparkles },
  { href: "/admin/achievements", label: "الإنجازات", icon: Award },
  { href: "/admin/stats", label: "الإحصائيات", icon: BarChart3 },
  { href: "/admin/messages", label: "الرسائل", icon: Mail, badgeKey: "messages" as const },
  { href: "/admin/media", label: "مكتبة الوسائط", icon: ImageIcon },
  { href: "/admin/social", label: "روابط التواصل", icon: Share2 },
  { href: "/admin/settings", label: "إعدادات الموقع", icon: Settings },
];

export function AdminSidebar({ newMessages, email }: { newMessages: number; email?: string | null }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [lastPath, setLastPath] = useState(pathname);
  if (lastPath !== pathname) {
    setLastPath(pathname);
    setOpen(false);
  }

  const nav = (
    <nav className="flex h-full flex-col">
      <div className="flex items-center justify-between px-5 py-5">
        <BrandMark />
      </div>
      <ul className="flex-1 space-y-1 overflow-y-auto px-3">
        {items.map(({ href, label, icon: Icon, badgeKey }) => {
          const active = href === "/admin" ? pathname === "/admin" : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  active ? "bg-primary/10 text-primary" : "text-muted hover:bg-surface-2 hover:text-foreground",
                )}
              >
                <Icon className="size-[1.1rem]" />
                <span className="flex-1">{label}</span>
                {badgeKey === "messages" && newMessages > 0 && (
                  <span className="latin rounded-full bg-primary px-2 py-0.5 text-[0.7rem] font-bold text-primary-fg">{newMessages}</span>
                )}
              </Link>
            </li>
          );
        })}
      </ul>
      <div className="space-y-2 border-t border-border p-3">
        <Link href="/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted hover:bg-surface-2 hover:text-foreground">
          <ExternalLink className="size-[1.1rem]" />
          عرض الموقع
        </Link>
        <div className="flex items-center justify-between gap-2 rounded-xl px-3 py-2">
          <span className="latin truncate text-xs text-subtle" dir="ltr">
            {email}
          </span>
          <div className="flex items-center">
            <ThemeToggle />
            <form action={logout}>
              <button type="submit" className="inline-flex size-10 items-center justify-center rounded-full text-muted hover:bg-danger/10 hover:text-danger" aria-label="تسجيل الخروج" title="تسجيل الخروج">
                <LogOut className="size-[1.1rem] ltr:rotate-180" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </nav>
  );

  return (
    <>
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 border-e border-border bg-elevated lg:block">{nav}</aside>
      <div className="sticky top-0 z-40 flex items-center justify-between border-b border-border bg-elevated/90 px-4 py-3 backdrop-blur lg:hidden">
        <BrandMark compact />
        <span className="text-sm font-semibold">لوحة الإدارة</span>
        <button type="button" onClick={() => setOpen(true)} className="grid size-10 place-items-center rounded-full hover:bg-surface-2" aria-label="فتح القائمة">
          <Menu className="size-5" />
        </button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true">
          <button type="button" className="absolute inset-0 bg-background/70 backdrop-blur-sm" onClick={() => setOpen(false)} aria-label="إغلاق القائمة" />
          <aside className="absolute inset-y-0 start-0 w-72 border-e border-border bg-elevated shadow-2xl">
            <button type="button" onClick={() => setOpen(false)} className="absolute top-5 end-4 grid size-9 place-items-center rounded-full hover:bg-surface-2" aria-label="إغلاق">
              <X className="size-5" />
            </button>
            {nav}
          </aside>
        </div>
      )}
    </>
  );
}
