"use client";

import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { Copy, ImagePlus, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/states";
import { deleteMedia } from "@/services/admin/media";

type Item = { id: string; url: string; filename: string; size: number; mimeType: string };

const formatSize = (bytes: number) => (bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`);

export function MediaLibrary({ items }: { items: Item[] }) {
  const router = useRouter();
  const input = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pending, startTransition] = useTransition();

  async function upload(files: FileList) {
    setUploading(true);
    let ok = 0;
    for (const file of Array.from(files)) {
      const body = new FormData();
      body.append("file", file);
      const res = await fetch("/api/admin/upload", { method: "POST", body });
      const data = (await res.json().catch(() => ({}))) as { message?: string };
      if (res.ok) ok++;
      else toast.error(`${file.name}: ${data.message ?? "فشل الرفع"}`);
    }
    if (ok) toast.success(`تم رفع ${ok} ملف`);
    setUploading(false);
    if (input.current) input.current.value = "";
    router.refresh();
  }

  return (
    <div className="space-y-6">
      <div
        className="flex flex-col items-center justify-center gap-3 rounded-[var(--radius-card)] border-2 border-dashed border-border-strong p-10 text-center transition-colors hover:border-primary/40"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer.files.length) upload(e.dataTransfer.files);
        }}
      >
        <ImagePlus className="size-8 text-primary" />
        <p className="text-sm text-muted">اسحب الصور هنا أو</p>
        <Button type="button" size="sm" onClick={() => input.current?.click()} disabled={uploading}>
          {uploading ? <Loader2 className="size-4 animate-spin" /> : null}
          {uploading ? "جارٍ الرفع…" : "اختر صورًا"}
        </Button>
        <p className="text-xs text-subtle">PNG, JPG, WEBP, AVIF, GIF — حتى 5MB</p>
        <input ref={input} type="file" multiple accept="image/png,image/jpeg,image/webp,image/avif,image/gif" className="hidden" onChange={(e) => e.target.files && upload(e.target.files)} />
      </div>

      {items.length ? (
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((m) => (
            <li key={m.id} className="group card-surface overflow-hidden rounded-2xl">
              <div className="relative aspect-square bg-surface-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={m.url} alt={m.filename} loading="lazy" className="absolute inset-0 size-full object-cover" />
              </div>
              <div className="flex items-center justify-between gap-2 p-3">
                <div className="min-w-0">
                  <p className="latin truncate text-xs font-medium" dir="ltr">{m.filename}</p>
                  <p className="latin text-[0.7rem] text-subtle">{formatSize(m.size)}</p>
                </div>
                <div className="flex shrink-0">
                  <button
                    type="button"
                    className="grid size-8 place-items-center rounded-full text-muted hover:bg-surface-2 hover:text-primary"
                    aria-label="نسخ الرابط"
                    onClick={() => navigator.clipboard.writeText(m.url).then(() => toast.success("تم نسخ الرابط"))}
                  >
                    <Copy className="size-4" />
                  </button>
                  <button
                    type="button"
                    disabled={pending}
                    className="grid size-8 place-items-center rounded-full text-muted hover:bg-danger/10 hover:text-danger"
                    aria-label="حذف"
                    onClick={() => {
                      if (!confirm("حذف هذا الملف نهائيًا؟ تأكد أنه غير مستخدم في المحتوى.")) return;
                      startTransition(async () => {
                        const r = await deleteMedia(m.id);
                        (r.ok ? toast.success : toast.error)(r.message ?? "");
                        router.refresh();
                      });
                    }}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState title="المكتبة فارغة" description="ابدأ برفع الشعارات والصور الخاصة بمشاريعك." />
      )}
    </div>
  );
}
