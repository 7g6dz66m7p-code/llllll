"use client";

import { useRouter } from "next/navigation";
import { useTransition, type ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { buttonStyles } from "@/components/ui/button";
import type { ActionResult } from "@/services/admin/shared";

/** Runs a bound Server Action (delete, toggle, status change) with optional confirmation. */
export function ActionButton({
  action,
  children,
  confirmMessage,
  variant = "ghost",
  size = "sm",
  className,
  title,
}: {
  action: () => Promise<ActionResult>;
  children: ReactNode;
  confirmMessage?: string;
  variant?: "ghost" | "danger" | "outline" | "secondary" | "primary";
  size?: "sm" | "icon" | "md";
  className?: string;
  title?: string;
}) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={pending}
      className={buttonStyles({ variant, size, className })}
      onClick={() => {
        if (confirmMessage && !window.confirm(confirmMessage)) return;
        startTransition(async () => {
          const result = await action();
          if (result.message) (result.ok ? toast.success : toast.error)(result.message);
          if (result.ok && result.redirectTo) router.push(result.redirectTo);
          else router.refresh();
        });
      }}
    >
      {pending ? <Loader2 className="size-4 animate-spin" /> : children}
    </button>
  );
}
