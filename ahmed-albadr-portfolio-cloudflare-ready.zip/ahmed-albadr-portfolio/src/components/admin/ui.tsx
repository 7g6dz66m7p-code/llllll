import Link from "next/link";
import { DatabaseZap, Plus } from "lucide-react";
import type { ReactNode } from "react";
import { buttonStyles } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function AdminPageHeader({
  title,
  description,
  createHref,
  createLabel = "إضافة جديد",
  actions,
}: {
  title: string;
  description?: string;
  createHref?: string;
  createLabel?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold sm:text-3xl">{title}</h1>
        {description && <p className="mt-2 text-muted">{description}</p>}
      </div>
      <div className="flex items-center gap-2">
        {actions}
        {createHref && (
          <Link href={createHref} className={buttonStyles({ size: "sm" })}>
            <Plus className="size-4" />
            {createLabel}
          </Link>
        )}
      </div>
    </header>
  );
}

export function DatabaseNotice() {
  return (
    <div className="mb-8 flex items-start gap-4 rounded-2xl border border-warning/30 bg-warning/5 p-5" role="status">
      <DatabaseZap className="mt-0.5 size-5 shrink-0 text-warning" />
      <div className="text-sm">
        <p className="font-semibold text-foreground">قاعدة البيانات غير مُعدّة</p>
        <p className="mt-1 text-muted">
          الموقع يعرض حاليًا المحتوى الافتراضي. أضف <code className="latin rounded bg-surface-2 px-1.5 py-0.5">DATABASE_URL</code> ثم شغّل{" "}
          <code className="latin rounded bg-surface-2 px-1.5 py-0.5">npm run db:deploy && npm run db:seed</code> لتفعيل الإدارة الكاملة.
        </p>
      </div>
    </div>
  );
}

export function AdminTable({ head, children, empty }: { head: string[]; children: ReactNode; empty?: boolean }) {
  return (
    <div className="card-surface overflow-hidden rounded-[var(--radius-card)]">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[40rem] text-sm">
          <thead className="border-b border-border bg-surface-2/50 text-start text-xs text-subtle">
            <tr>
              {head.map((h, i) => (
                <th key={i} scope="col" className={cn("px-5 py-3 text-start font-medium", i === head.length - 1 && "text-end")}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">{children}</tbody>
        </table>
      </div>
      {empty && <p className="px-5 py-12 text-center text-sm text-muted">لا توجد عناصر بعد.</p>}
    </div>
  );
}

export function Td({ children, className, end }: { children: ReactNode; className?: string; end?: boolean }) {
  return <td className={cn("px-5 py-4 align-middle", end && "text-end", className)}>{children}</td>;
}
