"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { Eye, EyeOff, Loader2, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/form";
import { login } from "@/services/admin/session";

function Submit() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" size="lg" className="w-full" disabled={pending}>
      {pending ? <Loader2 className="size-4 animate-spin" /> : <LogIn className="size-4 ltr:rotate-180" />}
      {pending ? "جارٍ التحقق…" : "تسجيل الدخول"}
    </Button>
  );
}

export function LoginForm() {
  const [state, action] = useActionState(login, { ok: false });
  const [showPassword, setShowPassword] = useState(false);

  return (
    <form action={action} className="space-y-5">
      <Field label="البريد الإلكتروني" htmlFor="email">
        <Input id="email" name="email" type="email" dir="ltr" autoComplete="username" required defaultValue={state.values?.email} className="text-start" />
      </Field>
      <Field label="كلمة المرور" htmlFor="password">
        <div className="relative">
          <Input
            id="password"
            name="password"
            type={showPassword ? "text" : "password"}
            dir="ltr"
            autoComplete="current-password"
            required
            className="pe-12 text-start"
          />
          <button
            type="button"
            onClick={() => setShowPassword((value) => !value)}
            className="absolute end-1 top-1/2 grid size-10 -translate-y-1/2 place-items-center rounded-lg text-subtle transition-colors hover:bg-surface-2 hover:text-foreground"
            aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
            aria-pressed={showPassword}
          >
            {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
          </button>
        </div>
      </Field>
      {state.message && (
        <p className="rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">
          {state.message}
        </p>
      )}
      <Submit />
    </form>
  );
}
