import type { ReactNode } from "react";
import { AdminForm, CheckboxField, FormActions, FormSection, SelectField, TextAreaField, TextField } from "@/components/admin/form-kit";
import { iconNames } from "@/lib/icons";
import { SOCIAL_PLATFORMS } from "@/types/content";
import { socialMeta } from "@/components/shared/social-links";
import type { ActionResult } from "@/services/admin/shared";

type Action = (prev: ActionResult, formData: FormData) => Promise<ActionResult>;
const iconOptions = iconNames.map((n) => ({ value: n, label: n }));

export function ServiceForm({
  action,
  service: s,
  extraActions,
}: {
  action: Action;
  service?: { title: string; description: string; icon: string; highlights: string[]; ctaLabel: string; ctaHref: string; published: boolean; sortOrder: number } | null;
  extraActions?: ReactNode;
}) {
  return (
    <AdminForm action={action}>
      <FormSection title="الخدمة">
        <TextField name="title" label="العنوان" defaultValue={s?.title} required />
        <SelectField name="icon" label="الأيقونة" defaultValue={s?.icon ?? "Sparkles"} options={iconOptions} />
        <TextAreaField name="description" label="الوصف" defaultValue={s?.description} rows={4} className="sm:col-span-2" required />
        <TextAreaField name="highlights" label="نقاط مميزة" defaultValue={s?.highlights.join("\n")} rows={4} className="sm:col-span-2" hint="نقطة في كل سطر" />
        <TextField name="ctaLabel" label="نص الزر (CTA)" defaultValue={s?.ctaLabel ?? "ابدأ مشروعك"} />
        <TextField name="ctaHref" label="رابط الزر" defaultValue={s?.ctaHref ?? "/contact"} dir="ltr" />
        <TextField name="sortOrder" label="الترتيب" type="number" defaultValue={s?.sortOrder ?? 0} />
        <div className="flex items-end pb-3">
          <CheckboxField name="published" label="منشورة" defaultChecked={s?.published ?? true} />
        </div>
      </FormSection>
      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}

export function AchievementForm({
  action,
  achievement: a,
  ventures,
  extraActions,
}: {
  action: Action;
  achievement?: { year: number; title: string; description: string | null; date: Date | null; ventureId: string | null; published: boolean; sortOrder: number } | null;
  ventures: { id: string; name: string }[];
  extraActions?: ReactNode;
}) {
  return (
    <AdminForm action={action}>
      <FormSection title="المحطة">
        <TextField name="title" label="العنوان" defaultValue={a?.title} required className="sm:col-span-2" />
        <TextField name="year" label="السنة" type="number" defaultValue={a?.year ?? new Date().getFullYear()} required />
        <TextField name="date" label="التاريخ (اختياري)" type="date" defaultValue={a?.date?.toISOString().slice(0, 10)} />
        <TextAreaField name="description" label="الوصف" defaultValue={a?.description} rows={3} className="sm:col-span-2" />
        <SelectField
          name="ventureId"
          label="المشروع المرتبط"
          defaultValue={a?.ventureId ?? ""}
          options={[{ value: "", label: "— بدون —" }, ...ventures.map((v) => ({ value: v.id, label: v.name }))]}
        />
        <TextField name="sortOrder" label="الترتيب" type="number" defaultValue={a?.sortOrder ?? 0} />
        <div className="pb-3">
          <CheckboxField name="published" label="منشور" defaultChecked={a?.published ?? true} />
        </div>
      </FormSection>
      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}

export function StatForm({
  action,
  stat: s,
  extraActions,
}: {
  action: Action;
  stat?: { label: string; value: number; suffix: string | null; icon: string; sortOrder: number } | null;
  extraActions?: ReactNode;
}) {
  return (
    <AdminForm action={action}>
      <FormSection title="الرقم">
        <TextField name="label" label="العنوان" defaultValue={s?.label} required />
        <TextField name="value" label="القيمة" type="number" defaultValue={s?.value ?? 0} required />
        <TextField name="suffix" label="لاحقة (مثال: +)" defaultValue={s?.suffix} />
        <SelectField name="icon" label="الأيقونة" defaultValue={s?.icon ?? "Rocket"} options={iconOptions} />
        <TextField name="sortOrder" label="الترتيب" type="number" defaultValue={s?.sortOrder ?? 0} />
      </FormSection>
      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}

export function SocialLinkForm({
  action,
  link: l,
  extraActions,
}: {
  action: Action;
  link?: { platform: string; url: string; label: string | null; active: boolean; sortOrder: number } | null;
  extraActions?: ReactNode;
}) {
  return (
    <AdminForm action={action}>
      <FormSection title="الرابط" description="واتساب: https://wa.me/9647XXXXXXXXX — البريد: mailto:you@example.com">
        <SelectField
          name="platform"
          label="المنصة"
          defaultValue={l?.platform ?? "LINKEDIN"}
          options={SOCIAL_PLATFORMS.map((p) => ({ value: p, label: socialMeta[p].label }))}
        />
        <TextField name="url" label="الرابط" defaultValue={l?.url} dir="ltr" required placeholder="https://" />
        <TextField name="label" label="تسمية مخصصة (اختياري)" defaultValue={l?.label} />
        <TextField name="sortOrder" label="الترتيب" type="number" defaultValue={l?.sortOrder ?? 0} />
        <div className="pb-3">
          <CheckboxField name="active" label="ظاهر في الموقع" defaultChecked={l?.active ?? true} />
        </div>
      </FormSection>
      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}
