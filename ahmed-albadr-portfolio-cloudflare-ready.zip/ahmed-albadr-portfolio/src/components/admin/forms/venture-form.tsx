import { AdminForm, CheckboxField, FormActions, FormSection, SelectField, TextAreaField, TextField } from "@/components/admin/form-kit";
import { ImageField } from "@/components/admin/image-field";
import { t } from "@/lib/i18n";
import { VENTURE_STATUSES, type VentureFeature } from "@/types/content";
import type { ActionResult } from "@/services/admin/shared";
import type { ReactNode } from "react";

type VentureValues = {
  name: string;
  nameEn: string | null;
  slug: string;
  tagline: string | null;
  logo: string | null;
  coverImage: string | null;
  shortDescription: string;
  fullDescription: string;
  problem: string | null;
  solution: string | null;
  features: unknown;
  targetAudience: string[];
  screenshots: string[];
  category: string;
  status: string;
  technologies: string[];
  websiteUrl: string | null;
  githubUrl: string | null;
  accentColor: string | null;
  featured: boolean;
  published: boolean;
  sortOrder: number;
  launchedAt: Date | null;
};

const featuresToText = (features: unknown) =>
  Array.isArray(features) ? (features as VentureFeature[]).map((f) => (f.description ? `${f.title} | ${f.description}` : f.title)).join("\n") : "";

export function VentureForm({
  action,
  venture,
  extraActions,
}: {
  action: (prev: ActionResult, formData: FormData) => Promise<ActionResult>;
  venture?: VentureValues | null;
  extraActions?: ReactNode;
}) {
  const v = venture;
  return (
    <AdminForm action={action}>
      <FormSection title="الهوية" description="الاسم والمعرّف والشعار.">
        <TextField name="name" label="اسم المشروع" defaultValue={v?.name} required />
        <TextField name="nameEn" label="الاسم بالإنجليزية" defaultValue={v?.nameEn} dir="ltr" />
        <TextField name="slug" label="المعرّف في الرابط (slug)" defaultValue={v?.slug} dir="ltr" hint="مثال: mahara → /ventures/mahara" required />
        <TextField name="tagline" label="شعار قصير (Tagline)" defaultValue={v?.tagline} />
        <TextField name="category" label="التصنيف" defaultValue={v?.category} hint="مثال: AI SaaS" required />
        <SelectField
          name="status"
          label="الحالة"
          defaultValue={v?.status ?? "IN_DEVELOPMENT"}
          options={VENTURE_STATUSES.map((s) => ({ value: s, label: t.ventureStatus[s] }))}
        />
        <ImageField name="logo" label="الشعار (Logo)" defaultValue={v?.logo} folder="logos" aspect="aspect-square" />
        <ImageField name="coverImage" label="صورة الغلاف" defaultValue={v?.coverImage} hint="اختياري — بدونها يُولَّد غلاف من لون المشروع" />
        <TextField name="accentColor" label="لون المشروع" defaultValue={v?.accentColor} dir="ltr" placeholder="#22d3ee" />
        <TextField name="launchedAt" label="تاريخ الإطلاق" type="date" defaultValue={v?.launchedAt?.toISOString().slice(0, 10)} />
      </FormSection>

      <FormSection title="المحتوى">
        <TextAreaField name="shortDescription" label="الوصف المختصر" defaultValue={v?.shortDescription} rows={3} className="sm:col-span-2" required />
        <TextAreaField name="fullDescription" label="الوصف الكامل" defaultValue={v?.fullDescription} rows={8} className="sm:col-span-2" hint="يدعم Markdown" required />
        <TextAreaField name="problem" label="المشكلة التي يعالجها" defaultValue={v?.problem} rows={4} />
        <TextAreaField name="solution" label="الحل" defaultValue={v?.solution} rows={4} />
        <TextAreaField
          name="features"
          label="المميزات الرئيسية"
          defaultValue={featuresToText(v?.features)}
          rows={6}
          className="sm:col-span-2"
          hint="ميزة في كل سطر بصيغة: العنوان | الوصف"
        />
        <TextAreaField name="targetAudience" label="الجمهور المستهدف" defaultValue={v?.targetAudience.join("\n")} rows={4} hint="عنصر في كل سطر" />
        <TextAreaField name="technologies" label="التقنيات" defaultValue={v?.technologies.join("\n")} rows={4} dir="ltr" hint="تقنية في كل سطر" />
        <TextAreaField name="screenshots" label="روابط لقطات الشاشة" defaultValue={v?.screenshots.join("\n")} rows={4} dir="ltr" className="sm:col-span-2" hint="رابط في كل سطر — ارفع الصور من مكتبة الوسائط وانسخ روابطها" mono />
      </FormSection>

      <FormSection title="الروابط والنشر">
        <TextField name="websiteUrl" label="رابط المشروع" defaultValue={v?.websiteUrl} dir="ltr" placeholder="https://" />
        <TextField name="githubUrl" label="GitHub (اختياري)" defaultValue={v?.githubUrl} dir="ltr" placeholder="https://github.com/…" />
        <TextField name="sortOrder" label="الترتيب" type="number" defaultValue={v?.sortOrder ?? 0} />
        <div className="flex flex-wrap items-end gap-6 pb-3">
          <CheckboxField name="featured" label="مشروع مميز (Featured)" defaultChecked={v?.featured ?? false} />
          <CheckboxField name="published" label="منشور" defaultChecked={v?.published ?? true} />
        </div>
      </FormSection>

      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}
