import type { ReactNode } from "react";
import { AdminForm, CheckboxField, FormActions, FormSection, SelectField, TextAreaField, TextField } from "@/components/admin/form-kit";
import { ImageField } from "@/components/admin/image-field";
import { INSIGHT_CATEGORIES } from "@/data/insights";
import type { ActionResult } from "@/services/admin/shared";

type InsightValues = {
  title: string;
  slug: string;
  coverImage: string | null;
  excerpt: string;
  content: string;
  category: string;
  status: string;
  featured: boolean;
  publishedAt: Date | null;
  seoTitle: string | null;
  metaDescription: string | null;
};

export function InsightForm({
  action,
  insight,
  extraActions,
}: {
  action: (prev: ActionResult, formData: FormData) => Promise<ActionResult>;
  insight?: InsightValues | null;
  extraActions?: ReactNode;
}) {
  const i = insight;
  const categories = [...new Set([...INSIGHT_CATEGORIES, ...(i?.category ? [i.category] : [])])];
  return (
    <AdminForm action={action}>
      <FormSection title="المقال">
        <TextField name="title" label="العنوان" defaultValue={i?.title} className="sm:col-span-2" required />
        <TextField name="slug" label="المعرّف (slug)" defaultValue={i?.slug} dir="ltr" required hint="مثال: ai-in-arab-market" />
        <SelectField name="category" label="التصنيف" defaultValue={i?.category ?? categories[0]} options={categories.map((c) => ({ value: c, label: c }))} />
        <TextAreaField name="excerpt" label="الوصف المختصر" defaultValue={i?.excerpt} rows={3} className="sm:col-span-2" required />
        <ImageField name="coverImage" label="صورة الغلاف" defaultValue={i?.coverImage} />
        <TextAreaField name="content" label="المحتوى" defaultValue={i?.content} rows={20} className="sm:col-span-2" hint="Markdown: ## عنوان، **عريض**، > اقتباس، - قائمة" required />
      </FormSection>

      <FormSection title="النشر">
        <SelectField
          name="status"
          label="الحالة"
          defaultValue={i?.status ?? "DRAFT"}
          options={[
            { value: "DRAFT", label: "مسودة" },
            { value: "PUBLISHED", label: "منشور" },
          ]}
        />
        <TextField name="publishedAt" label="تاريخ النشر" type="date" defaultValue={i?.publishedAt?.toISOString().slice(0, 10)} hint="فارغ = الآن عند النشر. تاريخ مستقبلي = نشر مجدول" />
        <div className="pb-3">
          <CheckboxField name="featured" label="مقال مميز" defaultChecked={i?.featured ?? false} />
        </div>
      </FormSection>

      <FormSection title="SEO" description="اختياري — يُستخدم العنوان والوصف إن تُرك فارغًا.">
        <TextField name="seoTitle" label="SEO Title" defaultValue={i?.seoTitle} hint="حتى 70 حرفًا" />
        <TextField name="metaDescription" label="Meta Description" defaultValue={i?.metaDescription} hint="حتى 170 حرفًا" />
      </FormSection>

      <FormActions>{extraActions}</FormActions>
    </AdminForm>
  );
}
