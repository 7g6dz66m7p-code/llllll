"use client";

import { useRef, useState } from "react";
import { ImagePlus, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Field, Input } from "@/components/ui/form";
import { cn } from "@/lib/utils";

/**
 * URL input with direct upload to R2 (via /api/admin/upload) and live preview.
 * Works with any image URL, so it is usable even before storage is configured.
 */
export function ImageField({
  name,
  label,
  defaultValue,
  hint,
  folder = "uploads",
  className,
  aspect = "aspect-video",
}: {
  name: string;
  label: string;
  defaultValue?: string | null;
  hint?: string;
  folder?: "uploads" | "logos";
  className?: string;
  aspect?: string;
}) {
  const [value, setValue] = useState(defaultValue ?? "");
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(file: File) {
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      body.append("folder", folder);
      const res = await fetch("/api/admin/upload", { method: "POST", body });
      const data = (await res.json()) as { ok: boolean; message?: string; media?: { url: string } };
      if (!res.ok || !data.media) throw new Error(data.message ?? "فشل رفع الصورة");
      setValue(data.media.url);
      toast.success("تم رفع الصورة");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "فشل رفع الصورة");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <Field label={label} htmlFor={name} hint={hint ?? "ارفع صورة أو الصق رابطًا (https:// أو /)"} className={cn("sm:col-span-2", className)}>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
        <div className={cn("relative w-full shrink-0 overflow-hidden rounded-xl border border-border bg-surface-2 sm:w-48", aspect)}>
          {value ? (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={value} alt="" className="absolute inset-0 size-full object-cover" />
              <button
                type="button"
                onClick={() => setValue("")}
                className="absolute top-2 end-2 grid size-7 place-items-center rounded-full bg-background/80 text-foreground backdrop-blur hover:text-danger"
                aria-label="إزالة الصورة"
              >
                <X className="size-4" />
              </button>
            </>
          ) : (
            <span className="absolute inset-0 grid place-items-center text-subtle">
              <ImagePlus className="size-6" />
            </span>
          )}
        </div>
        <div className="flex-1 space-y-3">
          <Input id={name} name={name} value={value} onChange={(e) => setValue(e.target.value)} dir="ltr" className="text-start" placeholder="https://…" />
          <input
            ref={fileRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/avif,image/gif"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="inline-flex items-center gap-2 rounded-full border border-border-strong px-4 py-2 text-sm font-medium transition-colors hover:border-primary/50 hover:text-primary disabled:opacity-50"
          >
            {uploading ? <Loader2 className="size-4 animate-spin" /> : <ImagePlus className="size-4" />}
            {uploading ? "جارٍ الرفع…" : "رفع صورة"}
          </button>
        </div>
      </div>
    </Field>
  );
}
