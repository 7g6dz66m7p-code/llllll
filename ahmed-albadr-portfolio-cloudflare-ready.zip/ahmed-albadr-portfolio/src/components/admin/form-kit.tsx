"use client";

import { useRouter } from "next/navigation";
import { createContext, useActionState, useContext, useEffect, useRef, type ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox, Field, Input, Select, Textarea } from "@/components/ui/form";
import { cn } from "@/lib/utils";
import type { ActionResult } from "@/services/admin/shared";

type FormAction = (prev: ActionResult, formData: FormData) => Promise<ActionResult>;

const FormStateContext = createContext<ActionResult>({ ok: false });
const useFormState = () => useContext(FormStateContext);

/**
 * Admin form shell around a Server Action: pending state, toasts, field errors,
 * value echo after failed validation, and redirects after create.
 */
export function AdminForm({ action, children, className }: { action: FormAction; children: ReactNode; className?: string }) {
  const [state, formAction] = useActionState(action, { ok: false });
  const router = useRouter();
  const last = useRef<ActionResult | null>(null);

  useEffect(() => {
    if (state === last.current || (!state.message && !state.redirectTo)) return;
    last.current = state;
    if (state.message) (state.ok ? toast.success : toast.error)(state.message);
    if (state.ok && state.redirectTo) router.push(state.redirectTo);
    else if (state.ok) router.refresh();
  }, [state, router]);

  return (
    <FormStateContext.Provider value={state}>
      <form action={formAction} className={cn("space-y-6", className)} noValidate>
        {children}
      </form>
    </FormStateContext.Provider>
  );
}

export function SubmitButton({ label = "حفظ", className }: { label?: string; className?: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className={className}>
      {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
      {pending ? "جارٍ الحفظ…" : label}
    </Button>
  );
}

function useFieldState(name: string, defaultValue?: string | number | null) {
  const state = useFormState();
  const echoed = state.values?.[name];
  return {
    error: state.fieldErrors?.[name],
    value: echoed ?? (defaultValue === null || defaultValue === undefined ? "" : String(defaultValue)),
    // Re-mount uncontrolled inputs when the server echoes values back.
    key: `${name}:${state.values ? "echo" : "init"}:${echoed ?? ""}`,
  };
}

interface BaseFieldProps {
  name: string;
  label: string;
  hint?: string;
  className?: string;
  required?: boolean;
  dir?: "ltr" | "rtl";
}

export function TextField({
  name,
  label,
  hint,
  className,
  defaultValue,
  type = "text",
  required,
  dir,
  placeholder,
}: BaseFieldProps & { defaultValue?: string | number | null; type?: string; placeholder?: string }) {
  const { error, value, key } = useFieldState(name, defaultValue);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} className={className}>
      <Input
        key={key}
        id={name}
        name={name}
        type={type}
        defaultValue={value}
        required={required}
        dir={dir}
        placeholder={placeholder}
        aria-invalid={Boolean(error)}
        className={dir === "ltr" ? "text-start" : undefined}
      />
    </Field>
  );
}

export function TextAreaField({
  name,
  label,
  hint,
  className,
  defaultValue,
  rows = 5,
  required,
  dir,
  mono,
}: BaseFieldProps & { defaultValue?: string | null; rows?: number; mono?: boolean }) {
  const { error, value, key } = useFieldState(name, defaultValue);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} className={className}>
      <Textarea
        key={key}
        id={name}
        name={name}
        rows={rows}
        defaultValue={value}
        required={required}
        dir={dir}
        aria-invalid={Boolean(error)}
        className={cn(mono && "font-mono text-sm")}
      />
    </Field>
  );
}

export function SelectField({
  name,
  label,
  hint,
  className,
  defaultValue,
  options,
}: BaseFieldProps & { defaultValue?: string | null; options: { value: string; label: string }[] }) {
  const { error, value, key } = useFieldState(name, defaultValue);
  return (
    <Field label={label} htmlFor={name} error={error} hint={hint} className={className}>
      <Select key={key} id={name} name={name} defaultValue={value} aria-invalid={Boolean(error)}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </Select>
    </Field>
  );
}

export function CheckboxField({ name, label, defaultChecked }: { name: string; label: string; defaultChecked?: boolean }) {
  const state = useFormState();
  const checked = state.values ? state.values[name] === "on" : defaultChecked;
  return <Checkbox key={`${name}:${String(checked)}`} name={name} label={label} defaultChecked={checked} />;
}

export function FormSection({ title, description, children }: { title: string; description?: string; children: ReactNode }) {
  return (
    <section className="card-surface rounded-[var(--radius-card)] p-5 sm:p-7">
      <header className="mb-6">
        <h2 className="text-base font-bold">{title}</h2>
        {description && <p className="mt-1 text-sm text-muted">{description}</p>}
      </header>
      <div className="grid gap-5 sm:grid-cols-2 [&>*]:min-w-0">{children}</div>
    </section>
  );
}

export function FormActions({ children }: { children?: ReactNode }) {
  return (
    <div className="sticky bottom-4 z-10 flex items-center justify-end gap-3 rounded-2xl glass p-3">
      {children}
      <SubmitButton />
    </div>
  );
}
