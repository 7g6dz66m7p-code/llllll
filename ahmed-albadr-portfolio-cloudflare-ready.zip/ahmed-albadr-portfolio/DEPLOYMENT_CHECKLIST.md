# قائمة الإطلاق — موقع أحمد البدر

هذه الخطوات تجعل النسخة الحالية قابلة للإدارة والإرسال والنشر الفعلي بدل وضع المعاينة فقط.

## 1) متغيرات البيئة

انسخ `.env.example` إلى إعدادات الاستضافة وأكمل القيم التالية:

- `NEXT_PUBLIC_SITE_URL`: الدومين النهائي للموقع بدون `/` في النهاية.
- `DATABASE_URL`: رابط PostgreSQL (مثل Neon أو Supabase أو Vercel Postgres).
- `AUTH_SECRET`: مفتاح عشوائي لا يقل عن 32 حرفًا.
- `ADMIN_EMAIL`: البريد الذي سيدخل إلى `/admin`.
- `ADMIN_PASSWORD_HASH_B64`: أنشئه بالأمر `npm run auth:hash -- "YOUR_PASSWORD"`.
- `IP_HASH_SECRET`: قيمة عشوائية منفصلة لحماية بيانات الزوار في rate limiting.
- `CONTACT_EMAIL` و`CONTACT_WHATSAPP`: بيانات التواصل الافتراضية قبل أول seed.

## 2) قاعدة البيانات

بعد ضبط `DATABASE_URL`:

```bash
npm run db:deploy
npm run db:seed
```

ثم افتح `/admin` وتأكد أن المشاريع والخدمات والإحصاءات ظهرت ويمكن تعديلها.

## 3) الصور والوسائط

لتفعيل رفع الصور من لوحة الإدارة اضبط:

- `R2_ACCOUNT_ID`
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_BUCKET`
- `R2_PUBLIC_URL`

`R2_ENDPOINT` اختياري إذا كنت تستخدم مزود S3 متوافقًا غير Cloudflare R2.

## 4) محتوى الإطلاق

من `/admin/settings`:

- ارفع الصورة الشخصية العمودية 4:5.
- راجع وصف Hero والرؤية ونص "عن أحمد".
- ثبّت البريد ورقم واتساب والموقع.
- أضف صورة Open Graph بقياس 1200×630 إن رغبت بصورة مخصصة للمشاركة.

من `/admin/ventures`:

- أضف الرابط النهائي لكل مشروع عندما يصبح عامًا.
- ارفع Cover/Screenshots حقيقية للمشاريع المتاحة.
- راجع حالة كل مشروع: Live / Beta / In development / Planned.

من `/admin/social`:

- أضف Instagram / LinkedIn / GitHub / YouTube / Telegram حسب الحسابات الرسمية فقط.

## 5) اختبار ما قبل الإطلاق

شغّل محليًا أو داخل CI:

```bash
npm ci
npm run typecheck
npm run lint
npm run build
```

ثم افحص:

- `/`
- `/ventures`
- `/about`
- `/services`
- `/vision`
- `/achievements`
- `/insights`
- `/contact`
- `/privacy`
- `/terms`
- `/admin/login`
- `/api/health`
- `/sitemap.xml`
- `/robots.txt`

## 6) اختبار الرسائل

أرسل رسالة تجريبية من `/contact` ثم تأكد أنها ظهرت في `/admin/messages`. إذا لم توجد `DATABASE_URL` فلن يظهر نموذج إرسال معطّل؛ ستظهر للمستخدم وسائل التواصل المباشر بدلًا منه.

## 7) التحقق النهائي

- جرّب الهاتف والكمبيوتر والوضع الفاتح والداكن.
- اختبر زر واتساب والبريد وجميع الروابط الخارجية.
- افتح رابطًا غير موجود وتأكد من صفحة 404.
- سجّل خروجًا من الإدارة وحاول فتح `/admin` للتأكد من الحماية.
- تأكد أن مفاتيح `.env` غير موجودة في Git أو في ملفات الواجهة العامة.
