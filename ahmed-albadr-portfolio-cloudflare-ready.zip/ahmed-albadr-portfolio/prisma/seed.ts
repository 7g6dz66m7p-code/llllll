/**
 * Idempotent seed: `npm run db:seed`.
 * Ventures and insights are upserted by slug (existing rows keep admin edits — only missing rows are created).
 * Collections (services, stats, achievements, social links) are seeded only when empty.
 */
import "dotenv/config";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient, type Prisma } from "../src/generated/prisma/client";
import { ventureSeeds } from "../src/data/ventures";
import { insightSeeds } from "../src/data/insights";
import { achievementSeeds, defaultSiteSettings, fallbackSocialLinks, serviceSeeds, statSeeds } from "../src/data/site";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required to seed");
const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

async function main() {
  for (const v of ventureSeeds) {
    await prisma.venture.upsert({ where: { slug: v.slug }, update: {}, create: { ...v, features: v.features as unknown as Prisma.InputJsonValue } });
  }
  console.log(`✓ ventures (${ventureSeeds.length})`);

  for (const i of insightSeeds) {
    await prisma.insight.upsert({ where: { slug: i.slug }, update: {}, create: i });
  }
  console.log(`✓ insights (${insightSeeds.length})`);

  if ((await prisma.service.count()) === 0) await prisma.service.createMany({ data: serviceSeeds });
  console.log("✓ services");

  if ((await prisma.stat.count()) === 0) await prisma.stat.createMany({ data: statSeeds });
  console.log("✓ stats");

  if ((await prisma.achievement.count()) === 0) {
    const ventures = await prisma.venture.findMany({ select: { id: true, slug: true } });
    await prisma.achievement.createMany({
      data: achievementSeeds.map(({ ventureSlug, ...a }) => ({ ...a, ventureId: ventures.find((v) => v.slug === ventureSlug)?.id ?? null })),
    });
  }
  console.log("✓ achievements");

  await prisma.siteSettings.upsert({ where: { id: "main" }, update: {}, create: { id: "main", ...defaultSiteSettings } });
  console.log("✓ site settings");

  if ((await prisma.socialLink.count()) === 0 && fallbackSocialLinks.length) {
    await prisma.socialLink.createMany({ data: fallbackSocialLinks.map((l) => ({ platform: l.platform, url: l.url, label: l.label, active: l.active, sortOrder: l.sortOrder })) });
  }
  console.log("✓ social links");
}

main()
  .then(() => console.log("Seed complete."))
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
